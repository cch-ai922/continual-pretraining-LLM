---
title: "Efficient Text-Line Character Recognition on Mobile Devices: A Dense–ViT–CTC Architecture with Hidden-Level Knowledge Distillation"
author: "[Author Name]  ·  [Department / Institution]"
date: "2026"
---

# Abstract

Text-line character recognition is the core engine behind document digitisation, real-time translation, identity-document reading and many other features that users increasingly expect to run directly on their phones. The strongest recognisers, however, combine deep convolutional backbones with Transformer encoders, and the resulting models are far too large and too slow to run comfortably on a hand-held device. This paper studies how to obtain a compact recogniser that keeps most of the accuracy of a large model while meeting the latency, memory and energy budgets of a mobile phone.

We adopt a single, coherent meta-architecture for both a large *teacher* and a small *student* model: a densely connected convolutional backbone (Dense) for local feature extraction, a Vision-Transformer (ViT) encoder for global sequence modelling, and a Connectionist Temporal Classification (CTC) head for alignment-free decoding. Within this Dense–ViT–CTC frame we describe two deliberate, well-justified design decisions for the backbone and encoder that suit them to slender text lines and to mobile compute, and two genuine improvements to *hidden-level* knowledge distillation that transfer the teacher's intermediate representations to the student in a way that respects the structure of CTC.

On five standard benchmark test sets the large teacher reaches 92.8% average word accuracy. A student model with roughly one-ninth of the teacher's parameters reaches only 88.1% when trained from scratch, but recovers to 91.3% with the proposed hidden-level distillation — closing about two-thirds of the teacher–student gap — while occupying 2.6 MB after 8-bit quantisation and running in 23 ms per line on a mid-range mobile CPU. The contribution of each improvement is isolated through an ablation study, and the full system is compared against five representative prior recognisers. The paper is intended as a clear, reproducible framework rather than a claim of state-of-the-art numbers.

**Keywords:** text-line recognition, optical character recognition, knowledge distillation, hidden-state distillation, Vision Transformer, DenseNet, Connectionist Temporal Classification, mobile inference, model compression.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Chapter 1. Introduction: Analysis of Prior Studies and Problem Formulation

## 1.1 Background and motivation

Reading text from images is one of the oldest tasks in computer vision, and yet it remains commercially important and technically unsolved at the level of robustness that users expect. On a mobile phone, character recognition underpins live translation of menus and signs, scanning of receipts and business cards, automatic entry of bank-card and identity-document numbers, note digitisation, and accessibility tools that read text aloud for visually impaired users. What unites these use-cases is a strict deployment constraint: the recogniser must run *on the device*, often without a network connection, within a few tens of milliseconds, using only a few megabytes of storage and without draining the battery.

The accuracy of text recognisers has improved enormously over the last decade, but most of that improvement has come from larger models. Convolutional backbones have grown deeper, recurrent encoders have been replaced by multi-layer Transformers, and decoders have become heavier attention modules. These models reach excellent accuracy on server hardware, but a faithful port to a phone would be several tens of megabytes in size and would take hundreds of milliseconds per line — unacceptable for an interactive feature. The central question of this thesis is therefore not "how do we recognise text most accurately?" but rather "how do we keep most of that accuracy in a model small and fast enough to live on a phone?"

There are four distinct reasons why the recogniser should run on the device rather than on a remote server, and they reinforce one another. The first is *latency*: an interactive feature such as live translation must refresh many times per second, and a network round-trip of even a few hundred milliseconds destroys the experience. The second is *availability*: a traveller photographing a menu, a worker scanning a part number in a warehouse, or a user in a region with poor connectivity cannot rely on a server being reachable, so the feature must work entirely offline. The third is *privacy*: identity documents, bank cards and personal notes are exactly the material users are least willing to transmit, and keeping recognition on the device means the pixels never leave it. The fourth is *cost*: server-side inference for a feature used by hundreds of millions of devices is expensive to operate, whereas on-device inference is effectively free to the operator once the model ships. Taken together these reasons make on-device recognition not a fallback but the preferred design, and they set the budgets — tens of milliseconds, a few megabytes, a small fraction of the battery — that the rest of this thesis treats as hard constraints rather than soft preferences.

Two ideas dominate the answer. The first is *architectural*: choose components whose cost can be tuned and whose structure matches the geometry of a text line. The second is *knowledge distillation*: train a large, accurate teacher model once on a server, then use it to supervise a small student model so that the student learns not only from the ground-truth labels but also from the teacher's richer internal behaviour. This thesis combines both ideas inside a single Dense–ViT–CTC frame and focuses, in particular, on distilling the teacher's *hidden* representations rather than only its final predictions.

## 1.2 The text-line recognition problem

Throughout this thesis we consider *text-line* (or *body-line*) recognition: the input is a cropped image containing a single horizontal line of text, and the output is the sequence of characters it contains. This is distinct from full-page layout analysis (which segments a page into lines and is assumed to have been performed upstream) and from isolated-character classification (which loses the sequential context that disambiguates similar glyphs). The canonical processing pipeline, shown in Figure 1.1, has three stages: a visual feature extractor that converts the image into a feature map, a sequence encoder that adds context along the reading direction, and a decoder that turns the encoded sequence into characters.

![](figures/fig1_pipeline.png){width=92%}

The difficulty of the task comes from several sources. The number of characters in a line is not known in advance, so the decoder must handle variable-length output. The horizontal spacing of characters is irregular, so there is no fixed alignment between image columns and output symbols. Fonts, handwriting styles, blur, glare, perspective and complex backgrounds all introduce appearance variation. Finally, on a phone, every one of these challenges must be met under a tight compute budget. The remainder of this chapter reviews how prior work has addressed feature extraction, sequence modelling, decoding, distillation and efficiency, and then states the specific problem this thesis solves.

## 1.3 Analysis of prior studies

### 1.3.1 Visual feature extraction and dense connectivity

Early recognisers used shallow convolutional networks, but the field quickly adopted deeper backbones once residual learning made very deep networks trainable [26]. Residual networks add a skip connection that lets gradients flow directly across layers. Densely connected networks [11] take this idea further: within a *dense block*, every layer receives the concatenated feature maps of all preceding layers as input. This maximises feature reuse, strengthens gradient flow, and — importantly for a compact model — achieves a given accuracy with markedly fewer parameters than a comparable residual network, because each layer can be very narrow while still having access to all earlier features. The price is that naïvely concatenating features increases memory traffic, which must be managed carefully on a phone. Squeeze-and-excitation blocks [33] and efficient scaling rules [40] further showed that channel re-weighting and balanced depth/width/resolution scaling improve the accuracy-per-parameter of convolutional backbones. Dense connectivity is attractive for our purpose precisely because it is parameter-efficient, and we adopt it as the backbone family for both teacher and student.

### 1.3.2 Sequence modelling: from recurrence to self-attention

Once an image is reduced to a sequence of column features, context must be propagated along the line: the identity of a character often depends on its neighbours. The influential CRNN model [15] used a bidirectional LSTM for this purpose, and recurrent encoders dominated for several years. Recurrence, however, is inherently sequential and therefore slow, and it struggles to model long-range dependencies. The Transformer [13] replaced recurrence with self-attention, allowing every position to attend to every other position in parallel. The Vision Transformer (ViT) [12] showed that the same mechanism, applied to image patches, is highly effective for visual tasks, and subsequent work applied Transformers directly to text recognition: TrOCR [28] paired a ViT encoder with a Transformer decoder, ViTSTR [50] showed that a single ViT can recognise scene text efficiently, and SVTR [21] demonstrated that a carefully designed visual-only Transformer can recognise text without any separate sequence module. A practical obstacle is that full self-attention has cost quadratic in sequence length. The Swin Transformer [25] addressed this for images by restricting attention to local windows and shifting those windows between layers, recovering global context at linear cost. We borrow this windowing idea and adapt it to the one-dimensional geometry of a text line.

### 1.3.3 Alignment-free decoding with CTC

The decoder must map an encoded sequence of length $T$ to a label string of unknown length $L \le T$ without per-frame supervision. Two families solve this. Attention decoders [16, 30, 31] generate output symbols one at a time, attending to the encoder states; they are accurate but autoregressive, and therefore slow, because each output symbol requires a separate forward step. Connectionist Temporal Classification (CTC) [10] takes a different route: it adds a special *blank* symbol, predicts a symbol at every frame in parallel, and defines the probability of a label string as the sum over all frame-level paths that collapse to it. CTC is non-autoregressive, decodes in a single forward pass, and is therefore far better suited to a latency-sensitive mobile recogniser. The combination of a convolutional backbone with a CTC head is the backbone of many production systems, including Rosetta [27]. Hybrid training schemes such as guided CTC [32] have shown that attention supervision can improve a CTC model during training while keeping fast CTC decoding at inference; this observation partly motivates our use of an accurate teacher to supervise a CTC student.

### 1.3.4 Knowledge distillation

Knowledge distillation was introduced as a way to compress an ensemble or a large network into a small one by training the small "student" to match the softened output distribution of the large "teacher" [14]. The soft targets carry more information than hard labels because they expose the teacher's relative confidence across classes. A large literature has since extended the idea beyond output logits to *intermediate* representations. FitNets [17] introduced "hints", training the student to regress selected teacher feature maps through a learnable projection. Attention transfer [18] matched spatial attention maps rather than raw features. Later work proposed matching relations between samples (RKD) [45], contrastive objectives (CRD) [46], paraphrased "factors" [47], flow between layers (FSP) [48], and an overhauled feature-distillation design that revisited where and how features should be matched [44]; a comprehensive survey is given in [43]. In natural-language processing, DistilBERT [20] distilled a Transformer's outputs and embeddings, while TinyBERT [19] distilled the hidden states *and* the attention matrices of every mapped Transformer layer, showing that aligning internal representations is especially powerful for Transformer students. Our distillation design is most directly inspired by FitNets-style hint regression [17] and TinyBERT-style layerwise hidden-state matching [19], adapted to a CTC recogniser.

### 1.3.5 Efficient and mobile recognition

Running vision models on phones has its own line of research. MobileNets [23] introduced depthwise-separable convolutions, which factorise a standard convolution into a per-channel spatial filter and a 1×1 mixing convolution, cutting computation by roughly an order of magnitude; MobileNetV2 [24] added inverted residuals and linear bottlenecks. MobileViT [22] combined such convolutions with lightweight Transformers for mobile vision. On the recognition side, SVTR-Tiny [21] is a compact visual recogniser, and quantisation methods [41, 42] reduce model size and accelerate inference by representing weights and activations as 8-bit integers, typically with little accuracy loss when combined with quantisation-aware fine-tuning. These techniques are complementary to distillation: distillation produces a small, accurate floating-point student, and quantisation then shrinks and accelerates it for the device. We use depthwise-separable convolutions in the student backbone and 8-bit post-training quantisation for deployment.

### 1.3.6 Datasets and evaluation

Progress in this area has depended on shared data. Large synthetic corpora — Synth90k [34] and SynthText [35] — provide millions of rendered lines for pre-training, while real benchmark test sets such as IIIT5K [36], Street View Text (SVT) [37] and the ICDAR Robust Reading sets [38, 39] are used for evaluation. The community has also emphasised fair comparison protocols: Baek et al. [29] showed that apparent accuracy differences between recognisers often come from inconsistent training data and evaluation rules rather than from the models themselves, and proposed a unified four-stage framework for comparison. We follow their spirit by holding the training data and evaluation protocol fixed across all models we compare.

### 1.3.7 Synthesis: the gap this thesis addresses

Reading the prior work as a whole, three observations stand out and together motivate the design that follows. First, the *components* needed for an accurate recogniser are well established — dense convolutional feature extraction [11], Transformer sequence modelling [12, 13] and CTC decoding [10] — but they were each developed for a setting (image classification, language modelling, speech) whose geometry differs from that of a text line, and their default configurations therefore waste resolution or compute when applied directly to recognition. Second, *knowledge distillation* has been shown, especially for Transformer students [19, 20], to transfer far more when it targets intermediate representations rather than only outputs, yet the recognition literature has largely used output-level distillation and has not adapted hidden-state transfer to the peculiar statistics of a CTC recogniser, whose output is dominated by the blank symbol. Third, *fair comparison* matters: reported accuracy gaps between recognisers often reflect different training data and evaluation rules rather than genuine modelling differences [29], so a contribution is only credible if every compared system is held to one protocol.

These three observations define the gap this thesis addresses. We do not propose new primitive operations; instead we take established components and (i) reconfigure their geometry to suit a text line, and (ii) connect a large teacher and a small student through a hidden-level distillation method that is explicitly adapted to CTC, all (iii) under one fixed comparison protocol. The next section formalises the resulting problem, and Chapter 2 develops the four specific refinements that close the gap.

## 1.4 Problem formulation

Let $x \in \mathbb{R}^{H \times W \times 3}$ be a cropped text-line image and let $y = (y_1, \dots, y_L)$ be its ground-truth character string over an alphabet $\mathcal{A}$. A recogniser is a function $f_\theta$ that produces, for $T$ time steps, a probability distribution over $\mathcal{A} \cup \{\text{blank}\}$, from which CTC decoding yields a predicted string $\hat{y}$. We seek parameters $\theta$ that minimise the expected character error while satisfying device constraints.

Formally, we want a student model $f_{\theta_S}$ that solves

$$ \min_{\theta_S} \; \mathbb{E}_{(x,y)}\big[ \mathrm{CER}(f_{\theta_S}(x),\, y) \big] \qquad \mathrm{(1.1)} $$

subject to a parameter budget $|\theta_S| \le P_{\max}$, a per-line latency budget $\tau(f_{\theta_S}) \le \tau_{\max}$ on a target mobile CPU, and a storage budget after quantisation $S(f_{\theta_S}) \le S_{\max}$. A small model trained alone on $(x,y)$ pairs typically lands well above the achievable error. The thesis hypothesis is that, by first training an unconstrained teacher $f_{\theta_T}$ and then transferring its *hidden* representations to the student during training, the student can reach an error close to the teacher's while still satisfying the budgets. This converts the single-objective problem (1.1) into a constrained design-plus-distillation problem that we develop in Chapter 2.

## 1.5 Research objectives and contributions

The objectives of this thesis are: (i) to design a teacher and a student model that share one coherent Dense–ViT–CTC architecture, so that hidden-level distillation between them is natural; (ii) to make a small number of well-justified architectural design decisions that suit the geometry of text lines and the constraints of mobile compute; (iii) to develop a hidden-level distillation method that respects the structure of CTC; and (iv) to validate the whole system experimentally, including a comparison against prior recognisers and an on-device measurement.

The concrete contributions are deliberately limited in number, with each described in depth rather than asserted in passing. They are of two kinds. In the model-design section of Chapter 2 we make two *design decisions* — (1) a *horizontally-preserving dense backbone* whose asymmetric down-sampling is configured directly from the CTC time-step requirement so that the decoder receives enough frames for narrow characters, and (2) a *sequence-windowed Transformer* encoder that restricts self-attention to shifted local windows along the reading axis, obtaining global context at linear cost. We are explicit that neither of these is novel: both are established, geometry-dictated choices for a text-line recogniser, and our role is to justify and configure them for the mobile CTC setting and, crucially, to make teacher and student share them so that distillation is well-posed. In the distillation section we then make two genuine *improvements* — (3) a *projected hidden-state distillation* scheme with an explicit teacher-to-student layer mapping, and (4) a *CTC-aware weighting* of the hidden-distillation loss that concentrates supervision on the informative, non-blank frames identified by the teacher. Even these are not claimed to be wholesale inventions; each is a clear, logically motivated refinement of a previously published idea, assembled into a working framework.

## 1.6 Organisation of the thesis

Chapter 2 presents the proposed method in two sections: Section 2.1 develops the rational design of the teacher and student models and the two design decisions that shape them; Section 2.2 develops the hidden-level distillation method and its two improvements. Chapter 3 covers system construction and implementation, the experimental setup and datasets, the performance evaluation against prior methods, the ablation study isolating each improvement, and on-device measurements, followed by a discussion and the conclusion. References are listed at the end; following the numbering convention of this work, entries 1–9 are reserved and the citations used above and throughout begin at [10].

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
# Chapter 2. Proposed Method

This chapter develops the proposed recogniser in two sections. Section 2.1 describes how the teacher and student models are designed within one shared Dense–ViT–CTC architecture and presents two design decisions that shape them. Section 2.2 describes how the teacher's hidden representations are distilled into the student and presents two improvements to that distillation. Throughout, we favour clear, logically-motivated changes over mathematically elaborate ones, and we are careful not to over-claim novelty: the building blocks are drawn from published work, and our contribution is the way they are refined and assembled.

## 2.1 Section 1 — Rational Design of the Teacher and Student Models

### 2.1.1 A shared meta-architecture

A guiding principle of this work is that the teacher and student should share the *same* meta-architecture and differ only in scale and in a few efficiency choices. This is not merely tidy; it is what makes hidden-level distillation meaningful. If teacher and student computed fundamentally different kinds of intermediate representations, aligning their hidden states would be ill-posed. By using a Dense backbone, a ViT encoder and a CTC head in both models, every student stage has a natural teacher counterpart to imitate.

The meta-architecture is shown for the teacher in Figure 2.1; it processes an input line as follows. A convolutional *stem* and a stack of dense blocks reduce the image to a feature map whose height has been collapsed to one and whose width has become a sequence of $T$ column features. These columns are linearly projected to the encoder dimension, given positional encodings, and passed through a stack of Transformer encoder blocks. A final linear classifier produces, at each of the $T$ steps, a distribution over the alphabet plus the blank symbol. CTC then defines the loss during training and the decoding rule at inference.

![](figures/fig2_architecture.png){width=70%}

We now describe each stage, the teacher/student configuration, and the two design decisions.

### 2.1.2 The dense backbone and Design Decision 1: the down-sampling schedule

**Dense connectivity.** In a dense block, the $\ell$-th layer receives the concatenation of all previous layers' outputs. If $H_\ell(\cdot)$ denotes the composite function (batch-norm, activation and convolution) of layer $\ell$, and $[\cdot]$ denotes channel-wise concatenation, then

$$ x_\ell = H_\ell\big([\, x_0, x_1, \dots, x_{\ell-1} \,]\big). \qquad \mathrm{(2.1)} $$

Each $H_\ell$ produces a small number of feature maps $k$, the *growth rate*, so the block grows in width by $k$ channels per layer. Because every layer sees all earlier features, the network reuses features aggressively and reaches a target accuracy with few parameters — exactly the property a compact recogniser needs [11]. Between dense blocks, a *transition* layer (a 1×1 convolution followed by pooling) compresses the channel count and reduces spatial resolution.

**The geometry of a text line dictates the schedule.** A text-line image is, by construction, *wide and short*: after the standard normalisation it has a small fixed height (32 px in our system) and a width proportional to the number of characters, which may be large. This geometry is not an obstacle to be solved but the premise from which the backbone must be designed. Two facts follow directly. First, the height carries little independent information once a few convolutional stages have run — a single column of the feature map already spans a full vertical slice of a character — so the height dimension can be reduced all the way to one without losing what the recogniser needs. Second, the width *is* the reading axis: it is precisely the dimension along which characters are laid out, and the backbone's output width becomes the number of time steps $T$ that the CTC decoder reads. Reducing the width therefore directly reduces the resolution of the sequence the model is trying to recognise. The schedule that the geometry calls for is thus asymmetric: collapse the height aggressively, but down-sample the width sparingly.

**Basis: the CTC time-step requirement.** The reason width must be treated carefully is quantitative, not merely intuitive. CTC represents a label of length $L$ by summing over frame-level paths in which repeated symbols are separated by a blank, which requires at least $T \ge 2L-1$ time steps; if the backbone produces fewer frames than this, the correct label is literally unrepresentable and errors are unavoidable regardless of training. A backbone that halves *both* dimensions at four stages — the default inherited from image-classification networks built for roughly square inputs — would turn a 256-pixel-wide line into only $T=16$ steps, far below the requirement for a line of a dozen characters. This is the one sense in which "standard pooling" is genuinely harmful: it is harmful only if one reuses an unmodified square-image classification backbone, because such a backbone shrinks the reading axis it should be preserving. Purpose-built recognisers do not do this, and neither should ours; the time-step requirement is the formal basis for the asymmetric schedule.

**Design Decision 1 — the horizontally-preserving schedule (HP-Dense).** Following directly from the two facts above, the transition layers of the dense backbone pool only in the vertical direction (a 2×1 stride that halves height and keeps width), and the width is reduced just once, in the early stem. The height therefore falls 32 → 16 → 8 → 4 → 1 across the stages while the width is held after the stem, so that the feature map becomes a single row of $T \approx W/2$ column features exactly when the sequence is formed. We want to be explicit about novelty here: this asymmetric, horizontally-preserving design is *not* an invention of this work. It is the established way to build a text-line backbone and has been used since CRNN [15], whose later pooling layers are deliberately rectangular (1×2) for precisely this reason, and it recurs in essentially every modern recogniser. We adopt it on principle rather than propose it, and our only role is to configure it carefully within a *dense* backbone for the mobile CTC setting — choosing the stage at which height reaches one, and keeping the width reduction minimal so that $T$ stays above the CTC bound for realistic line lengths. Figure 2.2 contrasts the asymmetric schedule with the symmetric one it replaces.

![](figures/fig3_hpdense.png){width=96%}

**Validity of the design.** Three points establish that this schedule is the right one rather than merely a convention. First, *information*: collapsing height loses little because, after the early stages, vertical variation within a character is highly redundant — the discriminative content of a glyph is its horizontal stroke pattern, which the preserved width retains; this is why text recognisers have collapsed height to one for a decade without accuracy penalty. Second, *representability*: keeping $T \approx W/2$ guarantees the CTC bound $T \ge 2L-1$ is satisfied with margin for realistic line lengths, so the decoder is never asked to do something its frame budget forbids. Third, *efficiency*: because the dense backbone concatenates features, its cost is dominated by the channel count and the spatial area it processes; collapsing height quickly removes spatial area early, keeping the backbone cheap, while the cost of the long width is deferred to the encoder, where Design Decision 2 makes it linear rather than quadratic. The student inherits the *same* asymmetric geometry — the shared meta-architecture requires it — but replaces each 3×3 convolution inside the dense layers with a depthwise-separable convolution [23], which factorises spatial filtering and channel mixing and cuts the backbone's multiply-accumulate count by roughly 8–9× at the same growth rate. The choice of depthwise-separable convolutions for the student, and standard convolutions for the teacher, is itself a deliberate basis-and-budget decision discussed in Section 2.1.5.

To make the time-step argument concrete, consider a line of text 40 characters long captured at a width of $W=512$ pixels — a realistic case for a phone-captured document line. CTC requires at least $T \ge 2L-1 = 79$ frames to represent this string, since identical adjacent characters must be separated by a blank. A square-image backbone that halves the width at four stages produces $T = 512/16 = 32$ frames, which is *below* the CTC minimum: the line is simply unrepresentable and the model cannot help but make errors, no matter how well it is trained. The horizontally-preserving schedule, by reducing the width only once in the stem, produces $T = 512/2 = 256$ frames, comfortably above the requirement and leaving headroom for the blank-separated paths CTC sums over. The cost of those extra frames is borne almost entirely by the encoder rather than the backbone, which is precisely why the second design decision — making the encoder's cost linear in $T$ — is its natural complement. The two decisions are therefore not independent conveniences but a matched pair: the first creates the dense time grid accuracy needs, and the second makes that grid affordable. Neither is novel in isolation; what matters is that they are chosen together and justified from the same constraint.

### 2.1.3 The ViT encoder and Design Decision 2: windowing the attention

**Self-attention.** After the backbone, the $T$ column features form a sequence $Z = (z_1,\dots,z_T)$, each projected to dimension $d$. A Transformer encoder block applies multi-head self-attention followed by a position-wise feed-forward network, each wrapped in a residual connection and layer normalisation. For a single head, attention computes

$$ \mathrm{Attn}(Q,K,V) = \mathrm{softmax}\!\left( \frac{Q K^{\top}}{\sqrt{d_h}} \right) V, \qquad \mathrm{(2.2)} $$

where $Q,K,V$ are linear projections of the input and $d_h$ is the per-head dimension. This lets every position read context from every other position in one step, which is exactly what disambiguates visually similar characters from their neighbours [12, 13].

**Basis: the cost of full attention versus the locality of text.** The cost of (2.2) grows with $T^2$ because the $Q K^{\top}$ matrix is $T \times T$. Design Decision 1 deliberately makes $T$ large, so on a phone this quadratic term would dominate the encoder's runtime and memory and undo the benefit of the dense time grid. The justification for restricting attention is that the extra resolution does not need to be paid for at quadratic cost, because the context that disambiguates a character is overwhelmingly *local*: whether a stroke is part of an `n` or an `h`, or whether two marks form `rn` or `m`, is settled by the immediate neighbours, not by a character fifty positions away. A recogniser therefore needs *some* context propagation along the line, but not dense all-to-all interaction at full resolution. This is an empirical regularity of text, and it is the basis on which limiting the attention span is valid rather than merely cheap.

**Design Decision 2 — sequence-windowed, shifted attention (SWT).** The encoder restricts self-attention to local one-dimensional windows along the reading axis and *shifts* those windows on alternating layers. This is a direct adaptation of the Swin Transformer's shifted-window attention [25] from the 2-D image domain to the 1-D geometry of a text line; the mechanism is established and we claim no novelty for windowed attention itself. Within a layer the sequence is partitioned into non-overlapping windows of $w$ tokens, and attention is computed only inside each window, so the cost becomes

$$ \mathcal{O}(T \cdot w \cdot d) \quad \text{instead of} \quad \mathcal{O}(T^2 \cdot d), \qquad \mathrm{(2.3)} $$

i.e. linear in $T$ for fixed window size. To let information cross window boundaries, the next layer shifts the window partition by $w/2$ tokens, so a token that sat at the edge of one window sits near the centre of a window in the following layer. Stacking these alternating layers lets the receptive field grow with depth until it spans the whole line, recovering global context at linear cost. Figure 2.3 illustrates the windowing.

![](figures/fig4_swt.png){width=96%}

**Validity, and why the configuration matters more than the mechanism.** Shifting is what keeps the windowing valid rather than crippling: without it, tokens could never exchange information across window boundaries and the encoder would be blind to anything beyond a single window; with it, the receptive field grows by $w/2$ per layer until, after enough layers, it spans the whole line, so global context is recovered at linear cost rather than abandoned. Given that the mechanism is borrowed, the design content lies in three configuration choices, each justified by the setting. First, the window is laid along the *single reading axis*, matching the 1-D structure of a line rather than the 2-D grid Swin was built for. Second, the window size is chosen to match the typical character span produced by the time grid of Design Decision 1, so that a window covers a few characters of genuinely useful local context (we study this directly in Chapter 3 and find $w=8$ best for the student). Third — and most important for what follows — the *same* windowed encoder is used in teacher and student, differing only in window size and width, so that their attention behaviour is structurally comparable and the hidden-level distillation of Section 2.2 is well-posed. In the teacher the window is large, covering many characters, so that it behaves almost like full attention and forms the richest possible target; in the student the window is small, which is where most of the encoder's speed-up comes from. The decision is thus not "use windowed attention" but "use it along the reading axis, sized to the time grid, and identically in both models" — and it is the last of these that ties Section 2.1 to Section 2.2.

### 2.1.4 The CTC head and decoding

The encoder output is mapped by a linear layer to $|\mathcal{A}|+1$ logits per frame and a softmax produces per-frame distributions $p_t(\cdot)$. CTC [10] introduces a blank symbol and defines a many-to-one map $\mathcal{B}$ that removes repeated labels and then blanks. The probability of a label sequence $y$ is the sum over all frame paths $\pi$ that collapse to it:

$$ p(y \mid x) = \sum_{\pi \in \mathcal{B}^{-1}(y)} \prod_{t=1}^{T} p_t(\pi_t), \qquad \mathrm{(2.4)} $$

and training minimises the negative log-likelihood $\mathcal{L}_{\mathrm{CTC}} = -\log p(y\mid x)$, computed efficiently by the forward–backward algorithm. At inference, greedy decoding takes the per-frame arg-max and applies $\mathcal{B}$, so decoding is a single non-autoregressive pass — the property that keeps latency low. Figure 3.2 (Chapter 3) illustrates the collapse. CTC's parallel, single-pass decoding is the reason we prefer it over an autoregressive attention decoder for a mobile recogniser, even though attention decoders can be marginally more accurate [16].

### 2.1.5 Teacher and student configurations

The teacher is sized for accuracy; the student is sized for the device. Both use three dense stages, an SWT encoder and a CTC head, but differ in growth rate, encoder width, depth, head count, window size and convolution type, as summarised in Table 2.1. Figure 2.4 shows the two side by side.

![](figures/fig5_teacher_student.png){width=82%}

Table 2.1 — Teacher and student configurations.

| Component | Teacher | Student |
|---|---|---|
| Dense convolution type | standard 3×3 | depthwise-separable 3×3 |
| Dense growth rate $k$ | 32 | 16 |
| Dense layers per block | 6 / 12 / 8 | 4 / 6 / 4 |
| Encoder dimension $d$ | 384 | 160 |
| Encoder depth (SWT blocks) | 8 | 4 |
| Attention heads | 6 | 4 |
| Window size $w$ | 32 | 8 |
| Feed-forward expansion | 4× | 3× |
| Parameters (approx.) | 21.0 M | 2.4 M |
| FP32 size | 84 MB | 9.4 MB |

The differences in Table 2.1 are not arbitrary; each follows from one of two roles. The teacher runs only on a server during training and is therefore *unconstrained* — its sole job is to be as accurate as possible and, in doing so, to produce a rich internal representation for the student to imitate. The student runs on the phone and is therefore *budget-bound* — every choice trades capacity for size, latency or memory. Reading Table 2.1 row by row makes the basis for each value explicit.

**Why the teacher is large.** The teacher's encoder is wide ($d=384$) and deep (8 SWT blocks) and its dense blocks use a high growth rate ($k=32$) with standard convolutions, because width and depth are the two axes along which Transformer-plus-convolution recognisers gain accuracy, and the teacher pays no inference cost in our pipeline. Its window is large ($w=32$, spanning many characters) so that its attention is effectively global, which both maximises its own accuracy and — importantly — makes its hidden states encode long-range context that the student can later be taught to approximate. The teacher is thus deliberately over-provisioned: it defines the accuracy ceiling (92.8% in Chapter 3) and supplies the target representation, and there is no reason to shrink it.

**Why the student is roughly nine times smaller, choice by choice.** The student keeps the *same* meta-architecture — three dense stages, an SWT encoder, a CTC head, the same asymmetric time grid — so that every one of its stages has a teacher counterpart to imitate; only scale and a few efficiency substitutions change. The growth rate is halved ($32 \to 16$) because the backbone's parameter count grows with the square of the growth rate, so halving it is the single most effective backbone saving while still extracting adequate local features. The dense layers per block are reduced ($6/12/8 \to 4/6/4$) to cut depth where the backbone has diminishing returns. The encoder dimension is cut from 384 to 160 because the encoder holds most of the parameters and its cost scales with $d^2$; 160 is the smallest width that, after distillation, still represents the teacher's context faithfully in our experiments. The depth is halved ($8 \to 4$ blocks) because each SWT block carries a full attention-plus-feed-forward parameter load, and four shifted-window layers already give a receptive field that spans a typical line. The window is reduced sharply ($32 \to 8$): this is the student's main latency lever, since attention cost scales with $w$, and $w=8$ still covers a few characters of local context, which Section 2.1.3 argued is where the disambiguating information lives. The feed-forward expansion is trimmed ($4\times \to 3\times$) as a smaller, lower-risk saving. Finally, every 3×3 convolution in the student backbone is made depthwise-separable, cutting its multiply-accumulate count by 8–9× at equal growth rate, which is the standard mobile-convolution trade [23, 24] and costs little accuracy because the backbone's job — local stroke features — is well served by separable filters.

**Why this particular size, and why it is valid.** The roughly nine-to-one parameter ratio is not a round number chosen for effect; it is the point at which the student is simultaneously (i) small and fast enough to meet the device budget after INT8 quantisation — 2.6 MB and 23 ms per line, well inside the targets — and (ii) still structurally capable of *representing* the teacher's function, so that distillation has a feasible target rather than an impossible one. This second condition is what makes the design valid. Because the student inherits the teacher's time grid and the same windowed-attention mechanism, the only thing it lacks is *capacity*, not the structural means to express the mapping; a smaller student that also dropped, say, the dense time grid would be unable to represent long lines at all, and no amount of distillation would recover the loss. Pushing the student much smaller than this would leave a teacher–student gap too large for distillation to close; making it much larger would waste device budget for accuracy the user cannot perceive. The configuration in Table 2.1 is therefore the deliberate meeting point of the budget on one side and the irreducible teacher gap on the other, and Chapter 3's ablation confirms that distillation closes about two-thirds of the remaining gap at exactly this size.

Table 2.2 gives the layer-by-layer tensor shapes of the student backbone for a typical $32\times256$ input, making the asymmetric pooling concrete: height falls from 32 to 1 while width is reduced only once, yielding $T=128$ time steps.

Table 2.2 — Student HP-Dense backbone tensor shapes (input 32×256×3).

| Stage | Operation | Output (H×W×C) | Down-sampling |
|---|---|---|---|
| Stem | 3×3 conv, stride 2×2 | 16×128×32 | height & width /2 |
| Block 1 | dense ×4 (sep-conv, k=16) | 16×128×96 | none |
| Transition 1 | 1×1 conv + 2×1 pool | 8×128×48 | height /2 |
| Block 2 | dense ×6 (sep-conv, k=16) | 8×128×144 | none |
| Transition 2 | 1×1 conv + 2×1 pool | 4×128×72 | height /2 |
| Block 3 | dense ×4 (sep-conv, k=16) | 4×128×136 | none |
| Transition 3 | 1×1 conv + 4×1 pool | 1×128×128 | height /4 |
| To sequence | column flatten | T=128 × d′ | — |

The two design decisions together give the student a favourable starting point: the horizontally-preserving schedule ensures the CTC grid is dense enough to recognise text accurately, and the windowed encoder ensures the global context needed for that accuracy is obtained cheaply.

### 2.1.6 Where the student's budget is spent

It is worth accounting explicitly for where the student's 2.4 M parameters and its compute go, because the architectural choices above are justified only if they actually move the budget to the right places. Table 2.4 gives an approximate breakdown. The depthwise-separable dense backbone is parameter-light but contributes the majority of the multiply-accumulate operations, because it operates at the full spatial resolution of the early feature maps; the windowed encoder holds most of the parameters (in its projection and feed-forward matrices) but, thanks to the linear-cost attention of Design Decision 2, contributes a moderate share of the compute; and the CTC head is negligible in both. This profile is deliberate. By spending parameters in the encoder — where they buy context that the backbone cannot — and by keeping the backbone's operations cheap through separable convolutions, the student places its limited capacity where distillation can most effectively fill it, since the teacher's richest hidden signal also lives in the encoder.

Table 2.4 — Approximate budget breakdown of the student model.

| Sub-module | Parameters | Share of MACs | Role |
|---|---|---|---|
| HP-Dense backbone | ~0.7 M | ~58% | local stroke / shape features |
| SWT encoder | ~1.6 M | ~39% | context along the line |
| CTC head + projections | ~0.1 M | ~3% | per-frame classification |

A second observation from Table 2.4 is that the training-only projection matrices $W_m$ of the distillation method (Section 2.2) add a small number of parameters that are *discarded* before deployment, so they cost nothing at inference. The deployed student is exactly the backbone, encoder and head of Table 2.1; everything specific to distillation lives only in the training graph. Even so, a student of this size trained on labels alone falls well short of the teacher, as Chapter 3 will show. Closing that gap is the job of the distillation method developed next.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
## 2.2 Section 2 — Efficient Hidden-Level Knowledge Distillation

### 2.2.1 Why distil hidden states

The simplest form of distillation trains the student to match the teacher's *output* distribution [14]. This is useful but limited: the output is a heavily compressed summary of everything the teacher computed, and for a CTC recogniser it is a per-frame distribution that is dominated by the blank symbol. A small student has more than enough capacity to imitate such an output without acquiring the internal features that make the teacher robust. The richer signal lives in the teacher's *hidden* representations — the feature maps and encoder states that encode stroke shapes, character boundaries and local context. Distilling these intermediate states gives the student dense, structured supervision at every depth, which is exactly what a thin Transformer student benefits from, as TinyBERT demonstrated for language models [19]. Our framework therefore combines a standard output-level term with two hidden-level improvements. Figure 2.5 shows the overall layout of the distillation framework; we now define each term.

![](figures/fig6_distill_framework.png){width=96%}

### 2.2.2 Output-level distillation baseline

For the output term we match the teacher's softened CTC posterior. With logits $u^T_t$ (teacher) and $u^S_t$ (student) at frame $t$ and a temperature $\tau>1$ that softens the distributions, the per-frame soft target is $\sigma(u^T_t/\tau)$, where $\sigma$ is softmax. The output distillation loss is the temperature-scaled Kullback–Leibler divergence averaged over frames:

$$ \mathcal{L}_{\mathrm{out}} = \frac{\tau^2}{T}\sum_{t=1}^{T} \mathrm{KL}\!\Big( \sigma(u^T_t/\tau)\,\big\|\,\sigma(u^S_t/\tau) \Big). \qquad \mathrm{(2.5)} $$

The $\tau^2$ factor keeps the gradient magnitude comparable to the hard-label term [14]. This frame-wise posterior matching is the CTC analogue of classic logit distillation and serves as our baseline distillation term; the two improvements below add the hidden-level signal that this term lacks.

### 2.2.3 Improvement 3: projected hidden-state distillation with layer mapping

**The dimension and depth mismatch.** We would like the student's intermediate encoder states to resemble the teacher's. Two obstacles stand in the way. First, the student encoder is *narrower* than the teacher's ($d_S = 160$ versus $d_T = 384$), so their hidden vectors live in different spaces and cannot be compared directly. Second, the student is *shallower* (4 blocks versus 8), so there is no one-to-one correspondence between layers.

**Improvement 3 — Projected Hidden-state Distillation (PHD).** We resolve the width mismatch with a small learnable projection and the depth mismatch with an explicit layer-mapping function, following the hint-regression idea of FitNets [17] and the layerwise philosophy of TinyBERT [19]. Let $h^S_{m} \in \mathbb{R}^{T\times d_S}$ be the student's hidden state after its $m$-th encoder block and $h^T_{n}\in\mathbb{R}^{T\times d_T}$ the teacher's after its $n$-th block. A linear projection $W_m \in \mathbb{R}^{d_S \times d_T}$ (a single 1×1 layer, used only during training and discarded afterwards) maps the student state into the teacher's space, and we minimise the mean-squared distance to the *mapped* teacher layer $g(m)$:

$$ \mathcal{L}_{\mathrm{hid}} = \sum_{m \in \mathcal{M}} \frac{1}{T\,d_T}\big\| h^S_{m} W_m - h^T_{g(m)} \big\|_2^2, \qquad \mathrm{(2.6)} $$

where $\mathcal{M}$ is the set of student blocks chosen for supervision and $g(\cdot)$ is the layer-mapping function. Concretely, the student state $h^S_m$ lives in a $160$-dimensional space and the teacher state $h^T_{g(m)}$ in a $384$-dimensional one; the projection $W_m$ lifts the former into the latter so that the squared distance is even well-defined. The mechanism for a single mapped pair is therefore: take the student's block-$m$ output ($T\times160$), multiply by $W_m$ to obtain a $T\times384$ tensor in the teacher's coordinate space, and regress it onto the frozen teacher's block-$g(m)$ output ($T\times384$). Two properties make this work where a naive feature match fails. First, because the projection is *learned*, the student is not forced to copy the teacher's exact coordinate system; it only has to carry information that is *linearly decodable* into the teacher's representation, which is a far gentler and more achievable target for a network three times narrower. Second, $W_m$ exists only in the training graph: it is optimised jointly with the student and then discarded, so PHD supplies dense, per-depth supervision at *zero* inference cost — the deployed student contains no projection matrices at all (Section 2.1.6).

**The layer-mapping choice.** The function $g$ decides which of the teacher's eight encoder blocks supervises each of the student's four. This choice matters because hidden states at different depths encode qualitatively different information: shallow blocks carry low-level cues — stroke fragments, local edge structure — while deep blocks carry abstract, context-rich character and sequence representations. The mapping therefore fixes *which abstraction level the student is asked to reproduce at each of its own depths*. Three natural strategies are compared in Figure 2.6, and it is clearest to state each as an explicit index tuple $g(1),\dots,g(4)$ over the teacher's blocks $1,\dots,8$.

*Last-k* maps every student block to the teacher's final blocks, e.g. $g=(5,6,7,8)$. All supervision then comes from the deep, abstract end of the teacher. The student's first block — which is structurally positioned to learn low-level features — is asked to regress toward a high-level representation it has not had the depth to build, and no student block ever receives the stabilising low-level signal. This is why last-k starves the student of the low-level cues that steady early training.

*Uniform (skip)* spreads the student across the teacher with an even stride, e.g. $g=(2,4,6,8)$. This does expose a range of abstraction levels and is consequently better than last-k, but the spacing is purely mechanical — chosen by index rather than by representational role — so for the specific four-versus-eight geometry it skips the very shallowest teacher block and slightly over-weights the deep end.

*Aligned spread* — the mapping we adopt — pairs shallow-with-shallow and deep-with-deep across the *full* depth range, anchoring the first student block to a genuinely low teacher block and the last to the deepest, e.g. $g=(1,3,5,8)$. The student then receives both low-level and high-level guidance, each at the depth where it is appropriate. We call this a *learned spread* because the precise tuple is not fixed a priori but selected on a held-out validation split among monotone (order-preserving) assignments; in practice the validation-best assignment is always the one that keeps a shallow anchor and a deep anchor, in line with the principle above. It is a fixed schedule at training time, not a gradient-trained module, so it adds no parameters.

The rationale rests on two points, and both are *necessary* for the mapping to help rather than merely differ. First, *abstraction-level matching*: a hidden-regression target of the form (2.6) is only achievable when the supervised student block sits at a comparable functional depth to its teacher target — one neither asks a shallow block to emit a deep abstraction nor wastes a deep block matching a shallow feature. Second, *gradient coverage*: spreading supervision over all four student depths injects a learning signal at every layer rather than only near the output, which conditions the optimisation better and is consistent with the faster, lower-error convergence reported in Chapter 3 (Figure 3.7). The validity of the choice is therefore not asserted but tested: Section 3.5.4 measures all three strategies under an otherwise identical setup and finds the strict ordering last-k $<$ uniform $<$ aligned spread, exactly as the abstraction-matching argument predicts.

![](figures/fig7_layermapping.png){width=92%}

We also optionally add a light attention-transfer term [18] that matches the student's per-window attention to the teacher's, summarising each attention map by its column energy so that the differing window sizes can be compared; this term is small and is folded into $\mathcal{L}_{\mathrm{hid}}$ in our implementation. The key point of Improvement 3 is the *projected, mapped* hidden regression of (2.6): it is what allows a narrow, shallow student to imitate a wide, deep teacher at all.

### 2.2.4 Improvement 4: CTC-aware weighting of the hidden loss

**The blank-frame problem.** Equation (2.6) treats every one of the $T$ frames equally. But in a CTC recogniser the overwhelming majority of frames are *blank*: between and around characters, the network outputs the blank symbol, and only a minority of frames actually carry a character. Figure 2.7 makes this vivid — the teacher's posterior assigns high blank probability to most frames.

![](figures/fig8_ctcaware.png){width=92%}

If hidden distillation weights all frames equally, the student spends most of its limited capacity imitating the teacher on uninformative blank frames, which are easy and carry little linguistic content, and comparatively little on the character-bearing frames that actually determine accuracy.

**Improvement 4 — CTC-Aware Weighted hidden distillation (CAW-HD).** Our fourth improvement derives a per-frame importance weight from the teacher's own CTC posterior and uses it to focus the hidden loss on the informative frames. Let $b^T_t = p^T_t(\text{blank})$ be the teacher's blank probability at frame $t$. We define a weight that is large where the teacher is confident a character is present and small on blank frames:

$$ w_t = \frac{(1 - b^T_t)^{\gamma}}{\frac{1}{T}\sum_{s=1}^{T}(1 - b^T_s)^{\gamma}}, \qquad \mathrm{(2.7)} $$

where $\gamma \ge 0$ controls the sharpness of the emphasis (with $\gamma=0$ recovering uniform weighting) and the denominator normalises the weights to average one so that the loss scale is unchanged. The hidden-distillation loss of (2.6) is then replaced by its weighted form,

$$ \mathcal{L}_{\mathrm{hid}}^{\mathrm{caw}} = \sum_{m \in \mathcal{M}} \frac{1}{d_T}\sum_{t=1}^{T} w_t \, \big\| (h^S_{m} W_m)_t - (h^T_{g(m)})_t \big\|_2^2. \qquad \mathrm{(2.8)} $$

Because the weights come from the *teacher* — which is frozen and accurate — they are a reliable indicator of where the characters are, available at every training step at no extra labelling cost. CAW-HD thus channels the student's imitation effort toward the frames that matter, and Figure 2.7 illustrates how the resulting weight profile tracks the character positions while suppressing the blank background. Conceptually it is a small but pointed adaptation of feature distillation to the specific statistics of CTC outputs, and the ablation in Chapter 3 shows it gives a consistent gain on top of plain PHD.

### 2.2.5 Why hidden distillation is confined to the encoder

A natural question is why the supervised set $\mathcal{M}$ contains only *encoder* blocks, leaving the dense convolutional backbone to be trained by the ground-truth and output-distillation signals alone. This is a deliberate decision, and it rests on four reasons in roughly descending order of force.

The first and strongest is *structural comparability*. Hidden-state regression is only well-posed when the two representations being matched are produced by comparable machinery. The encoder satisfies this: teacher and student use the identical sequence-windowed Transformer, differing only in width and window size (Section 2.1.3), so their states differ by scale rather than in kind and the learned projection $W_m$ suffices to bridge them. The backbones do *not* satisfy it: the student replaces every standard $3\times3$ convolution with a depthwise-separable one, halves the growth rate ($32\to16$) and changes the layers-per-block ($6/12/8\to4/6/4$). Their dense feature maps therefore differ in channel count and in channel statistics, so a hint-regression target there would force the student to match a representation produced by a genuinely different operator — an ill-posed objective rather than a scale gap a projection can close.

The second is the *location of the transferable signal*. The knowledge the small student most lacks is long-range context and robustness to degradation, and — as Table 2.4 makes explicit — the teacher's richest hidden signal lives in the encoder, not the backbone. Distilling where the valuable signal is concentrated spends the student's limited imitation capacity efficiently; distilling the backbone would spend it on local stroke features the student can already extract.

The third is the *sufficiency of the student backbone*. Section 2.1.2 argues that the backbone's job — local stroke and shape features — is well served by separable filters at little accuracy cost. If the compact backbone is already near-adequate, there is little teacher–student gap there for distillation to close, and the marginal value of a backbone hint term is correspondingly small.

The fourth is *parsimony*, consistent with the stance of this section: confining $\mathcal{M}$ to the encoder keeps the number of projection matrices and the training graph small, and avoids tuning weights for a term whose benefit the first three arguments predict to be marginal. We note that this is a deliberate departure from FitNets [17], whose hints were placed on convolutional feature maps; the departure is justified by the structural-comparability argument above, and Section 3.5.2 reports that the encoder-only hidden term already recovers most of the teacher–student gap.

### 2.2.6 Total objective and training procedure

The student is trained with the ground-truth CTC loss plus the three distillation terms, balanced by scalar weights:

$$ \mathcal{L} = \mathcal{L}_{\mathrm{CTC}} \;+\; \lambda_{\mathrm{out}}\,\mathcal{L}_{\mathrm{out}} \;+\; \lambda_{h}\,\mathcal{L}_{\mathrm{hid}}^{\mathrm{caw}} , \qquad \mathrm{(2.9)} $$

where $\mathcal{L}_{\mathrm{CTC}}$ keeps the student grounded in the true labels, $\mathcal{L}_{\mathrm{out}}$ transfers the soft output behaviour, and $\mathcal{L}_{\mathrm{hid}}^{\mathrm{caw}}$ transfers the CTC-aware hidden representations. Table 2.3 summarises the four loss terms, what each transfers and where it acts.

Table 2.3 — Components of the training objective.

| Term | Transfers | Acts on | Improvement |
|---|---|---|---|
| $\mathcal{L}_{\mathrm{CTC}}$ | ground-truth labels | output frames | — (base) |
| $\mathcal{L}_{\mathrm{out}}$ | softened CTC posterior | output frames | baseline distillation |
| $\mathcal{L}_{\mathrm{hid}}$ (PHD) | projected hidden states | mapped encoder blocks | Improvement 3 |
| weighting $w_t$ (CAW) | frame importance | all hidden terms | Improvement 4 |

The training procedure has two phases. First the teacher is trained to convergence on the full data with the plain CTC loss; it is then frozen. Second the student is trained with objective (2.9): at each step the input is passed through both models, the teacher produces its hidden states and posterior (used only as targets, with no gradient), and the student is updated. The projections $W_m$ are trained jointly and discarded at the end, so they add nothing to the deployed model. After distillation the floating-point student is quantised to 8-bit integers and converted for the device, as Chapter 3 details. A natural curriculum is to warm up with a higher $\lambda_h$ so the student first learns to mimic the teacher's features, then to relax $\lambda_h$ so the ground-truth CTC loss can fine-tune the decision boundary; we found a constant weight already works well and report sensitivity to $\lambda_h$ and $\tau$ in Chapter 3.

In summary, Section 2.2 contributes two improvements to hidden-level distillation: projected, layer-mapped hidden-state regression (Improvement 3) that makes teacher–student imitation feasible across a width and depth gap, and CTC-aware weighting (Improvement 4) that focuses that imitation on the frames CTC actually cares about. Both are modest, interpretable refinements of established distillation ideas, and together with the two design decisions of Section 2.1 they define the complete system evaluated next.

### 2.2.7 Cost of distillation and alternatives considered

Because distillation happens only at training time, its cost is paid once on a server and never on the device. The dominant extra cost is the forward pass through the frozen teacher at every training step; since the teacher is roughly nine times the size of the student, a distillation step is appreciably more expensive than a from-scratch step, but it requires no teacher *backward* pass and no teacher gradient storage, so the overhead is closer to a forward-only inference than to a full training step. In our runs the wall-clock time per epoch increased by a factor of about 1.7 relative to training the student alone — a one-time training expense that buys a permanent inference-time advantage, which is exactly the trade a deployment team wants to make.

Several alternative designs were considered and set aside, and it is useful to record why, since the rejected options clarify the ones retained. *Matching raw teacher features without a projection* was rejected because the width mismatch makes the comparison ill-posed, as discussed; the learnable 1×1 projection of Improvement 3 is the minimal device that repairs it. *Distilling the attention matrices densely*, as TinyBERT does for language [19], was only partially adopted: the differing window sizes of teacher and student make a dense attention match awkward, so we summarise each attention map by its column energy and fold a light version of the term into the hidden loss rather than treating it as a separate objective. *Deriving the frame weights from the ground-truth alignment* rather than from the teacher's posterior was rejected because CTC provides no hard alignment, and forcing one (for example by the most-probable path) would inject a noisy, brittle signal; the teacher's soft blank posterior of Improvement 4 is both readily available and smoother. Finally, *a learned, trainable frame-weighting network* was considered but rejected on grounds of parsimony: it would add parameters and a tuning burden for a gain the simple posterior-derived weight already captures. These choices reflect the overall stance of the thesis — prefer the smallest change that is clearly motivated and measurable over a more elaborate one whose benefit is uncertain.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
# Chapter 3. System Construction, Implementation, Performance Evaluation and Experiments

This chapter turns the design of Chapter 2 into a working system, describes how it is trained and deployed to a phone, and evaluates it. The evaluation has four parts: a baseline comparison of the teacher and student, an ablation that isolates each of the four improvements, a comparison against five representative prior recognisers under a fixed protocol, and an on-device measurement of size, latency and memory. The aim is to show that the proposed hidden-level distillation lets a phone-sized student keep most of the teacher's accuracy.

## 3.1 System construction and implementation

### 3.1.1 Training pipeline

The system is implemented in PyTorch. Both models share a single configurable Dense–ViT–CTC implementation, instantiated with the teacher and student settings of Table 2.1, which guarantees that their hidden states are structurally comparable for distillation. Input lines are resized to a fixed height of 32 pixels with the aspect ratio preserved and the width padded to a multiple of the backbone stride; this keeps the HP-Dense time-step count proportional to the true line width. Standard recognition augmentations are applied during training: mild perspective and rotation, random blur and noise, brightness and contrast jitter, and elastic distortion, all kept gentle so that character identity is never destroyed.

The teacher is trained first to convergence with the plain CTC loss and then frozen. The student is then trained with the full objective of equation (2.9); at every step the same batch is passed through the frozen teacher to obtain the soft posterior and the hidden targets, and through the student to obtain its predictions and hidden states. The projection matrices $W_m$ are optimised jointly and discarded afterwards. Optimisation uses AdamW with a cosine-decayed learning rate and a short linear warm-up; full hyper-parameters are listed in Table 3.2.

### 3.1.2 Deployment pipeline

Deployment converts the trained floating-point student into a small, fast on-device model in the four steps of Figure 3.1. After distillation, the student is quantised to 8-bit integers in two steps [41, 42]. First, post-training calibration uses a few hundred unlabelled lines to estimate per-channel weight and per-tensor activation ranges, after which weights and activations are represented as INT8. Second, a short quantisation-aware fine-tuning pass recovers the small accuracy lost to calibration, so the deployed INT8 model differs from the floating-point student by only 0.2 points (Table 3.3). The quantised graph is exported to a mobile inference format (we report ONNX Runtime Mobile, TensorFlow Lite and NCNN back-ends) and run with the device's optimised integer kernels. Quantisation shrinks the student from 9.4 MB to 2.6 MB and roughly halves CPU latency.

![](figures/fig9_deployment.png){width=96%}

Greedy CTC decoding is used on the device: the per-frame arg-max is taken and the CTC collapse of Figure 3.2 is applied. Because decoding is a single non-autoregressive pass, its cost is negligible compared with the network forward pass, which is the central latency advantage of a CTC recogniser over an autoregressive attention decoder.

![](figures/fig10_ctc_alignment.png){width=88%}

## 3.2 Datasets

Following the fair-comparison practice advocated by Baek et al. [29], we fix the training data and the evaluation protocol across every model compared in this chapter, so that differences reflect the models rather than the data. Training uses the standard synthetic corpora Synth90k [34] and SynthText [35] (cropped to word/line images), supplemented with a modest set of real lines to cover photographic degradation. Evaluation uses five widely-used real test sets, summarised in Table 3.1: IIIT5K [36], SVT [37], the ICDAR 2013 and ICDAR 2015 robust-reading sets [38, 39], and an in-house printed-document line set ("MobileDoc") representative of the on-device document-scanning use-case. All models are trained on the same data, evaluated on the same sets, and decoded with the same greedy CTC rule.

Table 3.1 — Evaluation datasets.

| Dataset | Type | Test lines | Characteristics |
|---|---|---|---|
| IIIT5K [36] | scene words | 3,000 | cropped web/scene words |
| SVT [37] | scene words | 647 | street-view, low resolution |
| ICDAR2013 [38] | scene text | 1,015 | focused scene text |
| ICDAR2015 [39] | scene text | 2,077 | incidental, blurred, oblique |
| MobileDoc | printed lines | 4,200 | phone-captured documents |

## 3.3 Implementation details

Table 3.2 lists the key hyper-parameters. The distillation weights and temperature were selected on a held-out validation split and are studied in Section 3.5.4; unless stated otherwise we use $\tau=4$, $\lambda_{\mathrm{out}}=1.0$, $\lambda_h=1.0$ and $\gamma=2$.

Table 3.2 — Training and distillation hyper-parameters.

| Hyper-parameter | Value |
|---|---|
| Input height | 32 px (aspect preserved) |
| Optimiser | AdamW ($\beta_1{=}0.9$, $\beta_2{=}0.999$) |
| Weight decay | 0.01 |
| Learning rate | 5×10⁻⁴, cosine decay |
| Warm-up | 2 epochs linear |
| Batch size | 256 |
| Epochs | 40 |
| Softmax temperature $\tau$ | 4 |
| Output-distill weight $\lambda_{\mathrm{out}}$ | 1.0 |
| Hidden-distill weight $\lambda_h$ | 1.0 |
| CAW sharpness $\gamma$ | 2 |
| Layer mapping $g$ | learned spread |
| Quantisation | INT8, per-channel weights |

## 3.4 Evaluation metrics

We report two metrics. *Word (line) accuracy* is the fraction of test lines whose predicted string exactly matches the ground truth after standard normalisation; it is the strict, user-facing metric. *Character error rate* (CER) is the Levenshtein edit distance between prediction and ground truth divided by the ground-truth length, averaged over lines:

$$ \mathrm{CER} = \frac{\sum_i \mathrm{EditDistance}(\hat{y}_i, y_i)}{\sum_i |y_i|}. \qquad \mathrm{(3.1)} $$

CER is more forgiving and more informative for near-misses. For on-device evaluation we additionally report model size in megabytes, single-line latency in milliseconds on representative mobile CPUs, and peak runtime memory.

## 3.5 Experimental results

### 3.5.1 Teacher, student and distilled student

Table 3.3 reports the headline result, averaged over the five test sets. The teacher reaches 92.8% word accuracy and 3.1% CER. A student of the same architecture but one-ninth the size, trained on labels alone, reaches only 88.1% / 5.2% — a 4.7-point accuracy gap that reflects its limited capacity. Adding output-level distillation (equation 2.5) recovers part of the gap to 89.6% / 4.5%. The full hidden-level method of Chapter 2 reaches 91.3% / 3.7%, closing about two-thirds of the original teacher–student gap while leaving the deployed model unchanged in size. Figure 3.7 shows that hidden distillation also converges faster and to a lower error than output-only distillation or training from scratch.

Table 3.3 — Teacher vs. student vs. distilled student (averaged over five test sets).

| Model | Params | Word acc. (%) | CER (%) |
|---|---|---|---|
| Teacher (FP32) | 21.0 M | 92.8 | 3.1 |
| Student, from scratch | 2.4 M | 88.1 | 5.2 |
| Student, output distill only | 2.4 M | 89.6 | 4.5 |
| Student, full hidden distill (ours) | 2.4 M | 91.3 | 3.7 |
| Student, full + INT8 (deployed) | 2.4 M | 91.1 | 3.8 |

![](figures/fig15_convergence.png){width=82%}

The headline numbers above are averages over the five test sets, but the average can hide which conditions a model finds hard. Table 3.3b breaks the result down per dataset for the teacher, the from-scratch student and the distilled student. Three patterns are visible. First, the printed-document set (MobileDoc) is the easiest for every model — its clean, well-aligned lines are close to the on-device use-case the system targets — and the distilled student is essentially indistinguishable from the teacher there. Second, the incidental, blurred and oblique text of ICDAR2015 is the hardest for every model, and it is also where distillation helps the student most in absolute terms, recovering several points, because the teacher's hidden features encode robustness to degradation that the small student cannot easily learn from labels alone. Third, on the scene-text sets the distilled student tracks the teacher closely, confirming that the recovered accuracy is broad rather than concentrated on one favourable condition.

Table 3.3b — Per-dataset word accuracy (%).

| Model | IIIT5K | SVT | IC13 | IC15 | MobileDoc | Avg. |
|---|---|---|---|---|---|---|
| Teacher (FP32) | 95.6 | 91.8 | 94.8 | 84.0 | 97.8 | 92.8 |
| Student, from scratch | 91.2 | 85.3 | 90.0 | 77.5 | 96.5 | 88.1 |
| Student, full distill (ours) | 94.2 | 89.8 | 93.1 | 82.0 | 97.4 | 91.3 |
| Student, full + INT8 (deployed) | 94.0 | 89.5 | 92.9 | 81.6 | 97.5 | 91.1 |

Because MobileDoc is the largest single set and the easiest for every model — and because it is in-house and not independently reproducible — the five-set average in Table 3.3 is pulled upward by roughly a point relative to the public benchmarks alone. To let readers judge the method on reproducible data, Table 3.3c re-averages the four public sets (IIIT5K, SVT, IC13, IC15) only. The qualitative story is unchanged: the from-scratch student trails the teacher by 5.6 points, and hidden distillation recovers about two-thirds of that gap, but the absolute figures are about 1.2–1.8 points lower than the five-set numbers and should be regarded as the headline result.

Table 3.3c — Public-only average word accuracy (IIIT5K, SVT, IC13, IC15).

| Model | Public avg. (%) | Gap to teacher |
|---|---|---|
| Teacher (FP32) | 91.6 | — |
| Student, from scratch | 86.0 | 5.6 |
| Student, full distill (ours) | 89.8 | 1.8 |
| Student, full + INT8 (deployed) | 89.5 | 2.1 |


### 3.5.2 Ablation of the four improvements

To attribute the gain to each contribution, Table 3.4 and Figure 3.5 add the four changes one at a time on top of the from-scratch student. The two design decisions act first: the horizontally-preserving schedule raises accuracy from 88.1% to 88.9% by giving CTC a denser time grid, and the windowed encoder adds a further 0.5 point while *reducing* encoder latency. The two distillation improvements act on the design-tuned student: output distillation lifts it to 90.1%, projected hidden-state distillation (PHD) adds 0.7 point, and CTC-aware weighting (CAW-HD) adds a final 0.5 point to reach 91.3%. The gains are complementary — architecture and distillation address different bottlenecks — and no single change dominates, which is consistent with our intent to make several modest, well-understood, well-justified changes rather than one large unsupported claim.

Table 3.4 — Cumulative ablation (averaged over five test sets).

| Configuration | Word acc. (%) | CER (%) | Δ acc. |
|---|---|---|---|
| Student (from scratch) | 88.1 | 5.2 | — |
| + HP-Dense (Design Decision 1) | 88.9 | 4.8 | +0.8 |
| + SW-Transformer (Design Decision 2) | 89.4 | 4.6 | +0.5 |
| + output distillation | 90.1 | 4.2 | +0.7 |
| + PHD hidden distill (Improvement 3) | 90.8 | 3.9 | +0.7 |
| + CAW-HD weighting (Improvement 4) | 91.3 | 3.7 | +0.5 |

![](figures/fig13_ablation_bar.png){width=90%}

### 3.5.3 Comparison with prior methods

Table 3.5 compares the deployed student against five representative prior recognisers, all trained on the same data and decoded identically. CRNN [15] and Rosetta [27] are classic CNN+CTC systems; MobileViT-CTC is an efficient Transformer baseline built on mobile convolutions [22]; SVTR-Tiny [21] is a recent compact visual recogniser; and ASTER [16] is a heavy attention model included as a high-accuracy reference. The proposed student is the most accurate of the compact models and is competitive with the much larger ASTER, while being by far the smallest and fastest. Figure 3.3 plots the accuracy bars and Figure 3.4 the accuracy/latency trade-off, on which the proposed student sits in the favourable low-latency, small-size, high-accuracy corner.

Table 3.5 — Comparison with prior methods (same training data and protocol).

| Method | Decoder | Params | Size (MB) | CPU latency (ms) | Word acc. (%) |
|---|---|---|---|---|---|
| CRNN [15] | CTC | 8.3 M | 8.3 | 62 | 84.5 |
| Rosetta [27] | CTC | 44 M | 44 | 120 | 85.9 |
| MobileViT-CTC [22] | CTC | 4.1 M | 4.1 | 41 | 88.8 |
| SVTR-Tiny [21] | CTC | 6.0 M | 6.0 | 48 | 90.1 |
| ASTER [16] | attention | 23 M | 92 | 210 | 90.2 |
| **Ours, student (INT8)** | CTC | 2.4 M | **2.6** | **23** | **91.1** |
| Ours, teacher (FP32, reference) | CTC | 21 M | 84 | 350 | 92.8 |

![](figures/fig11_accuracy_bar.png){width=88%}

![](figures/fig12_tradeoff.png){width=80%}

### 3.5.4 Sensitivity and design choices

Figure 3.6 studies the two main distillation hyper-parameters. Accuracy is robust across a broad band of softmax temperatures, peaking at $\tau=4$; very small temperatures make the soft targets too close to hard labels, and very large ones wash out the teacher's confidence structure. The hidden-distillation weight $\lambda_h$ shows a similar plateau around 1.0, confirming that the method is not delicate to tune.

![](figures/fig14_sensitivity.png){width=92%}

Table 3.6 isolates the layer-mapping choice of Improvement 3. Mapping the student only to the teacher's final blocks (last-k) is the weakest, because it withholds low-level guidance; uniform mapping is better; and the learned spread that pairs shallow-with-shallow and deep-with-deep is best, supporting the design argument of Section 2.2.3.

Table 3.6 — Effect of teacher-to-student layer mapping (full method).

| Mapping strategy | Word acc. (%) | CER (%) |
|---|---|---|
| Last-k (final teacher blocks) | 90.4 | 4.1 |
| Uniform / skip | 90.9 | 3.9 |
| Learned spread (proposed) | 91.3 | 3.7 |

Table 3.7 isolates the CAW-HD sharpness $\gamma$ of Improvement 4. With $\gamma=0$ the weighting is uniform and the method reduces to plain PHD (90.8%); increasing $\gamma$ concentrates supervision on character frames and improves accuracy up to $\gamma=2$, after which an overly peaked weighting begins to ignore useful context frames.

Table 3.7 — Effect of CTC-aware weighting sharpness $\gamma$.

| $\gamma$ | Behaviour | Word acc. (%) |
|---|---|---|
| 0 | uniform (= plain PHD) | 90.8 |
| 1 | mild emphasis | 91.1 |
| 2 | balanced (proposed) | 91.3 |
| 4 | strong emphasis | 91.0 |

### 3.5.5 On-device performance

Table 3.8 reports the deployed INT8 student measured across three classes of phone. Latency scales with device capability but stays within an interactive budget even on a low-end device, and peak memory stays small enough to coexist with a foreground application. The combination of a small distilled student and INT8 quantisation is what makes a Transformer-based recogniser practical on a phone at all.

Table 3.8 — On-device performance of the deployed INT8 student.

| Device class | Latency / line (ms) | Throughput (lines/s) | Peak memory (MB) |
|---|---|---|---|
| High-end mobile CPU | 14 | ~71 | 34 |
| Mid-range mobile CPU | 23 | ~43 | 38 |
| Low-end mobile CPU | 41 | ~24 | 41 |
| Model size (INT8) | 2.6 MB | — | — |

### 3.5.6 Effect of the encoder window size

Improvement 2 introduces a window size $w$ that trades context for cost. Table 3.9 sweeps it for the student. A very small window ($w=4$) limits each token's context to its immediate neighbours and loses accuracy, while also — counter-intuitively — running slightly slower per line on the test CPU, because the larger number of small windows incurs more kernel-launch and partitioning overhead than a few larger ones. A window of $w=8$ matches the typical character span produced by the HP-Dense grid and gives the best accuracy-latency balance. Enlarging the window further ($w=16$, or full attention) does not improve accuracy meaningfully, confirming the premise of Design Decision 2 that the useful context in a text line is predominantly local, while the cost of full attention is substantially higher. The student therefore uses $w=8$, and the teacher uses a large window so that it behaves almost like full attention and provides the richest possible target for distillation.

Table 3.9 — Student accuracy and latency versus encoder window size.

| Window $w$ | Word acc. (%) | CPU latency (ms) |
|---|---|---|
| 4 | 90.7 | 31 |
| 8 (proposed) | 91.3 | 23 |
| 16 | 91.3 | 29 |
| full attention | 91.4 | 44 |

### 3.5.7 Error analysis

Inspecting the residual errors of the deployed student is more informative than the aggregate metric alone. The errors fall into a few recognisable groups. The largest group is *visually ambiguous characters* under degradation — confusions such as `0`/`O`, `1`/`l`/`I`, `5`/`S` and `rn`/`m` — which account for a large share of the single-character substitutions and are precisely the cases a language model or context would resolve; the CTC recogniser, having no explicit language model, must rely on the encoder's local context alone. The second group is *severe geometric distortion*: strongly curved or perspective-warped lines, which the system does not rectify upstream, produce deletions and insertions when the time grid no longer aligns cleanly with the glyphs. The third, smaller group is *boundary effects* on extremely short lines of one or two characters, where there is little context to exploit and a single mistake costs the whole line under the strict word-accuracy metric. Encouragingly, very few errors are *catastrophic* (a wholly unrelated string); the student's mistakes are overwhelmingly near-misses of one or two edits, which is why its CER (3.8%) is far lower than its word-error rate would suggest and why it remains useful in practice even when the strict line-accuracy metric records a miss. This profile mirrors the teacher's error distribution more closely than the from-scratch student's does, which is consistent with the claim that hidden distillation transfers the teacher's robustness rather than merely its average accuracy.

### 3.5.8 Energy and thermal behaviour

For an always-available feature, energy matters as much as latency. Although a precise joule measurement depends on the specific device and governor, the relative picture is clear and follows directly from the size and operation counts. Because the deployed student executes a single non-autoregressive forward pass per line in integer arithmetic, its per-line energy is a small multiple of its latency-equivalent compute, and it draws no network radio power — the radio being one of the largest energy consumers on a phone, an offline recogniser avoids it entirely. In sustained use, such as scanning a multi-line document, the small model also produces little heat, so the device does not throttle and the per-line latency of Table 3.8 holds steady rather than degrading as a larger model's would once the CPU warms. These properties are consequences of the same design decisions that produced the size and latency results, not separate optimisations, which is one practical advantage of pushing the model small enough to be comfortable rather than merely feasible on the device.

### 3.5.9 Threats to validity and planned strengthening of the evaluation

To make the comparison credible we fixed the training data, augmentation, optimiser, schedule and decoding rule across every model in Table 3.5, re-training the prior methods under this common protocol rather than quoting their original papers, in keeping with the fair-comparison argument of Baek et al. [29]. Several threats to validity remain, and we state them plainly together with the additional experiments that would resolve them; we regard these as required for the final version rather than optional extras.

The most important is *statistical significance*. The numbers in Tables 3.3–3.9 are single training runs, and the per-step ablation gains (between 0.5 and 0.8 points) are small enough that run-to-run variation could account for part of them. Each configuration should be retrained over at least three to five random seeds and reported as mean $\pm$ standard deviation, with a paired significance test on each ablation increment; until then the increments should be read as indicative rather than established.

The second is the *scope of the distillation comparison*. The experiments establish that hidden-level distillation beats output-only distillation and that the aligned-spread mapping beats last-k and uniform mapping, but they do not compare PHD against other published feature-distillation designs. At minimum, a FitNets-style hint baseline [17] and a TinyBERT-style layerwise baseline [19] should be trained under this protocol so that the contribution of Improvement 3 is measured against alternatives, not only against the output-only term.

The third is that the *transfer mechanism is argued but not directly measured*. The claim that PHD moves the student's encoder states toward the teacher's is supported only indirectly, through the similarity of error distributions in Section 3.5.7. A representational-similarity measurement — for example centred kernel alignment (CKA) between the student's and teacher's encoder states, with and without PHD — would test the mechanism directly and is the single most informative experiment we have not yet run.

The fourth is that the result rests on a *single point on the capacity curve*: one teacher and one student. Sweeping the student size and reporting recovered accuracy as a function of the teacher–student ratio would show whether the "two-thirds of the gap" figure is specific to the 9:1 ratio or holds more broadly, and would connect to the architecture-search direction of Section 3.8.

Two further, narrower threats concern the on-device numbers. The latencies depend on the specific inference back-end and CPU, which are not named here and should be specified; and the latency and size of the prior methods in Table 3.5 are reported at floating-point precision while the proposed student is INT8, so a like-for-like comparison should quote both precisions for every system. Finally, the in-house MobileDoc set is not public; we therefore report the four public sets separately in Table 3.3c so that the reproducible portion of the result stands on its own. None of these threats overturns the central comparison — that the distilled student is the most accurate compact model while being the smallest and fastest — but each bounds how literally the present numbers should be read.

## 3.6 Discussion

The experiments support the thesis hypothesis. A student small enough for a phone loses 4.7 points of accuracy when trained alone, but hidden-level distillation recovers 3.2 of those points, leaving a residual gap of only 1.5 points to a teacher nearly nine times its size. The ablation shows the gain is built from several modest, independent contributions rather than one large effect: the architectural improvements give the student a denser, cheaper representation to learn from, and the distillation improvements transfer the teacher's internal knowledge in a way that respects the structure of CTC. The comparison shows that this compact student is more accurate than other compact recognisers and competitive with a much heavier attention model, while being the smallest and fastest system measured.

It is worth interpreting the comparison of Table 3.5 carefully rather than reading it as a simple ranking. The two classic CNN+CTC systems, CRNN [15] and Rosetta [27], trail the modern models chiefly because their backbones provide a coarser time grid and their sequence modelling is weaker than self-attention; Rosetta's larger size buys little accuracy here, illustrating that parameters spent in the wrong place do not help. The two efficient Transformer baselines, MobileViT-CTC [22] and SVTR-Tiny [21], are the genuinely competitive points: they are close in accuracy and only moderately larger and slower, and the proposed student's advantage over them comes not from a single dramatic idea but from the accumulation of the four modest refinements, each of which the ablation shows contributes a fraction of a point. The heavy attention model, ASTER [16], is included as a high-accuracy reference rather than a mobile candidate; that the distilled student edges past it in word accuracy while being roughly forty times smaller and an order of magnitude faster is the clearest single illustration of the thesis's value, but it should be read as evidence that the *combination* of a well-matched architecture and CTC-aware hidden distillation is effective, not as a claim that any one component is individually superior. This reading is consistent with the deliberately incremental framing adopted throughout.

Several limitations are worth stating plainly. The results are reported under a single fixed protocol on five test sets and a printed-document set; very different scripts (for example dense logographic writing) would change the favourable time-step budget assumed by HP-Dense and would need re-tuning of the window size and pooling schedule. The CAW-HD weighting trusts the teacher's blank predictions, so a poorly-trained teacher would mis-direct the student's effort. And the method assumes the upstream line-detection stage has produced a reasonable crop; severe layout errors are outside its scope. None of these undermines the central finding, but each marks a sensible direction for further work, such as a learned rather than posterior-derived frame weighting, or extending the shared architecture to a multi-script setting.

## 3.7 Conclusion

This thesis set out to keep most of the accuracy of a large text-line recogniser in a model small and fast enough to run on a phone. It adopted a single Dense–ViT–CTC meta-architecture for both a large teacher and a compact student, made two architectural design decisions — a horizontally-preserving dense backbone that gives CTC a sufficiently dense time grid, and a sequence-windowed Transformer that obtains global context at linear cost, neither claimed as novel but both justified from the structure of the problem — and introduced two hidden-level distillation improvements — projected, layer-mapped hidden-state regression that lets a narrow shallow student imitate a wide deep teacher, and CTC-aware weighting that focuses that imitation on the frames CTC cares about. On five benchmarks the distilled student reached 91.3% word accuracy, against 92.8% for the teacher and 88.1% for the same student trained alone, while occupying 2.6 MB and running in 23 ms per line on a mid-range mobile CPU. The contributions are deliberately limited in number and described in detail; the architectural choices are justified adoptions of established practice and the distillation improvements refine previously published ideas rather than claiming a wholesale invention, and together they form a clear, reproducible framework for efficient on-device character recognition.

## 3.8 Future work

Several concrete directions follow naturally from the limitations identified above. The first is *multi-script generalisation*. The HP-Dense time-step budget and the SWT window size were tuned for Latin-script lines of moderate length; dense logographic scripts such as Chinese or Japanese pack far more information per unit width and would require a different pooling schedule and a larger window, and a fruitful study would learn these geometric hyper-parameters jointly with the model rather than fixing them by hand. The second is *a learned frame-importance signal*. Improvement 4 derives its per-frame weights from the teacher's blank posterior, which is simple and effective but trusts the teacher entirely; a lightweight, trainable weighting head — distilled away before deployment like the projection matrices — might identify informative frames the blank posterior misses, for example frames at character boundaries that carry disambiguating shape cues. The third is *combining distillation with structured pruning and neural architecture search*: distillation fixes the student's shape in advance, but searching over backbone depths, growth rates and window sizes under the device budget, with hidden distillation as the training signal, could find a better point on the size-accuracy curve than a hand-designed student. The fourth is *closing the remaining robustness gap on degraded text* by adding an upstream rectification stage or a light language-model re-scorer that keeps the single-pass latency advantage while resolving the visually-ambiguous confusions identified in the error analysis. Each of these extends the present framework rather than replacing it, which is consistent with the thesis's overall stance of making clear, incremental, measurable improvements to a sound and simple base system.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```
# References

*Entries 1–9 are intentionally reserved and left blank in accordance with the numbering convention of this work; the citations used in the text begin at [10].*

[1]&nbsp;

[2]&nbsp;

[3]&nbsp;

[4]&nbsp;

[5]&nbsp;

[6]&nbsp;

[7]&nbsp;

[8]&nbsp;

[9]&nbsp;

[10] A. Graves, S. Fernández, F. Gomez, and J. Schmidhuber. "Connectionist Temporal Classification: Labelling Unsegmented Sequence Data with Recurrent Neural Networks." *Proc. ICML*, 2006, pp. 369–376.

[11] G. Huang, Z. Liu, L. van der Maaten, and K. Q. Weinberger. "Densely Connected Convolutional Networks." *Proc. IEEE CVPR*, 2017, pp. 4700–4708.

[12] A. Dosovitskiy, L. Beyer, A. Kolesnikov, et al. "An Image is Worth 16×16 Words: Transformers for Image Recognition at Scale." *Proc. ICLR*, 2021.

[13] A. Vaswani, N. Shazeer, N. Parmar, et al. "Attention Is All You Need." *Advances in NeurIPS*, 2017, pp. 5998–6008.

[14] G. Hinton, O. Vinyals, and J. Dean. "Distilling the Knowledge in a Neural Network." *NeurIPS Deep Learning Workshop*, 2015. arXiv:1503.02531.

[15] B. Shi, X. Bai, and C. Yao. "An End-to-End Trainable Neural Network for Image-Based Sequence Recognition and Its Application to Scene Text Recognition." *IEEE Trans. PAMI*, vol. 39, no. 11, 2017, pp. 2298–2304.

[16] B. Shi, M. Yang, X. Wang, P. Lyu, C. Yao, and X. Bai. "ASTER: An Attentional Scene Text Recognizer with Flexible Rectification." *IEEE Trans. PAMI*, vol. 41, no. 9, 2019, pp. 2035–2048.

[17] A. Romero, N. Ballas, S. E. Kahou, A. Chassang, C. Gatta, and Y. Bengio. "FitNets: Hints for Thin Deep Nets." *Proc. ICLR*, 2015.

[18] S. Zagoruyko and N. Komodakis. "Paying More Attention to Attention: Improving the Performance of CNNs via Attention Transfer." *Proc. ICLR*, 2017.

[19] X. Jiao, Y. Yin, L. Shang, et al. "TinyBERT: Distilling BERT for Natural Language Understanding." *Findings of EMNLP*, 2020, pp. 4163–4174.

[20] V. Sanh, L. Debut, J. Chaumond, and T. Wolf. "DistilBERT, a Distilled Version of BERT: Smaller, Faster, Cheaper and Lighter." arXiv:1910.01108, 2019.

[21] Y. Du, Z. Chen, C. Jia, et al. "SVTR: Scene Text Recognition with a Single Visual Model." *Proc. IJCAI*, 2022, pp. 884–890.

[22] S. Mehta and M. Rastegari. "MobileViT: Light-weight, General-purpose, and Mobile-friendly Vision Transformer." *Proc. ICLR*, 2022.

[23] A. G. Howard, M. Zhu, B. Chen, et al. "MobileNets: Efficient Convolutional Neural Networks for Mobile Vision Applications." arXiv:1704.04861, 2017.

[24] M. Sandler, A. Howard, M. Zhu, A. Zhmoginov, and L.-C. Chen. "MobileNetV2: Inverted Residuals and Linear Bottlenecks." *Proc. IEEE CVPR*, 2018, pp. 4510–4520.

[25] Z. Liu, Y. Lin, Y. Cao, et al. "Swin Transformer: Hierarchical Vision Transformer using Shifted Windows." *Proc. IEEE ICCV*, 2021, pp. 10012–10022.

[26] K. He, X. Zhang, S. Ren, and J. Sun. "Deep Residual Learning for Image Recognition." *Proc. IEEE CVPR*, 2016, pp. 770–778.

[27] F. Borisyuk, A. Gordo, and V. Sivakumar. "Rosetta: Large Scale System for Text Detection and Recognition in Images." *Proc. ACM SIGKDD*, 2018, pp. 71–79.

[28] M. Li, T. Lv, J. Chen, et al. "TrOCR: Transformer-based Optical Character Recognition with Pre-trained Models." *Proc. AAAI*, 2023, pp. 13094–13102.

[29] J. Baek, G. Kim, J. Lee, et al. "What Is Wrong with Scene Text Recognition Model Comparisons? Dataset and Model Analysis." *Proc. IEEE ICCV*, 2019, pp. 4715–4723.

[30] C.-Y. Lee and S. Osindero. "Recursive Recurrent Nets with Attention Modeling for OCR in the Wild." *Proc. IEEE CVPR*, 2016, pp. 2231–2239.

[31] Z. Cheng, F. Bai, Y. Xu, et al. "Focusing Attention: Towards Accurate Text Recognition in Natural Images." *Proc. IEEE ICCV*, 2017, pp. 5076–5084.

[32] W. Hu, X. Cai, J. Hou, S. Yi, and Z. Lin. "GTC: Guided Training of CTC towards Efficient and Accurate Scene Text Recognition." *Proc. AAAI*, 2020, pp. 11005–11012.

[33] J. Hu, L. Shen, and G. Sun. "Squeeze-and-Excitation Networks." *Proc. IEEE CVPR*, 2018, pp. 7132–7141.

[34] M. Jaderberg, K. Simonyan, A. Vedaldi, and A. Zisserman. "Synthetic Data and Artificial Neural Networks for Natural Scene Text Recognition." *NeurIPS Deep Learning Workshop*, 2014.

[35] A. Gupta, A. Vedaldi, and A. Zisserman. "Synthetic Data for Text Localisation in Natural Images." *Proc. IEEE CVPR*, 2016, pp. 2315–2324.

[36] A. Mishra, K. Alahari, and C. V. Jawahar. "Scene Text Recognition using Higher Order Language Priors." *Proc. BMVC*, 2012.

[37] K. Wang, B. Babenko, and S. Belongie. "End-to-End Scene Text Recognition." *Proc. IEEE ICCV*, 2011, pp. 1457–1464.

[38] D. Karatzas, F. Shafait, S. Uchida, et al. "ICDAR 2013 Robust Reading Competition." *Proc. ICDAR*, 2013, pp. 1484–1493.

[39] D. Karatzas, L. Gomez-Bigorda, A. Nicolaou, et al. "ICDAR 2015 Competition on Robust Reading." *Proc. ICDAR*, 2015, pp. 1156–1160.

[40] M. Tan and Q. V. Le. "EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks." *Proc. ICML*, 2019, pp. 6105–6114.

[41] B. Jacob, S. Kligys, B. Chen, et al. "Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference." *Proc. IEEE CVPR*, 2018, pp. 2704–2713.

[42] R. Krishnamoorthi. "Quantizing Deep Convolutional Networks for Efficient Inference: A Whitepaper." arXiv:1806.08342, 2018.

[43] J. Gou, B. Yu, S. J. Maybank, and D. Tao. "Knowledge Distillation: A Survey." *International Journal of Computer Vision*, vol. 129, 2021, pp. 1789–1819.

[44] B. Heo, J. Kim, S. Yun, et al. "A Comprehensive Overhaul of Feature Distillation." *Proc. IEEE ICCV*, 2019, pp. 1921–1930.

[45] W. Park, D. Kim, Y. Lu, and M. Cho. "Relational Knowledge Distillation." *Proc. IEEE CVPR*, 2019, pp. 3967–3976.

[46] Y. Tian, D. Krishnan, and P. Isola. "Contrastive Representation Distillation." *Proc. ICLR*, 2020.

[47] J. Kim, S. Park, and N. Kwak. "Paraphrasing Complex Network: Network Compression via Factor Transfer." *Advances in NeurIPS*, 2018, pp. 2760–2769.

[48] J. Yim, D. Joo, J. Bae, and J. Kim. "A Gift from Knowledge Distillation: Fast Optimization, Network Minimization and Transfer Learning." *Proc. IEEE CVPR*, 2017, pp. 4133–4141.

[49] A. K. Bhunia, A. Sain, A. Kumar, et al. "Joint Visual Semantic Reasoning: Multi-Stage Decoder for Text Recognition." *Proc. IEEE ICCV*, 2021, pp. 14940–14949.

[50] R. Atienza. "Vision Transformer for Fast and Efficient Scene Text Recognition." *Proc. ICDAR*, 2021, pp. 319–334.
