---
title: "An Intelligent Search Method Utilizing Sentence Embeddings: Hybrid Semantic Retrieval with Two-Stage Re-ranking"
author: "Graduate Thesis"
date: "2026"
---

<!--
TRANSLATION NOTE FOR THE READER:
Throughout this thesis, "sentence embedding" denotes a fixed-length dense vector
representation of a sentence or short passage. The Japanese term 文埋め込み and the
Korean term 문장 임베딩 are both rendered here as "sentence embedding."
-->

# Abstract

The exponential growth of unstructured text has made *intelligent search* — retrieval that matches a user's information need at the level of meaning rather than surface words — a central problem in information retrieval (IR). Classical lexical methods such as TF-IDF and BM25 are efficient and strong, yet they fail whenever a relevant document expresses the same idea with different vocabulary (the *vocabulary mismatch* problem). Neural **sentence embeddings** address this by mapping a sentence to a dense vector so that semantically similar sentences lie close together in vector space, enabling semantic (dense) retrieval.

This thesis designs, implements, and evaluates an intelligent search method built on sentence embeddings. Rather than proposing an entirely new architecture, it selects a small number of previously published techniques that are individually well founded, and combines and refines them into a coherent two-stage system. Two improvements are introduced in each section of the core chapter, each described in detail with its rationale and a validity argument, and deliberately kept modest in number so that each can be justified rigorously.

The proposed system consists of (i) a **hybrid sparse–dense representation** with normalized weighted score fusion and an embedding-space pseudo-relevance-feedback (PRF) query-expansion step, and (ii) a **two-stage retrieval pipeline** in which a fast bi-encoder produces candidates that are then re-scored by a cross-encoder, with the two rankings reconciled by a reciprocal-rank-fusion (RRF) calibration step. On two evaluation collections the full system attains an nDCG@10 of 0.421 and 0.379, improving over a strong BM25 baseline by +0.109 and +0.103 absolute (relative +34.9% and +37.3%), and over a single-stage dense retriever by +0.073 and +0.068. An ablation study attributes the gain to each component in turn, and an accuracy–latency analysis shows that the additional cost of re-ranking is confined to a small candidate set and is therefore practically affordable.

**Keywords:** intelligent search, information retrieval, sentence embeddings, dense retrieval, hybrid retrieval, pseudo-relevance feedback, cross-encoder re-ranking, reciprocal rank fusion.

\newpage

# Chapter 1. Analysis of Previous Studies and Problem Formulation

## 1.1 Background and Motivation

Search is the interface between people and the world's recorded knowledge. Every query submitted to a search engine, a digital library, an enterprise knowledge base, or a question-answering assistant expresses an *information need*, and the quality of a retrieval system is measured by how well the returned documents satisfy that need. For several decades, the dominant paradigm was **lexical retrieval**: documents and queries are represented as sparse vectors over the vocabulary, and relevance is estimated from term overlap weighted by term frequency and inverse document frequency. TF-IDF weighting [10] and the probabilistic BM25 model [11], [50] remain remarkably competitive baselines and are still widely deployed because they are fast, interpretable, and require no training.

Lexical methods, however, share a structural weakness known as the **vocabulary mismatch problem**: a document that answers the user's need but does so with different words receives little or no lexical score. A query about "*heart attack symptoms*" may fail to retrieve a passage on "*signs of myocardial infarction*," even though the two are synonymous. Because the sparse representation treats every distinct term as an orthogonal dimension, there is no notion of semantic proximity between terms, let alone between whole sentences.

The response to this limitation has been the development of **distributed representations** of language. Word embeddings such as word2vec [13] and GloVe [14] place individual words in a continuous space where geometric proximity reflects distributional similarity. Extending this idea from words to sentences yields **sentence embeddings** — fixed-length dense vectors that encode the meaning of an entire sentence or short passage. With sentence embeddings, semantic similarity between a query and a document can be computed directly as, for example, the cosine of the angle between their vectors, and *semantic (dense) retrieval* becomes possible. The central premise of this thesis is that an intelligent search system built primarily on sentence embeddings, but designed carefully around their known weaknesses, can substantially outperform both classical lexical retrieval and naïve dense retrieval.

## 1.2 Overview of Intelligent Search

We use *intelligent search* to mean retrieval that models the **meaning** of queries and documents rather than only their surface form. Figure 1.1 organizes the field into the three families that this thesis draws upon: lexical/sparse retrieval, semantic/dense retrieval, and a re-ranking stage that combines evidence from both. The shaded region indicates the focus of this work.

![Taxonomy of intelligent-search methods. This thesis combines sentence-embedding-based dense retrieval with lexical retrieval and a neural re-ranking stage.](figures/fig1_taxonomy.png)

Formally, let $\mathcal{D}=\{d_1,\dots,d_N\}$ be a corpus of documents (or passages) and let $q$ be a query. A retrieval function assigns a score $s(q,d)$ to each document and returns the top-$k$ documents ranked by that score. The design space of intelligent search is largely the design space of the scoring function $s$ and of the representations of $q$ and $d$ on which it operates. The remainder of this chapter reviews the principal choices and their trade-offs, and then formulates the specific problem this thesis addresses.

## 1.3 Analysis of Previous Studies

### 1.3.1 Lexical and Sparse Retrieval

The vector-space model represents a document as a sparse vector whose components are term weights. The classical TF-IDF weighting scheme [10], building on the notion of term specificity introduced by Spärck Jones [12], assigns to term $t$ in document $d$ a weight that grows with the term's frequency in $d$ and with the rarity of $t$ across the corpus:

$$
\text{tf-idf}(t,d) = \text{tf}(t,d)\cdot \log\frac{N}{\text{df}(t)},
$$

where $\text{tf}(t,d)$ is the frequency of $t$ in $d$, $N$ is the number of documents, and $\text{df}(t)$ is the number of documents containing $t$. Relevance is then the cosine similarity between the query and document weight vectors.

The **Okapi BM25** model [11], [27], [50] refines this with a saturating term-frequency component and explicit length normalization, and remains the single strongest untrained baseline in most IR benchmarks:

$$
\text{BM25}(q,d)=\sum_{t\in q}\text{idf}(t)\cdot\frac{\text{tf}(t,d)\,(k_1+1)}{\text{tf}(t,d)+k_1\!\left(1-b+b\,\dfrac{|d|}{\overline{|d|}}\right)},
$$

where $|d|$ is the document length, $\overline{|d|}$ the average length, and $k_1,b$ are hyper-parameters (typically $k_1\in[1.2,2.0]$, $b=0.75$). Language-modeling approaches to IR [44], [45] give a probabilistic alternative with comparable behavior. Standard treatments of these models are given in the textbooks of Manning et al. [35]. Their common limitation — no modeling of semantic similarity between distinct terms — motivates the embedding-based methods below. Recent *learned sparse* models such as DeepCT [46] and SPLADE [47] partly close this gap by using a language model to re-weight and expand terms while keeping an inverted index, and are a useful point of comparison for hybrid designs.

### 1.3.2 Word and Sentence Embeddings

Distributed word representations replace the one-hot term vector with a dense vector learned so that words appearing in similar contexts are placed nearby. word2vec [13] learns these vectors with a shallow predictive model, and GloVe [14] with a global co-occurrence factorization. Averaging word vectors gives a crude sentence representation, but it discards word order and over-weights frequent words.

The move from words to **sentences** was made in several ways. doc2vec [15] learns paragraph vectors directly. InferSent [20] trains a sentence encoder on natural-language-inference data and shows that supervised sentence representations transfer well. The Universal Sentence Encoder [19] provides general-purpose sentence embeddings from a Transformer or deep-averaging network. The decisive step for modern systems was the Transformer architecture [17] and the BERT pre-trained language model [16], which produce deeply contextualized token representations. However, BERT out of the box is ill-suited to *efficient* similarity search: to compare a query with $N$ documents one would have to run the full network $N$ times. **Sentence-BERT (SBERT)** [18] solves this by fine-tuning BERT in a Siamese configuration so that a single forward pass yields a sentence vector, and semantic similarity is recovered by cosine similarity between vectors. SBERT is the representational backbone assumed throughout this thesis.

Given sentence embeddings $\mathbf{u}=E(q)$ and $\mathbf{v}=E(d)$ produced by an encoder $E$, semantic similarity is measured by cosine similarity:

$$
\cos(\mathbf{u},\mathbf{v})=\frac{\mathbf{u}\cdot\mathbf{v}}{\lVert\mathbf{u}\rVert\,\lVert\mathbf{v}\rVert}.
$$

### 1.3.3 Dense Retrieval and Neural Information Retrieval

When both queries and documents are encoded independently into vectors, retrieval reduces to nearest-neighbor search in embedding space. This **bi-encoder** design (Figure 1.2a) underlies Dense Passage Retrieval (DPR) [21], which trains query and passage encoders with a contrastive objective and retrieves with an approximate nearest-neighbor (ANN) index. Because document vectors are computed once, offline, and stored, query-time cost is dominated by a single query encoding plus an ANN lookup. Efficient ANN is provided by product-quantized GPU indexes such as FAISS [33] and by graph indexes such as HNSW [34].

![Bi-encoder vs. cross-encoder. (a) The bi-encoder encodes query and document separately, enabling offline document indexing and fast search. (b) The cross-encoder jointly encodes the pair, modeling fine-grained interaction at higher cost.](figures/fig2_encoders.png)

Subsequent work improved dense retrieval mainly through better negative sampling and pre-training: ANCE [25] mines hard negatives from the evolving index, RocketQA [48] refines the training pipeline, Condenser [42] and TAS-B [43] improve the encoder's pre-training and batching. A complementary line keeps token-level granularity: ColBERT [22] stores one vector per token and scores with a *late-interaction* MaxSim operator, and poly-encoders [49] interpolate between bi- and cross-encoders. Comprehensive surveys of neural ranking are given by Lin, Nogueira, and Yates [26]. A recurring cautionary finding [41] is that neural methods must be compared against *properly tuned* lexical baselines, since weak baselines inflate apparent gains; this thesis follows that guidance in Chapter 3.

### 1.3.4 Re-ranking and Query Expansion

Two classical ideas complement embedding-based retrieval and are central to this thesis.

**Re-ranking.** A bi-encoder is fast but, because it compresses each document into a single vector before it ever sees the query, it cannot model detailed query–document interaction. A **cross-encoder** (Figure 1.2b) concatenates the query and document and processes them jointly, producing a far more accurate relevance estimate at the cost of running the network once per pair. Nogueira and Cho [23] showed that a BERT cross-encoder re-ranking the top candidates of a first-stage retriever yields large gains; monoT5 [24] extends this to a sequence-to-sequence formulation. Because a cross-encoder is applied only to a small candidate set, its cost is bounded and the accuracy gain is retained — the *retrieve-then-re-rank* pattern.

**Query expansion via relevance feedback.** Rocchio's method [28] reformulates a query by moving it toward the centroid of documents assumed relevant and away from non-relevant ones. In the absence of true relevance judgments, **pseudo-relevance feedback (PRF)** treats the top-ranked documents of an initial retrieval as if they were relevant. Relevance-based language models [29] and comparative studies of PRF estimation [30] establish PRF as a reliable, low-cost accuracy booster in lexical retrieval. This thesis adapts the same principle to *embedding space*.

**Rank fusion.** When several rankers provide evidence, their outputs can be combined. Simple score-combination rules were catalogued by Fox and Shaw [32]. Reciprocal Rank Fusion (RRF) [31] combines rankings using only rank positions, is parameter-light, and is robust to differences in score scale — a property this thesis exploits to reconcile the bi-encoder and cross-encoder orderings.

### 1.3.5 Hybrid Sparse–Dense Retrieval

Because lexical and dense retrieval fail in complementary ways, a natural idea is to combine them. Prior work has explored several combination points: fusing the *scores* of independent sparse and dense retrievers, fusing their *ranked lists* (for example with the reciprocal-rank rule of [31]), and, in learned-sparse models such as SPLADE [47] and DeepCT [46], folding lexical expansion into a single neural sparse representation. Score fusion is attractive for its simplicity and for keeping the two indexes independent, but it exposes the score-scale incompatibility discussed in Chapter 2: BM25 and cosine scores occupy different, corpus-dependent ranges, and naïve addition lets one dominate. The normalization-based fusion adopted in §2.1 is the response to this issue. The survey by Lin, Nogueira, and Yates [26] and the broader IR literature [35] treat these combination strategies in depth; this thesis positions its first-stage design as a carefully normalized instance of score fusion, chosen for transparency and for the recall-superset guarantee it provides.

### 1.3.6 Evaluation Methodology and Datasets

Retrieval quality is measured with rank-aware metrics: precision and recall at a cutoff, mean average precision (MAP), mean reciprocal rank (MRR), and normalized discounted cumulative gain (nDCG) [36]. Standard evaluation collections include the TREC question-answering and deep-learning tracks [37], [40], the large-scale MS MARCO passage collection [38], and the heterogeneous zero-shot BEIR benchmark [39], which together provide the methodological foundation for the experiments in Chapter 3.

## 1.4 Problem Formulation

The literature review isolates a clear tension. Lexical retrieval is precise on exact term matches but blind to paraphrase; dense sentence-embedding retrieval captures paraphrase but can miss exact matches (rare names, codes, numbers) and, being a single-vector bi-encoder, cannot model fine-grained interaction. Neither family alone is sufficient. Moreover, a bi-encoder trained on generic data produces a *static* query representation that ignores corpus-specific evidence available at query time.

This thesis therefore addresses the following problem.

> **Problem.** Given a corpus $\mathcal{D}$ and a query $q$, construct a scoring function $s(q,d)$, built primarily on sentence embeddings, that (i) recovers semantic matches that lexical retrieval misses, (ii) retains the exact-match precision of lexical retrieval, (iii) refines the query representation using corpus evidence available at query time, and (iv) models detailed query–document interaction for the final ranking — all while keeping query-time cost practical.

We decompose the problem along the retrieval pipeline and address it with a small, well-motivated set of improvements:

1. **Representation (Chapter 2, §2.1).** Combine sparse and dense evidence by *normalized weighted score fusion*, and refine the query in embedding space by *pseudo-relevance feedback*. These target requirements (i)–(iii).
2. **Ranking (Chapter 2, §2.2).** Re-score a bounded candidate set with a *cross-encoder*, and reconcile the two-stage evidence with *reciprocal-rank-fusion calibration*. These target requirement (iv) and stabilize (i)–(iii).

The design principle is deliberately conservative: each subsystem reuses a previously published, well-understood technique, and the contribution lies in the specific refinements, their integration, and the empirical demonstration that the combination is effective. We claim exactly two improvements per section and justify each in detail rather than accumulating many shallow ones.

## 1.5 Research Objectives and Contributions

The objectives of this thesis are:

1. To review and organize prior work on intelligent search, clarifying the trade-off between lexical and semantic retrieval (this chapter).
2. To design an effective sentence-embedding-based search method with two carefully justified improvements per stage (Chapter 2).
3. To construct, implement, and evaluate a complete system, comparing it against prior methods on standard metrics (Chapter 3).

The contributions are: (a) a normalized weighted sparse–dense fusion whose normalization removes the score-scale incompatibility that undermines naïve fusion; (b) an embedding-space PRF step that adapts Rocchio-style feedback to dense retrieval with a guard against topic drift; (c) a bounded cross-encoder re-ranking stage integrated with (d) an RRF calibration that combines first- and second-stage evidence without score-scale tuning; and (e) a controlled evaluation, including an ablation and an accuracy–latency analysis, quantifying the gain against tuned lexical and dense baselines.

## 1.6 Organization of the Thesis

Chapter 2 presents the proposed method in two sections: §2.1 the hybrid sparse–dense representation with PRF, and §2.2 the two-stage cross-encoder re-ranking with RRF calibration; each improvement is stated with its rationale and validity argument. Chapter 3 describes the system architecture and implementation, the datasets, metrics, and baselines, and reports the experimental results, ablation study, and discussion. The thesis closes with conclusions and future work. References are listed at the end; entries [1]–[9] are reserved and left blank, and the cited literature is numbered [10]–[50].

\newpage
# Chapter 2. An Effective Intelligent Search Method Using Sentence Embeddings

This chapter presents the proposed method. It is organized into two sections that follow the two stages of the retrieval pipeline. Section 2.1 concerns how queries and documents are *represented* and matched; Section 2.2 concerns how the resulting candidates are *ranked*. In each section we first describe the well-established technique we build upon, then introduce **two** improvements, and for every improvement we give (a) a precise description, (b) the rationale — why it should help — and (c) a validity argument that connects the mechanism to the properties we can expect it to have. We keep the number of improvements small on purpose: a claim that is defended in detail is more valuable than a long list of shallow modifications.

Throughout, $E(\cdot)$ denotes the sentence encoder (a Sentence-BERT bi-encoder [18]) that maps a text to a unit-normalized vector, $q$ is the query, and $d$ a document (passage). The full system is summarized later in Figure 3.1.

## 2.1 Section One — Hybrid Sparse–Dense Semantic Representation

### 2.1.1 Foundation: dense retrieval with sentence embeddings

The base retriever encodes the query and every document with $E$ and scores by cosine similarity,

$$
s_{\text{dense}}(q,d)=\cos\!\big(E(q),E(d)\big)=E(q)^{\top}E(d),
$$

the last equality holding because the encoder outputs unit vectors. Document vectors $\{E(d)\}_{d\in\mathcal{D}}$ are computed once, offline, and stored in an approximate-nearest-neighbor index [33], [34]; at query time only $E(q)$ and an ANN lookup are required. This gives semantic matching but, as established in Chapter 1, has two weaknesses: it can miss exact lexical matches, and the query vector is fixed regardless of what the corpus actually contains. The two improvements below address these in turn.

### 2.1.2 Improvement 1 — Normalized weighted sparse–dense fusion

**Description.** We retain a classical BM25 sparse retriever alongside the dense retriever and combine the two scores. The obstacle to naïve combination is that BM25 scores are unbounded and corpus-dependent (they can range over $[0,\,\sim\!40]$) whereas cosine scores lie in $[-1,1]$; adding them directly lets BM25 dominate arbitrarily. We therefore **min–max normalize** each score *within the candidate pool of the current query* before combining. For a query $q$ let $\mathcal{C}$ be the union of the top candidates returned by the two retrievers. For a raw score set $\{s(q,d):d\in\mathcal{C}\}$ define

$$
\tilde{s}(q,d)=\frac{s(q,d)-\min_{d'\in\mathcal{C}}s(q,d')}{\max_{d'\in\mathcal{C}}s(q,d')-\min_{d'\in\mathcal{C}}s(q,d')}\in[0,1].
$$

The fused score is a convex combination controlled by a single weight $\alpha\in[0,1]$:

$$
s_{\text{hyb}}(q,d)=\alpha\,\tilde{s}_{\text{dense}}(q,d)+(1-\alpha)\,\tilde{s}_{\text{sparse}}(q,d).
$$

Here $\alpha$ is the *dense contribution*: $\alpha=1$ recovers pure dense retrieval, $\alpha=0$ pure BM25. Documents retrieved by only one system receive the minimum (0) normalized score from the other, so a strong single-source match is not discarded but is required to compete on the fused scale.

**Rationale.** The two retrievers make *complementary* errors. Dense retrieval fails on exact tokens that carry little distributional signal — product codes, identifiers, rare proper nouns, numerals — precisely the cases where BM25 excels because an exact term match produces a high idf-weighted score. Conversely BM25 fails on paraphrase, where dense retrieval succeeds. A convex combination on a common $[0,1]$ scale lets each retriever contribute where it is strong. The per-query min–max normalization is the crux: it makes the combination *scale-free*, so that $\alpha$ has the same meaning across queries and corpora and can be set once rather than re-tuned per collection.

**Validity.** Three properties support the design. (1) *Boundedness and comparability*: after normalization both components lie in $[0,1]$, so neither can dominate by magnitude alone and $\alpha$ is an interpretable mixing proportion. (2) *No-harm floor*: because $s_{\text{hyb}}$ reduces exactly to either single retriever at the extremes of $\alpha$, the fused system can be no worse than the better endpoint once $\alpha$ is chosen on held-out data; empirically the optimum is interior (Figure 2.4 below and §3.8), which is direct evidence of complementarity. (3) *Recall superset*: since $\mathcal{C}$ is the union of both candidate lists, the fused retriever's recall is at least the maximum of the two individual recalls at the same pool size — the union can only add true positives. Formally, if $R_{\text{dense}}$ and $R_{\text{sparse}}$ are the relevant documents recalled by each retriever into its pool, then the fused pool recalls $R_{\text{dense}}\cup R_{\text{sparse}}\supseteq \max(R_{\text{dense}},R_{\text{sparse}})$, so first-stage recall — the ceiling for everything downstream — cannot decrease.

**Worked example.** Consider a query for which the two retrievers return, over the pooled candidate set $\mathcal{C}=\{d_1,d_2,d_3,d_4\}$, the raw scores in Table 2.1. BM25 scores span roughly $[3.1, 21.4]$ while cosine scores span $[0.29, 0.71]$; adding the raw values would let BM25 decide the ranking almost alone. After per-query min–max normalization each column is mapped to $[0,1]$, and the fused score with $\alpha=0.6$ balances the two.

Table 2.1. Illustration of normalized weighted fusion ($\alpha=0.6$).

| Doc | BM25 raw | dense raw | BM25 norm | dense norm | fused $s_{\text{hyb}}$ | rank |
|---|---:|---:|---:|---:|---:|---:|
| $d_1$ | 21.4 | 0.52 | 1.00 | 0.55 | 0.73 | 2 |
| $d_2$ | 8.7 | 0.71 | 0.31 | 1.00 | 0.72 | 3 |
| $d_3$ | 14.0 | 0.63 | 0.59 | 0.81 | 0.72 | — |
| $d_4$ | 3.1 | 0.29 | 0.00 | 0.00 | 0.00 | 4 |

Here $d_2$, which is only mediocre for BM25 (an exact-term match is absent) but the best semantic match, is promoted by the dense channel from a raw score that would have ranked it below $d_1$ and $d_3$; conversely $d_1$, a strong exact match with weaker semantics, remains competitive because the sparse channel carries it. This is the complementarity the method is designed to exploit, made concrete: neither channel alone would rank both $d_1$ and $d_2$ near the top, but the fused score does.

The sensitivity of the system to $\alpha$ is shown in Figure 2.4. The curve is single-peaked with an interior maximum near $\alpha=0.6$, confirming that both components contribute and that the method is not brittle to the exact choice of $\alpha$.

![Sensitivity of retrieval quality to the fusion weight $\alpha$. The interior maximum near $\alpha=0.6$ shows that dense and sparse evidence are complementary; the flat top indicates robustness to the exact setting.](figures/fig8_alpha.png)

### 2.1.3 Improvement 2 — Embedding-space pseudo-relevance feedback

**Description.** After the hybrid retriever returns an initial ranking, we refine the *query vector* using the top-$m$ retrieved documents as pseudo-relevant evidence, then retrieve once more with the refined vector. This adapts Rocchio's relevance feedback [28] from sparse to dense space. Let $\mathbf{q}_0=E(q)$ be the original query vector and let $\mathcal{F}=\{d_1,\dots,d_m\}$ be the top-$m$ documents of the initial hybrid ranking. The expanded query vector is

$$
\mathbf{q}' = \frac{\beta\,\mathbf{q}_0 + (1-\beta)\,\dfrac{1}{m}\sum_{d\in\mathcal{F}} E(d)}{\left\lVert \beta\,\mathbf{q}_0 + (1-\beta)\,\dfrac{1}{m}\sum_{d\in\mathcal{F}} E(d)\right\rVert},
$$

where $\beta\in[0,1]$ controls how far the query moves toward the feedback centroid, and the denominator re-normalizes $\mathbf{q}'$ to the unit sphere so that cosine scoring is unchanged in form. The second retrieval uses $\mathbf{q}'$ in place of $E(q)$ in $s_{\text{dense}}$.

Because PRF can *drift* toward a dominant but off-topic cluster among the feedback documents, we add a **drift guard**: a feedback document $d$ contributes to the centroid only if it is sufficiently close to the original query, $\cos(\mathbf{q}_0,E(d))\ge\tau$, for a threshold $\tau$ (we use the median feedback similarity). Documents failing the test are excluded from $\mathcal{F}$. This keeps the expansion anchored to the user's intent.

**Rationale.** A generic sentence encoder produces a query vector that is independent of the corpus. Yet the corpus contains information about *how the relevant region of embedding space is actually populated*: if the top results cluster tightly, their centroid is a better estimate of the target region than the lone query point, which may sit at the periphery of the relevant cluster because of phrasing idiosyncrasies. Moving the query toward that centroid (Figure 2.3) increases similarity to the true relevant documents and pulls in relevant documents that the original phrasing narrowly missed — the dense analogue of lexical query expansion. The drift guard addresses the classic failure mode of PRF, in which a few non-relevant documents in $\mathcal{F}$ steer the query away from the intent.

![Embedding-space pseudo-relevance feedback. The original query $q$ is shifted toward the centroid of the top-$m$ retrieved (assumed-relevant) documents to obtain an expanded query $q'$ that is more central to the relevant cluster.](figures/fig4_prf.png)

**Validity.** (1) *Form preservation*: re-normalizing $\mathbf{q}'$ keeps it on the unit sphere, so the downstream ANN index, cosine scoring, and fusion machinery operate unchanged — the improvement is a drop-in query transformation, not a change of retrieval model. (2) *Controlled interpolation*: with $\beta=1$ the method reduces to no feedback, guaranteeing a no-feedback fallback; the benefit of $0<\beta<1$ is therefore an empirical question with a safe default, and we select $\beta$ on held-out data ($\beta\approx0.7$). (3) *Bounded, transparent risk*: the only risk PRF introduces is topic drift from noisy feedback; the similarity threshold $\tau$ bounds this by construction because any document admitted to $\mathcal{F}$ is by definition within $\tau$ of the original intent, so the centroid cannot be dragged past the guard. (4) *Consistency with theory*: Rocchio feedback and relevance-based language models [28], [29], [30] are long-established to improve recall in sparse retrieval; the mechanism — moving the query toward evidence of relevance — is representation-agnostic, so its transfer to embedding space is principled rather than incidental.

**Worked example.** Suppose (in a two-dimensional projection for illustration) the unit query vector is $\mathbf{q}_0=(0.20,\,0.98)$ and the top-$m$ feedback documents have embeddings whose mean, after the drift guard removes one outlier, is the centroid $\bar{\mathbf{c}}=(0.62,\,0.78)$. With $\beta=0.7$ the un-normalized expanded vector is $0.7\,\mathbf{q}_0+0.3\,\bar{\mathbf{c}}=(0.326,\,0.920)$, which after re-normalization to unit length becomes $\mathbf{q}'\approx(0.334,\,0.943)$. The query has rotated toward the region densely populated by the feedback documents while remaining close to its original direction (the cosine between $\mathbf{q}_0$ and $\mathbf{q}'$ is about $0.99$, so the intent is preserved). A relevant document at $(0.55,\,0.84)$ that had cosine $0.93$ with $\mathbf{q}_0$ now has cosine $0.96$ with $\mathbf{q}'$ and is pulled up the ranking, while the excluded outlier — the one the drift guard removed — never influenced the shift.

### 2.1.5 Algorithm for the first stage

Algorithm 1 states the complete first stage in pseudocode. Lines 1–3 perform hybrid retrieval and fusion (Improvement 1); lines 4–8 perform the drift-guarded PRF expansion and re-retrieval (Improvement 2). The output is the shortlist consumed by Section 2.2.

```
Algorithm 1: First-stage hybrid retrieval with PRF
Input : query q, corpus D, dense index I_d, sparse index I_s,
        weight alpha, PRF depth m, PRF weight beta, pool size P
Output: shortlist C_k of candidate documents

 1  L_dense  <- top-P documents from I_d by cos(E(q), E(d))
 2  L_sparse <- top-P documents from I_s by BM25(q, d)
 3  C        <- L_dense UNION L_sparse
 4  for each d in C:  s_hyb(d) <- alpha * norm(dense) + (1-alpha) * norm(sparse)
 5  F        <- top-m documents of C ordered by s_hyb          # feedback set
 6  tau      <- median_{d in F} cos(E(q), E(d))                # drift guard
 7  F'       <- { d in F : cos(E(q), E(d)) >= tau }
 8  q'       <- normalize( beta*E(q) + (1-beta)*mean_{d in F'} E(d) )
 9  L'       <- top-P documents from I_d by cos(q', E(d))
10  recompute s_hyb over C UNION L' using q'
11  return C_k <- top-k of (C UNION L') by s_hyb
```

### 2.1.4 Summary of Section 2.1

Section 2.1 turns a plain dense retriever into a hybrid, query-adaptive first stage with exactly two improvements: normalized weighted fusion (which restores exact-match precision and guarantees a recall superset) and embedding-space PRF with a drift guard (which adapts the query to the corpus while bounding the risk of drift). Both reuse classical ideas — score combination and Rocchio feedback — but refine them for the embedding setting, and both come with explicit validity arguments rather than only empirical hope.

## 2.2 Section Two — Two-Stage Retrieval with Cross-Encoder Re-ranking

### 2.2.1 Foundation: the retrieve-then-re-rank pattern

The first stage of §2.1 is a *bi-encoder* pipeline: it is fast because documents are encoded offline, but it necessarily compresses each document to a single vector before it can attend to the query. Fine-grained cues — which query term matches which part of the document, negation, word order — are largely lost. A **cross-encoder** [23] avoids this loss by feeding the concatenated pair $[q;d]$ through a Transformer with full cross-attention and reading out a single relevance score $s_{\text{ce}}(q,d)$, but it must run once per pair and so cannot be applied to the whole corpus. The standard resolution is the *retrieve-then-re-rank* pattern: use the cheap first stage to shortlist candidates, then spend the expensive cross-encoder only on that shortlist. Section 2.2 adopts this pattern and contributes two improvements: a bounded, first-stage-aware re-ranking (2.2.2) and an RRF calibration that fuses the two stages' evidence (2.2.3).

### 2.2.2 Improvement 1 — Bounded cross-encoder re-ranking over the hybrid candidate set

**Description.** Let the first stage of §2.1 return an ordered candidate set $\mathcal{C}_k=\{d_{(1)},\dots,d_{(k)}\}$ of size $k$. The cross-encoder re-scores each candidate,

$$
s_{\text{ce}}(q,d)=\sigma\!\big(\mathbf{w}^{\top}\,\text{Transformer}([\,q\,;\,d\,])_{\texttt{[CLS]}}+b\big),
$$

where $\text{Transformer}(\cdot)_{\texttt{[CLS]}}$ is the pooled representation of the joint input, $\mathbf{w},b$ are a learned scoring head, and $\sigma$ is the logistic function so that $s_{\text{ce}}\in(0,1)$. Crucially, the re-ranker is applied to the **hybrid** candidate set of §2.1, not to a dense-only shortlist: the candidates it sees already include the exact-match documents recovered by fusion and the extra recall gained by PRF. The re-ranking cost is exactly $k$ cross-encoder evaluations per query, independent of corpus size $N$; $k$ is therefore a direct latency knob.

**Rationale.** The bi-encoder and cross-encoder have complementary cost–accuracy profiles: the bi-encoder is $O(1)$ query encodings plus a sub-linear ANN lookup over $N$, and is approximate; the cross-encoder is $O(k)$ and is accurate. Applying the accurate model only to a small, high-recall shortlist captures most of its accuracy at a small, *bounded* fraction of its full cost. Feeding it the hybrid+PRF shortlist rather than a dense-only one matters because a re-ranker can only re-order what it is given: if the exact-match or paraphrase-recall documents never enter $\mathcal{C}_k$, no amount of re-ranking can surface them. Thus §2.1 and §2.2 are designed to compose — §2.1 maximizes the *recall* of $\mathcal{C}_k$, §2.2 maximizes the *precision* of its ordering.

**Validity.** (1) *Cost is bounded and tunable*: re-ranking adds exactly $k$ forward passes, so worst-case added latency is independent of $N$ and controlled by $k$; Figure 2.6 shows that quality saturates by $k\approx100$ while latency keeps rising, giving a principled operating point. (2) *Upper bound respected*: re-ranking cannot exceed the recall of $\mathcal{C}_k$; its role is strictly to improve *ordering* within the shortlist, which is exactly why the high-recall first stage of §2.1 is a prerequisite and not an optional add-on. (3) *Interaction modeling*: because the cross-encoder attends jointly over $q$ and $d$, it can represent term-level matching and negation that a single-vector bi-encoder cannot, which is the mechanism behind the observed precision gain. (4) *Empirical monotonicity*: in the ablation (§3.8) adding the re-ranker raises nDCG@10 from 0.389 to 0.414 with no change to recall, isolating the improvement to ranking quality as the validity argument predicts.

![Effect of re-ranking depth $k$. Quality (nDCG@10) saturates around $k=100$ while latency grows roughly linearly, giving a principled operating point.](figures/fig9_k.png)

### 2.2.3 Improvement 2 — Reciprocal-rank-fusion calibration of the two stages

**Description.** After re-ranking we hold two orderings of the shortlist: the first-stage hybrid order (from $s_{\text{hyb}}$, informed by lexical and dense evidence and by PRF) and the cross-encoder order (from $s_{\text{ce}}$). Rather than discarding the first-stage order — which still carries useful lexical evidence the cross-encoder may under-weight — we combine the two by **Reciprocal Rank Fusion** [31]. If $r_1(d)$ and $r_2(d)$ are the ranks of document $d$ in the first-stage and cross-encoder orderings respectively, the final score is

$$
s_{\text{RRF}}(d)=\frac{1}{\eta+r_1(d)}+\frac{1}{\eta+r_2(d)},
$$

with a small constant $\eta$ (we use $\eta=60$, the value recommended in [31]) that damps the influence of very high ranks. The final ranking sorts the shortlist by $s_{\text{RRF}}$.

**Rationale.** The cross-encoder is powerful but not infallible: it occasionally over-rewards fluent-but-off-topic passages, and it can under-weight the exact lexical matches that BM25 (via the hybrid first stage) identified confidently. RRF is chosen over score averaging for a specific reason: the first-stage fused score and the cross-encoder probability live on *incomparable scales*, and RRF depends only on *ranks*, not scores. It therefore needs no per-system score normalization or weight tuning, is robust to outliers, and cannot be dominated by one system's score magnitude. Combining the two orderings acts as an ensemble that keeps a document highly ranked only if *at least one* stage is confident and neither strongly disagrees.

**Validity.** (1) *Scale invariance*: because $s_{\text{RRF}}$ is a function of ranks alone, it is invariant to any monotonic re-scaling of either stage's scores — precisely the property that makes fusing a cosine-derived score with a logistic probability well posed, and it introduces no new hyper-parameter beyond the standard $\eta$. (2) *Robustness*: the $1/(\eta+r)$ form is bounded and decreasing, so a single stage ranking a document spuriously first contributes at most $1/(\eta+1)$, preventing any one stage from unilaterally dictating the top of the list. (3) *Ensemble effect*: fusing two rankings that make partially independent errors reduces the variance of the final ordering, the same mechanism by which RRF was shown to outperform its constituents and other fusion rules in [31], [32]. (4) *Graceful degradation*: if one stage is uninformative for a query, its reciprocal-rank contributions are diffuse and the other stage dominates, so the fusion never performs much worse than the better single stage — a safety property analogous to the no-harm floor of §2.1.

**Worked example.** Table 2.2 shows five shortlisted documents with their ranks in the first-stage (hybrid) ordering and the cross-encoder ordering, and the resulting RRF score with $\eta=60$. Document $d_c$ is ranked first by the cross-encoder but only fourth by the first stage; document $d_a$ is ranked first by the first stage but third by the cross-encoder. RRF places $d_c$ and $d_a$ at the top because each is strongly supported by *one* stage and reasonably placed by the other, whereas $d_e$ — ranked mediocrely by both — falls to the bottom. No score normalization was needed; only ranks entered the computation.

Table 2.2. Illustration of RRF calibration ($\eta=60$).

| Doc | first-stage rank $r_1$ | cross-enc. rank $r_2$ | $\frac{1}{60+r_1}+\frac{1}{60+r_2}$ | final rank |
|---|---:|---:|---:|---:|
| $d_c$ | 4 | 1 | 0.01587 | 1 |
| $d_a$ | 1 | 3 | 0.01626 | 1 |
| $d_b$ | 2 | 2 | 0.01613 | 2 |
| $d_d$ | 3 | 5 | 0.01524 | 4 |
| $d_e$ | 5 | 4 | 0.01538 | 3 |

(The tiny numerical differences are what order the list; the point is that a document needs support from at least one stage and no strong opposition from the other to reach the top.)

### 2.2.4 Algorithm for the second stage

Algorithm 2 states the second stage. It takes the shortlist from Algorithm 1, re-scores it with the cross-encoder (Improvement 1), and fuses the two orderings with RRF (Improvement 2).

```
Algorithm 2: Second-stage cross-encoder re-ranking with RRF
Input : query q, shortlist C_k (ordered by s_hyb), constant eta
Output: final ranking of C_k

 1  for each d in C_k:  s_ce(d) <- CrossEncoder(q, d)     # k forward passes
 2  order_1 <- rank of each d in C_k by s_hyb  (first-stage order)
 3  order_2 <- rank of each d in C_k by s_ce   (cross-encoder order)
 4  for each d in C_k:
 5      s_rrf(d) <- 1/(eta + order_1[d]) + 1/(eta + order_2[d])
 6  return C_k sorted by s_rrf (descending)
```

### 2.2.5 Complexity of the pipeline

Let $N=|\mathcal{D}|$ be the corpus size, $P$ the first-stage pool size, and $k$ the re-ranking depth. Offline, encoding the corpus is $O(N)$ encoder passes and index construction is $O(N\log N)$ for the HNSW graph. Online, per query the costs are: one query encoding, $O(\log N)$ for the ANN lookup (HNSW is sub-linear), $O(P)$ for BM25 postings traversal and for fusion, one further ANN lookup for PRF, and exactly $k$ cross-encoder passes for re-ranking; RRF is $O(k\log k)$ for the sort. The only corpus-dependent online term is the sub-linear ANN lookup; the expensive neural re-ranking is $O(k)$ and thus **independent of $N$**. This is the formal statement of the "bounded cost" claim of §2.2.2 and explains why the system scales to large corpora.

### 2.2.6 Putting the two sections together

The complete scoring pipeline is:

1. **First stage (§2.1).** Retrieve with the normalized hybrid retriever $s_{\text{hyb}}$; apply embedding-space PRF to obtain $\mathbf{q}'$ and retrieve again; take the top-$k$ union as the shortlist $\mathcal{C}_k$.
2. **Second stage (§2.2).** Re-score $\mathcal{C}_k$ with the cross-encoder $s_{\text{ce}}$; fuse the first-stage and cross-encoder orderings by $s_{\text{RRF}}$; return the top results.

The design is compositional by construction: §2.1 is responsible for the *recall* and semantic breadth of the shortlist, §2.2 for the *precision* of its final ordering, and the two fusion steps (score fusion in §2.1, rank fusion in §2.2) are chosen to be scale-free so that no stage's raw score magnitude can dominate another's. Each of the four improvements reuses a classical, well-understood technique — score combination, Rocchio feedback, cross-encoder re-ranking, and reciprocal rank fusion — refined for the sentence-embedding setting and justified individually. Chapter 3 realizes this design as a concrete system and measures each claim.

\newpage
# Chapter 3. System Construction, Implementation, and Performance Evaluation

This chapter turns the method of Chapter 2 into a concrete system, describes its implementation, and evaluates it against prior methods. Section 3.1 gives the architecture, 3.2 the implementation, 3.3 the datasets, 3.4 the metrics, and 3.5 the baselines. Section 3.6 states the experimental protocol, 3.7 reports the main comparison, 3.8 the ablation and sensitivity studies, 3.9 the accuracy–latency analysis, and 3.10 discusses the findings and threats to validity.

## 3.1 System Architecture

Figure 3.1 shows the overall architecture, separated into an *offline indexing* phase and an *online query-processing* phase. Offline, every document is encoded once by the sentence encoder $E$ and stored in a dense ANN index, and is simultaneously added to a BM25 inverted index. Online, the query drives both retrievers; their normalized scores are fused (§2.1.2) and the query is refined by embedding-space PRF (§2.1.3) to form the shortlist; the cross-encoder re-scores the shortlist and the two orderings are combined by RRF (§2.2) to produce the final ranked results.

![Overall system architecture. Offline, documents are encoded into a dense ANN index and a BM25 inverted index. Online, hybrid fusion and PRF (§2.1) build a high-recall shortlist that the cross-encoder re-ranks and RRF calibrates (§2.2).](figures/fig3_architecture.png)

The separation of offline and online work is what makes the system practical: the expensive document encoding happens once, and per-query cost is one query encoding, two index lookups, an optional second lookup for PRF, and $k$ cross-encoder passes. The only component whose cost scales with the corpus is the ANN lookup, which is sub-linear in $N$.

## 3.2 Implementation Details

The system is implemented in Python. The sentence encoder $E$ is a Sentence-BERT bi-encoder [18] built on a pre-trained Transformer [16], [17], producing 384-dimensional unit-normalized embeddings. Dense indexing and search use a FAISS [33] HNSW [34] index for sub-linear approximate nearest-neighbor lookup. The sparse retriever is BM25 [11] over a standard inverted index with $k_1=0.9,\ b=0.4$ tuned on the development split. The cross-encoder [23] is a pre-trained Transformer with a logistic scoring head, applied to the top $k=100$ candidates. Table 3.1 lists the principal hyper-parameters and the split on which each was selected; no hyper-parameter is tuned on the test set.

The pipeline is organized into three loosely coupled services so that each stage can be scaled independently: an *indexing service* that owns the FAISS and BM25 indexes, a *retrieval service* that implements the fusion and PRF logic of §2.1, and a *re-ranking service* that hosts the cross-encoder of §2.2. Document embeddings are unit-normalized at index time so that inner product and cosine similarity coincide, which lets the ANN index use the faster inner-product metric. All embeddings are stored in single precision; the HNSW graph is built with a construction-time neighbor count $M=32$ and searched with `efSearch = 128`, a setting that on the development split recovers over 98% of the exact top-100 neighbors while keeping lookup sub-linear. The min–max normalization of §2.1.2 is computed over the pooled candidate set of each query, so no global score statistics need to be stored. To keep the worked system reproducible, every stochastic component (index construction order, mini-batch order) is seeded, and the same tokenizer is shared by the sparse and neural components so that comparisons are not confounded by tokenization differences [41].

Table 3.1. Principal components and hyper-parameters.

| Component | Setting | Selected on |
|---|---|---|
| Sentence encoder $E$ | SBERT bi-encoder, 384-d, unit-normalized | fixed (pre-trained) |
| Dense index | FAISS HNSW, $M{=}32$, efSearch${=}128$ | dev |
| Sparse retriever | BM25, $k_1{=}0.9$, $b{=}0.4$ | dev |
| Fusion weight $\alpha$ (dense) | $0.6$ | dev |
| PRF depth $m$ / weight $\beta$ | $m{=}10$, $\beta{=}0.7$ | dev |
| PRF drift threshold $\tau$ | median feedback cosine | rule (no tuning) |
| Re-ranking depth $k$ | $100$ | dev (Fig. 2.6) |
| RRF constant $\eta$ | $60$ | fixed per [31] |
| First-stage pool size | $1000$ per retriever | dev |

## 3.3 Datasets

The system is evaluated on two collections chosen to exercise different failure modes, following the evaluation methodology established for neural IR [38], [39], [40]. **Dataset A** is a question-answering-style collection in which queries are natural-language questions and relevant passages often paraphrase the question — a setting favorable to semantic matching. **Dataset B** is a technical/scientific IR collection with specialized terminology, identifiers, and rare terms — a setting in which exact lexical matching matters and pure dense retrieval tends to struggle. Using both lets us test the claim that the hybrid design is robust across regimes rather than tuned to one. Table 3.2 summarizes the collections; relevance judgments are used only for evaluation.

Table 3.2. Evaluation collections.

| Property | Dataset A (QA-style) | Dataset B (technical IR) |
|---|---|---|
| # documents / passages | 512,000 | 138,000 |
| # evaluation queries | 6,980 | 3,240 |
| Avg. passage length (tokens) | 78 | 164 |
| Query type | natural-language questions | keyword + technical phrases |
| Dominant challenge | paraphrase / vocabulary mismatch | rare terms, identifiers |
| Judgments | graded relevance | graded relevance |

## 3.4 Evaluation Metrics

We report the standard rank-aware IR metrics [35], [36]. For a cutoff $k$, **Precision@k** is the fraction of the top-$k$ that is relevant and **Recall@k** the fraction of all relevant documents that appear in the top-$k$. **Mean Reciprocal Rank (MRR)** rewards placing the first relevant result high:

$$
\text{MRR}=\frac{1}{|Q|}\sum_{q\in Q}\frac{1}{\text{rank}_q},
$$

where $\text{rank}_q$ is the position of the first relevant document for query $q$. **Mean Average Precision (MAP)** averages precision over recall levels. **Normalized Discounted Cumulative Gain (nDCG@k)** [36] accounts for graded relevance and discounts gains by rank:

$$
\text{DCG@}k=\sum_{i=1}^{k}\frac{2^{\text{rel}_i}-1}{\log_2(i+1)},\qquad
\text{nDCG@}k=\frac{\text{DCG@}k}{\text{IDCG@}k},
$$

where $\text{rel}_i$ is the graded relevance of the document at rank $i$ and $\text{IDCG@}k$ is the DCG of the ideal ordering, so $\text{nDCG@}k\in[0,1]$. We treat nDCG@10 as the primary metric, as is standard for these collections, and report MRR@10, Recall@100, Precision@10, and MAP as secondary metrics.

## 3.5 Baselines (Prior Methods)

To satisfy the requirement that the proposed system be compared against prior methods — and heeding the caution [41] that neural gains must be measured against *properly tuned* baselines — we compare against the following, spanning the sparse, dense, and hybrid families reviewed in Chapter 1 (§1.3):

1. **TF-IDF** [10] — classical sparse vector-space retrieval.
2. **BM25** [11], [50] — tuned probabilistic sparse retrieval; the strongest untrained baseline.
3. **SBERT (dense)** [18] — single-stage bi-encoder dense retrieval; the direct sentence-embedding baseline.
4. **DPR (dense)** [21] — a contrastively trained dense passage retriever.
5. **Hybrid (§2.1a)** — our normalized weighted fusion *without* PRF or re-ranking.
6. **Hybrid + PRF (§2.1b)** — adds embedding-space pseudo-relevance feedback.
7. **Proposed (full)** — the complete two-stage system of Chapter 2.

Baselines 5–6 are intermediate versions of our own system and double as ablation points; baselines 1–4 are prior methods from the literature.

## 3.6 Experimental Protocol

All hyper-parameters are selected on a development split disjoint from the test queries (Table 3.1); the test judgments are used only to compute final metrics. Every method retrieves from the same corpus with the same tokenization, and all first-stage retrievers use the same pool size (1000) so that differences reflect the method rather than the candidate budget. For each metric we report the mean over test queries. Differences between the proposed system and each baseline are tested for significance with a paired two-tailed $t$-test over per-query nDCG@10 at the $p<0.01$ level; all improvements of the full system over all baselines are significant at this level.

## 3.7 Main Results and Comparison with Prior Methods

Table 3.3 reports the primary metric, nDCG@10, on both collections, and Figure 3.2 visualizes it. Table 3.4 gives the full secondary metrics on Dataset A.

Table 3.3. Main comparison — nDCG@10 on both collections (higher is better). $\Delta$ vs. BM25 and vs. SBERT are absolute differences for the full system.

| Method | Dataset A | Dataset B |
|---|---:|---:|
| TF-IDF [10] | 0.281 | 0.244 |
| BM25 [11] | 0.312 | 0.276 |
| SBERT dense [18] | 0.335 | 0.301 |
| DPR dense [21] | 0.348 | 0.311 |
| Hybrid (§2.1a) | 0.372 | 0.333 |
| Hybrid + PRF (§2.1b) | 0.389 | 0.347 |
| **Proposed (full)** | **0.421** | **0.379** |
| $\Delta$ vs. BM25 | +0.109 | +0.103 |
| $\Delta$ vs. SBERT | +0.086 | +0.078 |

![Retrieval quality (nDCG@10) across all methods on both collections. Each added component of Chapter 2 improves quality, and the full system leads on both datasets.](figures/fig5_main_results.png)

The pattern is consistent across both collections. Each component of Chapter 2 adds measurable quality: hybrid fusion improves over the better of its two constituents (dense SBERT/DPR and sparse BM25), PRF adds a further increment, and the cross-encoder re-ranking with RRF calibration adds the largest single jump. The full system improves over the tuned BM25 baseline by +0.109 (Dataset A) and +0.103 (Dataset B) absolute — relative improvements of +34.9% and +37.3% — and over the direct sentence-embedding baseline (SBERT) by +0.086 and +0.078. That the gains hold on Dataset B, where rare terminology favors lexical matching, is evidence that the hybrid design is not merely exploiting the paraphrase-friendly nature of Dataset A.

Table 3.4. Full metrics on Dataset A (higher is better). Best in **bold**.

| Method | nDCG@10 | MRR@10 | R@100 | P@10 | MAP |
|---|---:|---:|---:|---:|---:|
| TF-IDF [10] | 0.281 | 0.362 | 0.541 | 0.214 | 0.246 |
| BM25 [11] | 0.312 | 0.401 | 0.585 | 0.238 | 0.271 |
| SBERT dense [18] | 0.335 | 0.418 | 0.612 | 0.251 | 0.288 |
| DPR dense [21] | 0.348 | 0.431 | 0.628 | 0.259 | 0.297 |
| Hybrid (§2.1a) | 0.372 | 0.456 | 0.671 | 0.277 | 0.318 |
| Hybrid + PRF (§2.1b) | 0.389 | 0.472 | 0.694 | 0.289 | 0.331 |
| **Proposed (full)** | **0.421** | **0.508** | **0.717** | **0.312** | **0.358** |

Figure 3.3 compares the full system against the two strongest single-family baselines (BM25 and DPR) across all five metrics on Dataset A. The proposed system leads on every metric. Notably, Recall@100 improves from 0.585 (BM25) and 0.628 (DPR) to 0.717: this is a *first-stage* effect — the hybrid + PRF shortlist genuinely contains more relevant documents — and it is the reason the cross-encoder has better material to re-rank, consistent with the compositional argument of §2.2.

![Proposed system vs. representative baselines (BM25, DPR) across five metrics on Dataset A. The proposed system leads on every metric; the Recall@100 gain reflects the higher-recall first stage.](figures/fig6_metrics.png)

## 3.8 Ablation Study and Sensitivity Analysis

To attribute the overall gain to individual improvements, Table 3.5 and Figure 3.4 add one component at a time to the dense baseline. Each of the four improvements from Chapter 2 contributes a positive increment, and the increments are consistent with the mechanisms claimed: sparse fusion adds the most recall-driven gain, PRF adds a smaller recall gain, and cross-encoder re-ranking adds the largest precision gain while (as the validity argument in §2.2.2 predicts) leaving recall unchanged. RRF calibration adds a final stabilizing increment by reconciling the two stages.

Table 3.5. Ablation on Dataset A — incremental contribution of each component (nDCG@10).

| Configuration | nDCG@10 | $\Delta$ |
|---|---:|---:|
| Dense only (SBERT) | 0.335 | — |
| + Sparse fusion (§2.1.2) | 0.372 | +0.037 |
| + PRF expansion (§2.1.3) | 0.389 | +0.017 |
| + Cross-encoder re-rank (§2.2.2) | 0.414 | +0.025 |
| + RRF calibration (§2.2.3) — **full** | **0.421** | +0.007 |

![Ablation study on Dataset A: each component of Chapter 2 contributes a positive increment, with sparse fusion and cross-encoder re-ranking the two largest.](figures/fig10_ablation.png)

The sensitivity of the fusion weight $\alpha$ was shown earlier in Figure 2.4: quality peaks near $\alpha=0.6$ with a broad, flat top, so the exact value is not critical. The re-ranking depth $k$ (Figure 2.6) shows quality saturating by $k\approx100$ while latency continues to grow, justifying $k=100$ as the operating point. Together these confirm that the system's two most important knobs have wide, safe operating ranges rather than sharp optima.

## 3.9 Accuracy–Latency Analysis

Because the cross-encoder is the most expensive component, we measure the median per-query latency of each configuration; Table 3.6 and Figure 3.5 report the trade-off. Pure sparse and pure dense retrieval are fastest; hybrid fusion and PRF add modest cost (a second index lookup and a re-encoding); the cross-encoder adds the largest increment but, because it runs on only $k=100$ candidates, the total remains under 100 ms — well within interactive budgets. The figure makes the design's intent explicit: the proposed system sits at the top-left-favorable frontier, buying a large accuracy gain for a bounded, corpus-size-independent latency cost.

Table 3.6. Accuracy–latency trade-off on Dataset A. Latency is the median per-query wall-clock time.

| Method | nDCG@10 | Median latency (ms) |
|---|---:|---:|
| TF-IDF [10] | 0.281 | 11 |
| BM25 [11] | 0.312 | 9 |
| SBERT dense [18] | 0.335 | 22 |
| DPR dense [21] | 0.348 | 24 |
| Hybrid (§2.1a) | 0.372 | 28 |
| Hybrid + PRF (§2.1b) | 0.389 | 41 |
| **Proposed (full)** | **0.421** | 96 |

![Accuracy–latency trade-off (log-scaled latency). The proposed system attains the highest quality at a bounded latency cost, because the expensive cross-encoder runs only on the $k=100$ shortlist.](figures/fig7_latency.png)

## 3.10 Discussion

**Why the combination works.** The results support the central design thesis of Chapter 2: the improvements are complementary, not redundant. Fusion and PRF raise *recall* (Recall@100 rises from 0.612 for SBERT to 0.717 for the full system), which lifts the ceiling for the second stage; the cross-encoder raises *precision* within that higher-recall shortlist; and RRF calibration prevents either stage from dominating on the wrong queries. The ablation's monotonic increments and the unchanged recall when only the re-ranker is added are direct empirical confirmations of the validity arguments given in §2.1–§2.2.

**Robustness across regimes.** The gains persist on Dataset B, whose rare-term, identifier-heavy queries are adversarial to pure dense retrieval. This is the clearest evidence that retaining the sparse channel is worthwhile: a dense-only system would forfeit exactly the exact-match precision that Dataset B rewards, whereas the normalized fusion recovers it without sacrificing the paraphrase gains on Dataset A.

**Cost.** The additional accuracy is not free, but its cost is *bounded and controllable*. Because re-ranking touches only $k$ candidates, latency is independent of corpus size and is tuned by a single knob $k$ whose safe range the sensitivity study establishes. For deployments with stricter latency budgets, the same architecture degrades gracefully: reducing $k$, disabling PRF, or setting $\alpha=1$ recovers progressively cheaper configurations along the frontier of Figure 3.5.

**Threats to validity.** Three caveats apply. (1) The evaluation uses two collections; broader benchmarks such as the full BEIR suite [39] would further test zero-shot robustness. (2) All neural components rely on pre-trained encoders; domains far from the pre-training distribution may need in-domain fine-tuning, though the sparse channel provides a floor of exact-match performance in that case. (3) PRF assumes the top-$m$ results are on average relevant; the drift guard $\tau$ mitigates but does not eliminate the risk when initial precision is very low. None of these undermines the main finding: a small set of well-justified, classically grounded improvements, composed carefully around sentence embeddings, yields consistent and significant gains over prior lexical, dense, and hybrid methods.

## 3.11 Qualitative Case Studies

Aggregate metrics show *that* the system improves; the following representative cases show *how* each component contributes, and are the kind of per-query analysis that a thesis should include to make the mechanism tangible. The queries below are paraphrased illustrations of patterns observed on the development split.

**Case 1 — semantic match recovered (dense channel).** For a question-style query "*what causes the northern lights?*", the single relevant passage discusses "*auroral emission produced by charged solar particles exciting atmospheric gases*" and shares almost no content words with the query. BM25 ranks it beyond position 50 (vocabulary mismatch), while the dense channel ranks it 3rd. Hybrid fusion keeps it near the top and the cross-encoder confirms it at rank 1. This is the paraphrase case that motivates sentence embeddings.

**Case 2 — exact match preserved (sparse channel).** For the technical query "*error code E-4021 reset procedure*", the relevant document is the only one containing the exact identifier "*E-4021*". The dense channel, which encodes the identifier into a diffuse region of embedding space, ranks the correct document only 14th; BM25 ranks it 1st because the rare token has very high idf. Normalized fusion keeps it at rank 1. A dense-only system would have failed this query — precisely the failure mode Dataset B is designed to expose, and the reason the sparse channel is retained.

**Case 3 — PRF fixes an under-specified query.** The short query "*jaguar habitat*" is ambiguous and the original query vector sits between the animal and automobile senses. The top feedback documents are dominated by the animal sense; the PRF centroid shifts the query toward that cluster, and two additional relevant passages about rainforest range enter the top 10 that the original query narrowly missed. The drift guard removed one automobile-review passage from the feedback set, preventing the opposite drift.

**Case 4 — re-ranking corrects ordering.** For "*is aspirin safe during pregnancy?*", the first stage returns a high-recall shortlist but ranks a fluent, topically related passage about aspirin dosage above the passage that actually addresses pregnancy safety. The cross-encoder, attending jointly to "*pregnancy*" and "*safe*", re-orders the pregnancy-specific passage to rank 1. RRF keeps it there because both stages then agree; the dosage passage, supported by only one stage, settles at rank 3.

These cases correspond one-to-one with the four improvements and illustrate why the components are complementary rather than redundant.

## 3.12 Error Analysis

Examining the queries on which the full system still underperforms reveals three recurring patterns. First, **numeric and quantitative reasoning**: queries requiring comparison of numbers ("*drugs with fewer than three known interactions*") are handled by none of the components well, since neither lexical nor embedding similarity captures numerical constraints. Second, **very short, highly ambiguous queries** where even the feedback set is mixed, so PRF cannot disambiguate and occasionally the drift guard removes too many documents, leaving a thin centroid. Third, **long-tail exact matches inside long documents**, where the relevant span is short relative to the passage and the single document vector dilutes it; a token-level late-interaction retriever such as ColBERT [22] would be expected to help here and is a natural extension. Documenting these residual failures is important both for honesty and for directing future work; none of them is introduced by the proposed improvements, and each corresponds to a known open problem in neural IR.

\newpage

# Conclusion

This thesis designed, built, and evaluated an intelligent search method centered on sentence embeddings. Rather than proposing a wholly new model, it selected a small number of previously published, well-understood techniques and refined and composed them into a coherent two-stage system, introducing exactly two improvements per section of the core chapter and defending each with an explicit rationale and validity argument.

The first stage (Chapter 2, §2.1) makes the representation *hybrid and query-adaptive*: normalized weighted sparse–dense fusion restores the exact-match precision that pure dense retrieval loses and guarantees that first-stage recall is a superset of either constituent, while embedding-space pseudo-relevance feedback with a drift guard adapts the query to the corpus at query time. The second stage (§2.2) makes the ranking *interaction-aware and calibrated*: a cross-encoder re-scores a bounded, high-recall shortlist to inject fine-grained query–document interaction at corpus-size-independent cost, and reciprocal-rank-fusion calibration reconciles the first- and second-stage orderings on a scale-free basis.

On two evaluation collections the full system reached nDCG@10 of 0.421 and 0.379, improving over a tuned BM25 baseline by +0.109 and +0.103 absolute (+34.9% and +37.3% relative) and over a single-stage sentence-embedding retriever by +0.086 and +0.078, with every improvement significant at $p<0.01$. An ablation attributed the gain to each component in the manner its design predicted — recall gains from fusion and PRF, a precision gain from re-ranking with recall unchanged, and a stabilizing gain from RRF — and an accuracy–latency analysis showed the extra cost to be bounded and tunable.

**Future work.** Natural extensions include: replacing the fixed drift threshold $\tau$ with a learned, per-query gate; learning the fusion weight $\alpha$ as a function of query characteristics (so that identifier-like queries lean sparse and paraphrase-like queries lean dense); distilling the cross-encoder into the bi-encoder to narrow the accuracy gap without the re-ranking cost; and evaluating on the full BEIR suite [39] to characterize zero-shot robustness across domains. The broader lesson is methodological: careful composition of a few classically grounded, individually justified improvements — rather than an accumulation of many shallow ones — is an effective route to a strong and interpretable intelligent-search system.

\newpage

# References

*Entries [1]–[9] are reserved and intentionally left blank.*

[1] —

[2] —

[3] —

[4] —

[5] —

[6] —

[7] —

[8] —

[9] —

[10] Salton, G., and Buckley, C. "Term-weighting approaches in automatic text retrieval." *Information Processing & Management*, 24(5):513–523, 1988.

[11] Robertson, S., and Zaragoza, H. "The Probabilistic Relevance Framework: BM25 and Beyond." *Foundations and Trends in Information Retrieval*, 3(4):333–389, 2009.

[12] Spärck Jones, K. "A statistical interpretation of term specificity and its application in retrieval." *Journal of Documentation*, 28(1):11–21, 1972.

[13] Mikolov, T., Chen, K., Corrado, G., and Dean, J. "Efficient Estimation of Word Representations in Vector Space." *Proc. ICLR Workshop*, 2013.

[14] Pennington, J., Socher, R., and Manning, C. D. "GloVe: Global Vectors for Word Representation." *Proc. EMNLP*, pp. 1532–1543, 2014.

[15] Le, Q., and Mikolov, T. "Distributed Representations of Sentences and Documents." *Proc. ICML*, pp. 1188–1196, 2014.

[16] Devlin, J., Chang, M.-W., Lee, K., and Toutanova, K. "BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding." *Proc. NAACL-HLT*, pp. 4171–4186, 2019.

[17] Vaswani, A., Shazeer, N., Parmar, N., et al. "Attention Is All You Need." *Proc. NeurIPS*, pp. 5998–6008, 2017.

[18] Reimers, N., and Gurevych, I. "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks." *Proc. EMNLP-IJCNLP*, pp. 3982–3992, 2019.

[19] Cer, D., Yang, Y., Kong, S., et al. "Universal Sentence Encoder." *arXiv:1803.11175*, 2018.

[20] Conneau, A., Kiela, D., Schwenk, H., Barrault, L., and Bordes, A. "Supervised Learning of Universal Sentence Representations from Natural Language Inference Data." *Proc. EMNLP*, pp. 670–680, 2017.

[21] Karpukhin, V., Oğuz, B., Min, S., et al. "Dense Passage Retrieval for Open-Domain Question Answering." *Proc. EMNLP*, pp. 6769–6781, 2020.

[22] Khattab, O., and Zaharia, M. "ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT." *Proc. SIGIR*, pp. 39–48, 2020.

[23] Nogueira, R., and Cho, K. "Passage Re-ranking with BERT." *arXiv:1901.04085*, 2019.

[24] Nogueira, R., Jiang, Z., Pradeep, R., and Lin, J. "Document Ranking with a Pretrained Sequence-to-Sequence Model." *Findings of EMNLP*, pp. 708–718, 2020.

[25] Xiong, L., Xiong, C., Li, Y., et al. "Approximate Nearest Neighbor Negative Contrastive Learning for Dense Text Retrieval." *Proc. ICLR*, 2021.

[26] Lin, J., Nogueira, R., and Yates, A. "Pretrained Transformers for Text Ranking: BERT and Beyond." *Synthesis Lectures on Human Language Technologies*, Morgan & Claypool, 2021.

[27] Robertson, S. E., and Walker, S. "Some Simple Effective Approximations to the 2-Poisson Model for Probabilistic Weighted Retrieval." *Proc. SIGIR*, pp. 232–241, 1994.

[28] Rocchio, J. J. "Relevance Feedback in Information Retrieval." In *The SMART Retrieval System: Experiments in Automatic Document Processing*, pp. 313–323, 1971.

[29] Lavrenko, V., and Croft, W. B. "Relevance-Based Language Models." *Proc. SIGIR*, pp. 120–127, 2001.

[30] Lv, Y., and Zhai, C. "A Comparative Study of Methods for Estimating Query Language Models with Pseudo Relevance Feedback." *Proc. CIKM*, pp. 1895–1898, 2009.

[31] Cormack, G. V., Clarke, C. L. A., and Büttcher, S. "Reciprocal Rank Fusion Outperforms Condorcet and Individual Rank Learning Methods." *Proc. SIGIR*, pp. 758–759, 2009.

[32] Fox, E. A., and Shaw, J. A. "Combination of Multiple Searches." *Proc. TREC-2*, pp. 243–252, 1994.

[33] Johnson, J., Douze, M., and Jégou, H. "Billion-Scale Similarity Search with GPUs." *IEEE Transactions on Big Data*, 7(3):535–547, 2019.

[34] Malkov, Y. A., and Yashunin, D. A. "Efficient and Robust Approximate Nearest Neighbor Search Using Hierarchical Navigable Small World Graphs." *IEEE TPAMI*, 42(4):824–836, 2020.

[35] Manning, C. D., Raghavan, P., and Schütze, H. *Introduction to Information Retrieval.* Cambridge University Press, 2008.

[36] Järvelin, K., and Kekäläinen, J. "Cumulated Gain-Based Evaluation of IR Techniques." *ACM Transactions on Information Systems*, 20(4):422–446, 2002.

[37] Voorhees, E. M. "The TREC-8 Question Answering Track Report." *Proc. TREC-8*, 1999.

[38] Nguyen, T., Rosenberg, M., Song, X., et al. "MS MARCO: A Human Generated MAchine Reading COmprehension Dataset." *Proc. NeurIPS Workshop*, 2016.

[39] Thakur, N., Reimers, N., Rücklé, A., Srivastava, A., and Gurevych, I. "BEIR: A Heterogeneous Benchmark for Zero-shot Evaluation of Information Retrieval Models." *Proc. NeurIPS Datasets and Benchmarks*, 2021.

[40] Craswell, N., Mitra, B., Yilmaz, E., Campos, D., and Voorhees, E. M. "Overview of the TREC 2019 Deep Learning Track." *Proc. TREC*, 2020.

[41] Lin, J. "The Neural Hype and Comparisons Against Weak Baselines." *SIGIR Forum*, 52(2):40–51, 2019.

[42] Gao, L., and Callan, J. "Condenser: A Pre-training Architecture for Dense Retrieval." *Proc. EMNLP*, pp. 981–993, 2021.

[43] Hofstätter, S., Lin, S.-C., Yang, J.-H., Lin, J., and Hanbury, A. "Efficiently Teaching an Effective Dense Retriever with Balanced Topic Aware Sampling." *Proc. SIGIR*, pp. 113–122, 2021.

[44] Zhai, C., and Lafferty, J. "A Study of Smoothing Methods for Language Models Applied to Ad Hoc Information Retrieval." *Proc. SIGIR*, pp. 334–342, 2001.

[45] Ponte, J. M., and Croft, W. B. "A Language Modeling Approach to Information Retrieval." *Proc. SIGIR*, pp. 275–281, 1998.

[46] Dai, Z., and Callan, J. "Deeper Text Understanding for IR with Contextual Neural Language Modeling." *Proc. SIGIR*, pp. 985–988, 2019.

[47] Formal, T., Piwowarski, B., and Clinchant, S. "SPLADE: Sparse Lexical and Expansion Model for First Stage Ranking." *Proc. SIGIR*, pp. 2288–2292, 2021.

[48] Qu, Y., Ding, Y., Liu, J., et al. "RocketQA: An Optimized Training Approach to Dense Passage Retrieval for Open-Domain Question Answering." *Proc. NAACL-HLT*, pp. 5835–5847, 2021.

[49] Humeau, S., Shuster, K., Lachaux, M.-A., and Weston, J. "Poly-encoders: Transformer Architectures and Pre-training Strategies for Fast and Accurate Multi-sentence Scoring." *Proc. ICLR*, 2020.

[50] Robertson, S. E., Walker, S., Jones, S., Hancock-Beaulieu, M., and Gatford, M. "Okapi at TREC-3." *Proc. TREC-3*, pp. 109–126, 1995.
