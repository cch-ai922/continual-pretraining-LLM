# Effective and Fast Single-Image Super-Resolution: Design, Implementation, and Evaluation of Lightweight Deep Networks

**Author:** [Author Name]
**Affiliation:** [Department / Institution]
**Degree Programme:** [Programme]
**Supervisor:** [Supervisor Name]
**Date:** June 2026

---

## Abstract

Single-image super-resolution (SISR) reconstructs a high-resolution (HR) image from a single low-resolution (LR) observation. Over the past decade the field has been transformed by deep convolutional neural networks, which have raised reconstruction quality far above that of the interpolation and classical example-based methods that preceded them. This progress, however, has come at a steadily rising computational cost: the most accurate networks now contain tens of millions of parameters and require hundreds of billions of floating-point operations to upscale even a modest image, which makes them difficult to deploy on the mobile phones, cameras, set-top boxes, and embedded devices where super-resolution is most useful. The central problem addressed in this thesis is therefore the accuracy–efficiency dilemma: how to retain most of the reconstruction quality of deep networks while drastically reducing their computational and memory footprint.

The thesis is organised in three chapters. Chapter 1 analyses prior research, formulates the SISR problem mathematically, reviews the principal families of methods—interpolation, reconstruction, classical learning, and deep learning—and identifies the specific weaknesses that motivate this work. Chapter 2 describes two effective and efficient models. The first, **ESRN-B**, is a compact residual network whose two key improvements are (i) computation entirely in the low-resolution space using a sub-pixel convolution for upsampling, and (ii) global residual learning with batch-normalisation-free, weight-normalised residual blocks. The second, **ESRN-D**, adds (i) information-distillation blocks that progressively retain a fraction of features rather than discarding them, and (ii) cascading feature reuse combined with a contrast-aware channel-attention mechanism. For each model the rationale and validity of every improvement are explained in detail rather than asserted. Chapter 3 constructs a complete training and inference system around these models, describes its implementation, and reports a thorough quantitative and qualitative evaluation against prior methods on the standard Set5, Set14, BSD100, and Urban100 benchmarks at ×2, ×3, and ×4 scale factors, together with parameter, FLOP, and runtime comparisons and a set of ablation studies.

The experiments show that the proposed models recover image quality competitive with the best lightweight networks in the literature, and within a few tenths of a decibel of much larger networks such as EDSR and RCAN, while using one to two orders of magnitude fewer parameters and running several times faster. The thesis concludes that careful architectural design—placing computation where it is cheap, reusing features instead of recomputing them, and recalibrating channels at negligible cost—is more valuable than raw depth for practical super-resolution.

**Keywords:** single-image super-resolution; convolutional neural networks; lightweight models; sub-pixel convolution; residual learning; information distillation; channel attention; PSNR; SSIM.

---

---

# Chapter 1. Analysis of Previous Research and Problem Formulation

## 1.1 Introduction and motivation

Digital images are everywhere, yet their resolution is almost always limited by something: the size and cost of the camera sensor, the bandwidth available to transmit the image, the storage budget of the device that holds it, or simply the distance between the camera and the scene. *Super-resolution* (SR) is the family of techniques that attempt to recover the missing high-frequency detail and produce an image with more pixels—and, ideally, more genuine information—than the input. When the reconstruction is performed from a single low-resolution input, the task is called **single-image super-resolution** (SISR), and it is the subject of this thesis.

![Figure 1.1: Conceptual overview of single-image super-resolution: a learned model maps a low-resolution input to a high-resolution output.](figures/fig_1_1_overview.png)

*Figure 1.1: Conceptual overview of single-image super-resolution: a learned model maps a low-resolution input to a high-resolution output.*

The practical importance of SISR is easy to state. In consumer photography it lets a phone present a sharp image after a digital zoom. In video streaming it allows a low-bandwidth signal to be upscaled on the receiving device, saving transmission cost. In surveillance and remote sensing it can make a distant licence plate or a small ground feature legible. In medical imaging it can sharpen a scan without exposing the patient to a longer acquisition. In each of these settings the same two requirements appear together: the result must be *visually faithful*, and it must be produced *quickly and cheaply*, often on hardware with very little memory and a strict power budget. These two requirements pull in opposite directions, and the tension between them is the thread that runs through this entire thesis.

The difficulty of SISR is fundamental rather than incidental. When an image is reduced in size, many different high-resolution images could have produced exactly the same low-resolution result; the downscaling has discarded information that cannot be recovered with certainty. Super-resolution is therefore an *ill-posed inverse problem*, and any method that solves it must, explicitly or implicitly, supply prior knowledge about what natural images look like in order to choose a plausible reconstruction among the infinitely many that are consistent with the input. The history of the field is, in large part, the history of how that prior knowledge has been expressed—first as hand-designed smoothness assumptions, then as dictionaries of image patches learned from data, and finally as the weights of deep neural networks trained end to end.

This first chapter lays the groundwork for the rest of the thesis. Section 1.2 formulates the problem precisely, introduces the standard degradation model, and defines the metrics used throughout. Section 1.3 organises the older, pre-deep-learning literature into a taxonomy. Section 1.4 reviews deep-learning-based super-resolution in the detail that the rest of the thesis requires, introducing the specific networks that will later serve as baselines and as sources of design ideas. Section 1.5 isolates the accuracy–efficiency dilemma that motivates the work. Section 1.6 states the research objectives, and Section 1.7 lists the contributions and describes how the thesis is organised.

## 1.2 The single-image super-resolution problem

### 1.2.1 The image degradation model

To reason about super-resolution we first need a model of how a low-resolution image is produced from a high-resolution one. The standard and widely used model expresses the LR image $\mathbf{y}$ as the result of blurring the HR image $\mathbf{x}$, downsampling it, and adding noise:

$$\mathbf{y} = (\mathbf{x} \otimes \mathbf{k})\!\downarrow_{s} + \mathbf{n}$$

Here $\otimes$ denotes convolution with a blur kernel $\mathbf{k}$ (which models the point-spread function of the optics and any anti-aliasing filter), $\downarrow_{s}$ denotes downsampling by an integer factor $s$ (the *scale factor*), and $\mathbf{n}$ is additive noise, usually modelled as white and Gaussian. The scale factor $s$ is the number by which each spatial dimension is enlarged: a ×4 task turns a $128\times128$ image into a $512\times512$ image, so the output has $s^{2}=16$ times as many pixels as the input.

In most academic work, including the benchmarks used in Chapter 3, a deliberately simple instance of this model is adopted: the blur kernel is the one implied by **bicubic** downsampling and the noise term is set to zero. This *bicubic degradation* is not fully realistic—real cameras introduce more complex and varied blur—but it has the great advantage of being reproducible, so that different methods can be compared on exactly the same footing. The models developed in this thesis are trained and evaluated under the bicubic setting, and the limitations this implies are discussed in Section 3.11.

![Figure 1.2: The bicubic image-degradation model assumed by the standard benchmarks: blur, downsample, and (optionally) add noise.](figures/fig_1_2_degradation.png)

*Figure 1.2: The bicubic image-degradation model assumed by the standard benchmarks: blur, downsample, and (optionally) add noise.*

### 1.2.2 Ill-posedness and the role of priors

Given the degradation model, super-resolution is the problem of inverting it: recover $\mathbf{x}$ from $\mathbf{y}$. The difficulty is that the operator that maps $\mathbf{x}$ to $\mathbf{y}$ is not invertible. Downsampling by $s$ throws away a fraction $1-1/s^{2}$ of the pixels, and blurring removes high-frequency content; many distinct HR images map to the same LR image. The problem is therefore *ill-posed* in the sense of Hadamard: a unique, stable solution does not exist without further assumptions.

The classical Bayesian way to make the problem well-posed is to introduce a prior $p(\mathbf{x})$ on natural images and seek the *maximum a posteriori* estimate,

$$\hat{\mathbf{x}} = \mathrm{arg}\,\max_{\mathbf{x}}\; p(\mathbf{y}\,|\,\mathbf{x})\,p(\mathbf{x}),$$

where the likelihood $p(\mathbf{y}\,|\,\mathbf{x})$ is determined by the degradation model and the prior $p(\mathbf{x})$ encodes our expectations about plausible images. Every super-resolution method can be understood as a particular choice of prior: interpolation assumes smoothness, sparse-coding methods assume that natural patches are sparse combinations of dictionary atoms, and deep networks learn an extremely rich, implicit prior directly from millions of example patches. The modern, discriminative reformulation drops the explicit probabilistic machinery and instead learns a direct mapping $f_{\theta}$ from LR to HR by minimising a loss over a training set of paired examples:

$$\hat{\theta} = \mathrm{arg}\,\min_{\theta}\; \frac{1}{N}\sum_{i=1}^{N} \mathcal{L}\!\left(f_{\theta}(\mathbf{y}_i),\, \mathbf{x}_i\right).$$

The prior is now hidden in the architecture of $f_{\theta}$ and in the statistics of the training data, but it is present nonetheless. This discriminative formulation, introduced to super-resolution by the SRCNN of Dong et al. [10], underlies every model in this thesis.

### 1.2.3 Evaluation metrics

Two metrics dominate the quantitative evaluation of super-resolution, and both are used throughout Chapter 3.

The **peak signal-to-noise ratio** (PSNR) measures pixel-wise fidelity. For an 8-bit image with maximum value $L=255$ it is defined through the mean squared error (MSE) between the reconstruction $\hat{x}$ and the reference $x$:

$$\mathrm{PSNR} = 10\,\log_{10}\!\left(\frac{L^{2}}{\mathrm{MSE}}\right), \qquad \mathrm{MSE} = \frac{1}{HW}\sum_{p}\left(x_p - \hat{x}_p\right)^{2}.$$

PSNR is expressed in decibels; higher is better, and a difference of a few tenths of a decibel is considered meaningful in this field. Its weakness is that it correlates only loosely with human perception, because it treats every pixel error identically regardless of where it falls.

The **structural similarity index** (SSIM) of Wang et al. [39] was designed to track perceived quality more closely by comparing local luminance, contrast, and structure:

$$\mathrm{SSIM}(x,\hat{x}) = \frac{(2\mu_x\mu_{\hat{x}}+c_1)(2\sigma_{x\hat{x}}+c_2)}{(\mu_x^{2}+\mu_{\hat{x}}^{2}+c_1)(\sigma_x^{2}+\sigma_{\hat{x}}^{2}+c_2)},$$

where $\mu$, $\sigma$, and $\sigma_{x\hat{x}}$ are local means, variances, and covariance computed over a sliding window, and $c_1,c_2$ are small constants that stabilise the division. SSIM ranges from $0$ to $1$; higher is better. Following near-universal convention, both metrics are computed on the luminance (Y) channel of the YCbCr colour space and a few border pixels are cropped before measurement, because the chrominance channels carry little high-frequency detail and the borders are affected by convolution padding. The reasons for this protocol are discussed again in Section 3.5.

## 1.3 A taxonomy of classical super-resolution methods

Before deep learning, super-resolution methods fell into three broad families, illustrated in the left-hand branches of Figure 1.3. Understanding them clarifies what the deep-learning methods improved upon and why certain design choices recur.

![Figure 1.3: A taxonomy of single-image super-resolution methods, from interpolation to deep learning.](figures/fig_1_3_taxonomy.png)

*Figure 1.3: A taxonomy of single-image super-resolution methods, from interpolation to deep learning.*

### 1.3.1 Interpolation-based methods

The simplest approach treats super-resolution as pure interpolation: estimate the unknown pixels of the enlarged grid from the known pixels by fitting a smooth function. Nearest-neighbour, bilinear, bicubic, and Lanczos interpolation differ only in the support and smoothness of that function. Bicubic interpolation, which fits a piecewise cubic polynomial over a $4\times4$ neighbourhood, remains the de-facto baseline against which all super-resolution methods are compared, and it is the degradation operator assumed in the benchmark protocol of Section 1.2.1. Interpolation is extremely fast and free of training, but it embodies only a smoothness prior; it cannot invent the high-frequency detail that downscaling removed, so its outputs are inevitably blurred along edges and textures. Every learned method in this thesis is, at minimum, expected to beat bicubic interpolation by a wide margin.

### 1.3.2 Reconstruction-based methods

Reconstruction-based methods take the degradation model seriously and pose super-resolution as a regularised optimisation: find the HR image that, when passed through the known degradation, best reproduces the observed LR image, subject to a regulariser that enforces a prior such as small total variation or sharp but sparse gradients. These methods can produce crisp edges and respect the imaging physics, but they have two practical drawbacks. First, their performance degrades quickly as the scale factor grows, because the constraint imposed by the LR image becomes progressively weaker relative to the prior. Second, they typically require an iterative solver per image, which is slow. They are most effective when several LR observations of the same scene are available (multi-image super-resolution), a setting outside the scope of this single-image thesis.

### 1.3.3 Classical learning-based methods

The most successful pre-deep-learning approach was *example-based* or *learning-based* super-resolution, which learns the LR-to-HR relationship from a database of example patches. The seminal sparse-representation method of Yang et al. [33] learns a pair of coupled dictionaries—one for LR patches and one for HR patches—such that an LR patch and its HR counterpart share the same sparse code; reconstruction then amounts to computing the sparse code of an input patch against the LR dictionary and applying it to the HR dictionary. Neighbour-embedding methods, and in particular the Anchored Neighbourhood Regression (ANR) of Timofte et al. [32] and its improved variant A+ [31], replace the costly sparse-coding step with a set of precomputed linear regressors anchored to dictionary atoms, achieving a large speed-up at similar quality. The self-exemplar method of Glasner et al. [34] exploits patch recurrence *within* a single image across scales, dispensing with an external database entirely.

These classical learning methods established two ideas that deep learning inherited and amplified: that the LR-to-HR mapping should be *learned from data* rather than hand-designed, and that it can be approximated *patch by patch*. Indeed, Dong et al. [10] observed that their three-layer SRCNN can be interpreted as an end-to-end, jointly optimised generalisation of the sparse-coding pipeline, with the dictionaries and the mapping all folded into convolutional layers. This observation is the conceptual bridge from the classical era to the modern one.

## 1.4 Deep-learning-based super-resolution

The remainder of the review concentrates on convolutional-neural-network methods, because they define the state of the art and because the models of Chapter 2 are built from their components. Figure 1.5 plots the reconstruction quality of the principal methods against their year of publication and reveals the steady climb in accuracy—and, as Section 1.5 will show, the parallel climb in cost.

![Figure 1.5: Timeline of representative deep super-resolution networks and the trends they embody.](figures/fig_1_5_timeline.png)

*Figure 1.5: Timeline of representative deep super-resolution networks and the trends they embody.*

### 1.4.1 The first convolutional network: SRCNN

The modern era began with the **Super-Resolution Convolutional Neural Network** (SRCNN) of Dong et al. [10]. SRCNN first upsamples the LR image to the target size with bicubic interpolation and then applies just three convolutional layers that, in the authors' interpretation, perform patch extraction, non-linear mapping, and reconstruction. Despite its simplicity it decisively outperformed all previous methods, demonstrating that a single network trained end to end on the mean squared error could subsume the entire classical pipeline. SRCNN also exposed the two weaknesses that the next decade of research would attack. First, operating on the bicubically upsampled image means every convolution runs at the *full HR resolution*, which is wasteful. Second, the network was shallow, and the authors reported that naively adding layers did not help—training deeper networks for super-resolution turned out to require new ideas.

### 1.4.2 Going deeper with residual learning: VDSR, DRCN, DRRN

The breakthrough that unlocked depth was **residual learning**. Kim et al.'s **VDSR** [13] observed that the LR and HR images share their low-frequency content, so the network need only predict the *residual*—the high-frequency difference—rather than the whole image. Predicting a mostly-zero residual is an easier optimisation problem, and with this single change VDSR successfully trained a 20-layer network and improved markedly on SRCNN. The same paper popularised gradient clipping with a high learning rate to accelerate convergence. The **Deeply-Recursive Convolutional Network** (DRCN) [14] and the **Deep Recursive Residual Network** (DRRN) [15] pushed depth further while controlling parameter count by *reusing* the same convolutional weights recursively, an early example of the parameter-sharing idea that recurs in the efficient models of Chapter 2. The **MemNet** of Tai et al. [16] introduced explicit memory blocks with dense connections to let later layers access the features of earlier ones. All of these methods, like SRCNN, operate in the pre-upsampled HR space and therefore remain computationally heavy.

### 1.4.3 Computing in LR space: FSRCNN and ESPCN

Two influential 2016 papers attacked SRCNN's first weakness—its wasteful HR-space computation—and in doing so defined the architecture adopted in this thesis. Dong et al.'s **FSRCNN** [11] redesigned SRCNN into an hourglass shape that takes the *original* LR image as input, does all of its work at LR resolution, and only enlarges the image at the very end with a learned **deconvolution** (transposed convolution) layer. Combined with shrinking and expanding $1\times1$ layers that keep the feature dimension low in the middle, FSRCNN ran more than forty times faster than SRCNN with even better quality. In parallel, Shi et al.'s **ESPCN** [12] introduced the **efficient sub-pixel convolution** layer—also called *pixel shuffle*—which produces $s^{2}$ LR-resolution feature maps and then rearranges them periodically into a single HR image. Sub-pixel convolution is now the standard upsampling operator in efficient super-resolution, and it is the operator used by both models in Chapter 2; its mechanics are detailed in Section 2.1.2. The principle these two papers established—**post-upsampling**, in which the deep body of the network runs at LR resolution and only the final stage enlarges the image—is contrasted with the older **pre-upsampling** design in Figure 1.4 and is the single most important efficiency idea in this thesis.

![Figure 1.4: Pre-upsampling versus post-upsampling network designs. Post-upsampling computes in the low-resolution space and upsamples only at the end.](figures/fig_1_4_pre_post.png)

*Figure 1.4: Pre-upsampling versus post-upsampling network designs. Post-upsampling computes in the low-resolution space and upsamples only at the end.*

### 1.4.4 Residual and dense architectures: SRResNet, EDSR, RDN, SRDenseNet

As the ResNet architecture [40] reshaped image classification, its residual block was imported into super-resolution. Ledig et al.'s **SRResNet** [18] stacked many residual blocks in LR space with sub-pixel upsampling and set a new quality standard. Lim et al.'s **EDSR** [19] then made a deceptively simple but important observation: the **batch-normalisation** layers [42] that are standard in classification networks actually *hurt* super-resolution, because they discard the range information of the features that the task needs to preserve. Removing batch normalisation, widening the network, and adding residual scaling let EDSR win the 2017 NTIRE challenge and remain, years later, one of the strongest models in terms of pure PSNR. The removal of batch normalisation is a design choice that this thesis adopts and explains in Section 2.1.3. The **Residual Dense Network** (RDN) [20] combined residual and dense connections so that every layer's features are accessible to every later layer, and **SRDenseNet** [27] likewise applied dense blocks. These networks are accurate but extremely large—EDSR has more than forty million parameters—which is precisely the cost problem this thesis sets out to address.

### 1.4.5 Attention mechanisms: RCAN

A further accuracy gain came from **attention**. Zhang et al.'s **RCAN** [21] noted that the many channels of a feature map are not equally informative, and inserted a **channel-attention** module—borrowed from the Squeeze-and-Excitation network [46]—that learns to rescale each channel according to its global importance. Wrapped in a residual-in-residual structure exceeding four hundred layers, RCAN achieved the best PSNR of its generation. Channel attention is attractive for efficient models because it adds very few parameters and operations while measurably improving quality; a lightweight, contrast-aware variant of it is one of the two improvements in Section 2.2 of this thesis.

### 1.4.6 Lightweight and efficient networks: CARN, IDN, IMDN, RFDN

The line of work most directly related to this thesis is the explicit pursuit of *efficiency*. Ahn et al.'s **CARN** [22] introduced a **cascading** mechanism in which the outputs of all preceding blocks are concatenated and fused by $1\times1$ convolutions, so that features are reused rather than recomputed; a parameter-shared variant reduced the model further. Hui et al.'s **IDN** [23] proposed **information distillation**: at each step the features are split, one part is retained ("distilled") and set aside, and the other part is processed further, so that short- and long-path information are gathered cheaply. The follow-up **IMDN** [24] refined this into an information multi-distillation block and added a contrast-aware channel attention that, unlike the mean-only attention of SENet, also uses the standard deviation of each channel—a detail that matters for super-resolution and is adopted in Section 2.2.3. **RFDN** [25] re-expressed the distillation idea with feature-distillation connections and won the efficiency track of a subsequent challenge. These four networks are the closest competitors to the models proposed here, and they are the primary efficiency-oriented baselines in Chapter 3. The two models in Chapter 2 are deliberately built from the most effective and well-understood of these ideas—post-upsampling, residual learning, distillation, cascading, and contrast-aware attention—rather than from novel but fragile mechanisms.

### 1.4.7 Perceptual super-resolution: SRGAN and ESRGAN

A separate branch optimises *perceptual* quality rather than pixel fidelity. SRGAN [18] trains the network adversarially against a discriminator and adds a feature-space "perceptual" loss computed on a pretrained VGG network [41], producing images that look sharp and realistic to humans even though their PSNR is *lower* than that of fidelity-optimised models. **ESRGAN** [28] improved the generator and the adversarial training and is widely used where visual realism matters more than measured accuracy. Because perceptual methods trade measurable fidelity for realism and are evaluated with different criteria, they are outside the scope of this thesis, which targets the PSNR/SSIM-optimal, efficiency-constrained regime; they are mentioned here for completeness and revisited as future work in Section 3.11.

## 1.5 The accuracy–efficiency dilemma

The literature reviewed above exhibits a clear and troubling pattern, which Table 1.1 makes explicit. From SRCNN to RCAN, reconstruction quality on the standard ×4 Set5 benchmark rose by more than two decibels—a large gain—but the cost of obtaining it rose far faster. SRCNN has about 57 thousand parameters; EDSR has 43 million and RCAN 15.6 million, increases of roughly three orders of magnitude. The number of floating-point operations grew in step, and the pre-upsampling networks compounded the problem by running every operation at full HR resolution. The result is that the most accurate networks cannot run at interactive speed on a mobile or embedded device, which is exactly where super-resolution is most wanted.

| Method | Year | Type | Params | Key idea | Set5 ×4 PSNR (dB) |
|---|---|---|---|---|---|
| SRCNN [10] | 2014 | CNN | 57 K | First end-to-end CNN for SR | 30.48 |
| FSRCNN [11] | 2016 | CNN | 12 K | LR-space computation, deconvolution | 30.71 |
| ESPCN [12] | 2016 | CNN | 20 K | Sub-pixel convolution | 30.52 |
| VDSR [13] | 2016 | Deep CNN | 665 K | 20 layers, global residual learning | 31.35 |
| DRRN [15] | 2017 | Recursive | 297 K | Recursive residual blocks | 31.68 |
| LapSRN [17] | 2017 | Pyramid | 813 K | Progressive Laplacian upsampling | 31.54 |
| EDSR [19] | 2017 | Deep ResNet | 43 M | BN-free deep residual network | 32.46 |
| RCAN [21] | 2018 | Deep + attention | 15.6 M | Residual-in-residual + channel attention | 32.63 |
| IDN [23] | 2018 | Lightweight | 553 K | Information distillation | 31.82 |
| CARN [22] | 2018 | Lightweight | 1.59 M | Cascading residual network | 32.13 |
| IMDN [24] | 2019 | Lightweight | 715 K | Multi-distillation | 32.21 |
| **ESRN-B (ours)** | — | Lightweight | **0.62 M** | LR-space + global residual | **32.06** |
| **ESRN-D (ours)** | — | Lightweight | **0.78 M** | Distillation + cascading + CCA | **32.28** |

*Table 1.1: Representative single-image super-resolution methods. PSNR is for ×4 on Set5.*

Three observations sharpen the problem and point toward its solution. First, **most of the cost buys very little quality at the top end**: the gap between a 1.5-million-parameter lightweight model and a 43-million-parameter heavy one is often only two to four tenths of a decibel, while the gap between bicubic and the lightweight model is two whole decibels. The marginal return on parameters is steeply diminishing. Second, **where the computation happens matters as much as how much of it there is**: a pre-upsampling network wastes a factor of $s^{2}$ by operating at HR resolution, a factor of sixteen at ×4, that buys nothing. Third, **features are routinely recomputed when they could be reused**: dense and cascading connections show that giving later layers cheap access to earlier features improves quality at almost no cost. These three observations—diminishing returns on depth, the value of LR-space computation, and the value of feature reuse—are the foundation of the design philosophy in Chapter 2.

## 1.6 Problem statement and research objectives

The problem this thesis addresses can now be stated precisely.

> *Given the bicubic single-image super-resolution task at scale factors ×2, ×3, and ×4, design convolutional models that recover image quality competitive with state-of-the-art lightweight networks—and within a small margin of much larger networks—while keeping the parameter count below roughly one million and the runtime low enough for practical deployment, and justify every design choice by its rationale and measured effect rather than by assertion.*

This breaks down into the following concrete objectives:

1. **Formulate and adopt an efficient backbone** that performs all heavy computation in LR space and upsamples only once, at the end, thereby eliminating the $s^{2}$ waste of pre-upsampling networks (addressed in Section 2.1).
2. **Stabilise and accelerate training** of that backbone through residual learning and normalisation choices appropriate to super-resolution, so that a compact network reaches high quality quickly (Section 2.1).
3. **Increase quality without increasing cost** by reusing features through distillation and cascading rather than by adding depth (Section 2.2).
4. **Recalibrate features cheaply** with a contrast-aware channel-attention mechanism suited to the statistics of super-resolution features (Section 2.2).
5. **Build a complete, reproducible system** around the models and evaluate it rigorously against prior methods on standard benchmarks, including parameter, FLOP, and runtime comparisons and ablation studies that isolate the contribution of each design choice (Chapter 3).

A guiding constraint, stated here and respected throughout, is restraint: each of the two models introduces only **two** genuinely new or carefully re-engineered features, and the thesis argues for their validity in depth rather than claiming a long list of shallow innovations.

## 1.7 Contributions and organisation of the thesis

The contributions of this thesis are:

- A clear, self-contained analysis of the accuracy–efficiency dilemma in single-image super-resolution, distilled into three actionable design principles (Section 1.5).
- **ESRN-B**, a compact residual super-resolution network that computes entirely in LR space with sub-pixel upsampling and uses global residual learning with batch-normalisation-free, weight-normalised blocks; the rationale and validity of both improvements are analysed in Section 2.1.
- **ESRN-D**, a distillation-and-cascade network that adds progressive information-distillation blocks and a contrast-aware channel-attention mechanism with cascading feature reuse, analysed in Section 2.2.
- A complete training and inference system and a thorough experimental evaluation against prior methods at three scale factors on four benchmarks, with parameter, FLOP, runtime, and ablation analyses (Chapter 3).

The remainder of the thesis is organised as follows. **Chapter 2** describes the two models, devoting one section to each and explaining in detail the rationale and validity of the two improvements that each contributes. **Chapter 3** constructs the system, specifies its implementation, defines the evaluation protocol, and reports the experimental results, including the required comparison against prior methods, followed by ablation studies, a discussion of limitations, and concluding remarks. The references cited above by number are listed at the end of the thesis.


---

# Chapter 2. Effective Image Super-Resolution Models

## 2.0 Design philosophy and overview

Chapter 1 ended with three design principles drawn from the literature: depth yields steeply diminishing returns, so a compact network is preferable; computation should happen in low-resolution space, because operating at HR resolution wastes a factor of $s^{2}$; and features should be reused rather than recomputed, because feature reuse buys quality almost for free. This chapter turns those principles into two concrete models.

The two models form a deliberate progression. The first, **ESRN-B** ("B" for *base*), establishes a strong, efficient backbone and is described in Section 2.1. It contributes two improvements: it performs all computation in LR space and upsamples only at the end with a sub-pixel convolution, and it trains stably and quickly through global residual learning combined with batch-normalisation-free, weight-normalised residual blocks. The second model, **ESRN-D** ("D" for *distillation*), described in Section 2.2, keeps the same efficient backbone and adds two further improvements aimed at raising quality without raising cost: it replaces the plain residual blocks with information-distillation blocks that progressively retain features, and it introduces cascading feature reuse together with a contrast-aware channel-attention module. In keeping with the restraint stated in Section 1.6, each section introduces exactly two improvements, and the bulk of each section is spent explaining *why* the improvement works and *why* it is valid, rather than merely stating that it was made.

A note on terminology and notation is in order before the details. Throughout, $\mathbf{y}$ is the LR input, $\hat{\mathbf{x}}$ the network's HR output, $s$ the scale factor, $C$ the number of feature channels in the network body, and $B$ the number of residual or distillation blocks. A "$k\times k$ conv" denotes a two-dimensional convolution with a $k\times k$ spatial kernel; unless stated otherwise convolutions preserve the spatial size by zero-padding and act on $C$ input and $C$ output channels. The non-linearity $\sigma$ is the rectified linear unit (ReLU) [49] unless noted. Both models predict only the luminance channel; the chrominance channels are upsampled bicubically, as justified in Section 3.5.

## 2.1 Section 1 — ESRN-B: an efficient residual backbone

### 2.1.1 Architecture overview

ESRN-B follows the post-upsampling template established by FSRCNN [11] and ESPCN [12] and refined by EDSR [19]. It has three stages, shown in Figure 2.1:

1. a **head** of a single $3\times3$ convolution that maps the one-channel LR input to a $C$-channel feature representation, $F_{0}=H_{\mathrm{head}}(\mathbf{y})$;
2. a **body** of $B$ residual blocks operating entirely at LR resolution, followed by one $3\times3$ convolution, producing a residual feature map $\mathcal{R}(F_{0})$;
3. a **tail** that adds the head features back via a global skip connection and then upsamples once with a sub-pixel convolution to produce the HR output.

![Figure 2.1: Architecture of the proposed ESRN-B model: a head convolution, a body of residual blocks, a global skip connection, and a sub-pixel upsampling tail.](figures/fig_2_1_modelA.png)

*Figure 2.1: Architecture of the proposed ESRN-B model: a head convolution, a body of residual blocks, a global skip connection, and a sub-pixel upsampling tail.*

Compactly, the whole network computes

$$\hat{\mathbf{x}} = \mathcal{U}\!\left(F_{0} + \mathcal{R}(F_{0})\right), \qquad F_{0} = H_{\mathrm{head}}(\mathbf{y}),$$

where $\mathcal{U}$ is the sub-pixel upsampling operator described below. The default configuration uses $C=48$ channels and $B=16$ residual blocks, giving roughly 0.62 million parameters at ×4—about seventy times fewer than EDSR. The complete layer specification is given in Table 2.1.

| Stage | Layer | Kernel | In → Out channels | Output size |
|---|---|---|---|---|
| Head | Conv | 3×3 | 3 → 48 | H × W |
| Body | 16 × residual block (Conv–ReLU–Conv, scaling λ = 0.1) | 3×3 | 48 → 48 | H × W |
| Body | Body-end Conv + global skip add | 3×3 | 48 → 48 | H × W |
| Tail | Conv (expand for upsampling) | 3×3 | 48 → 3s² | H × W |
| Tail | Sub-pixel convolution (pixel shuffle ×s) | — | 3s² → 3 | sH × sW |

*Table 2.1: Layer specification of ESRN-B (C = 48 channels, B = 16 residual blocks). Spatial size is given for an H×W low-resolution input and scale factor s.*

The two improvements that distinguish ESRN-B from a naive stack of convolutions are the subject of the next two subsections. Improvement 1 concerns *where* the network computes and *how* it upsamples; Improvement 2 concerns *how* it is trained to converge.

### 2.1.2 Improvement 1 — low-resolution computation with sub-pixel convolution

**What it is.** Every convolution in the head and body of ESRN-B operates on feature maps whose spatial size equals that of the *low-resolution* input, $H\times W$. The network never works at the larger $sH\times sW$ resolution until the very last operation, the sub-pixel convolution (also called *pixel shuffle*), which enlarges the image in a single step. A sub-pixel convolution first uses an ordinary convolution to produce $s^{2}$ feature maps of size $H\times W$ and then rearranges these maps periodically into one map of size $sH\times sW$ by the deterministic shuffle

$$\mathrm{PS}(T)_{i,j,c} = T_{\lfloor i/s\rfloor,\,\lfloor j/s\rfloor,\; c\, s^{2} + s\,(i\,\mathrm{mod}\,s) + (j\,\mathrm{mod}\,s)}.$$

In words, the $s\times s$ block of HR pixels around output location $(i,j)$ is filled by reading one value from each of $s^{2}$ corresponding LR feature maps. The operation is illustrated in Figure 2.2. It has no parameters of its own beyond the convolution that produces the $s^{2}$ maps, and it is exactly invertible, so no information is lost in the rearrangement.

![Figure 2.2: Sub-pixel convolution (pixel shuffle): an LR-space tensor with s²C channels is rearranged into an HR-space tensor with C channels.](figures/fig_2_2_subpixel.png)

*Figure 2.2: Sub-pixel convolution (pixel shuffle): an LR-space tensor with s²C channels is rearranged into an HR-space tensor with C channels.*

**Why it works — the rationale.** The cost of a convolutional layer is proportional to the number of spatial locations it is applied at. A pre-upsampling network of the SRCNN or VDSR family first enlarges the image to $sH\times sW$ and then runs its entire body at that resolution. Writing $C_{l}$ for the channel count and $k_{l}$ for the kernel size of layer $l$, the total work of such a network is approximately

$$\mathcal{O}_{\mathrm{pre}} \approx s^{2}\,H W \sum_{l} C_{l-1} C_{l}\, k_{l}^{2}.$$

The factor $s^{2}$ multiplies *every* layer. A post-upsampling network performs the identical convolutions on $H\times W$ feature maps and therefore costs

$$\mathcal{O}_{\mathrm{post}} \approx H W \sum_{l} C_{l-1} C_{l}\, k_{l}^{2} = \frac{1}{s^{2}}\,\mathcal{O}_{\mathrm{post}}.$$

The body of a post-upsampling network is thus $s^{2}$ times cheaper—a factor of four at ×2, nine at ×3, and sixteen at ×4—for *exactly the same number of layers and channels*. This is not a small constant-factor tweak; it is the dominant lever on efficiency, and it is the first reason ESRN-B can be both compact and accurate.

The choice of sub-pixel convolution over the transposed convolution used by FSRCNN deserves its own justification, because both move computation to LR space. Transposed convolution enlarges the image by inserting zeros between input pixels and convolving, a process that is prone to producing periodic "checkerboard" artifacts when the kernel size is not divisible by the stride, because adjacent output pixels are covered by different numbers of kernel taps. Sub-pixel convolution avoids this failure mode entirely: it learns $s^{2}$ independent filters that each predict one fixed sub-pixel position, and the periodic shuffle that follows is a pure data rearrangement with no overlap and therefore no uneven coverage. The two operations have the same parameter count and arithmetic cost—the equivalence between a transposed convolution and a convolution-plus-shuffle is exact—so sub-pixel convolution is preferred purely for its better-conditioned, artifact-free behaviour.

**Why it is valid — addressing the obvious objection.** The natural worry about computing in LR space is that the network might "see" less context and therefore reconstruct worse. This worry is unfounded, and it is worth saying why precisely. A $3\times3$ convolution applied at LR resolution covers, after upsampling, an effective $3s\times3s$ region of the HR grid; the receptive field measured in HR pixels is *identical* whether the network operates before or after upsampling, because upsampling is a fixed geometric rescaling that commutes with the notion of spatial context. What changes is only the number of grid points at which the (identical) filters are evaluated. Empirically, FSRCNN and ESPCN already demonstrated that LR-space computation matches or exceeds the quality of HR-space computation while being far cheaper, and every strong efficient network since—CARN, IDN, IMDN, RFDN—has adopted it. The ablation in Section 3.9.1 confirms this for ESRN-B directly: moving from a pre-upsampling to a post-upsampling design *raises* PSNR slightly while cutting the body's cost by a factor of $s^{2}$. The improvement is therefore valid in the strong sense that it reduces cost without any quality penalty, indeed with a small quality gain attributable to the artifact-free upsampler.

### 2.1.3 Improvement 2 — global residual learning with normalisation-free, weight-normalised blocks

**What it is.** ESRN-B is trained to predict a *residual* rather than the image itself, at two levels. Globally, the head features $F_{0}$ are added back to the body output before upsampling, as written in the architecture equation above; this long skip connection lets the body concentrate on the high-frequency detail that distinguishes the HR image from a trivially upsampled LR image. Locally, each block in the body is itself residual,

$$F_{l} = F_{l-1} + \lambda\, W_{2}\,\sigma\!\left(W_{1} F_{l-1}\right),$$

a two-convolution block with a ReLU between and a residual-scaling factor $\lambda$ (set to $0.1$). Crucially, the blocks contain **no batch-normalisation** layers; instead the convolution weights are **weight-normalised** [48], i.e. each filter $\mathbf{w}$ is reparameterised as $\mathbf{w}=g\,\mathbf{v}/\|\mathbf{v}\|$ with a learned scalar gain $g$ and direction $\mathbf{v}$. The block structure is the middle variant in Figure 2.3.

![Figure 2.3: The batch-normalisation-free, weight-normalised residual block with residual scaling used in ESRN-B (right), compared with a conventional residual block (left).](figures/fig_2_3_resblocks.png)

*Figure 2.3: The batch-normalisation-free, weight-normalised residual block with residual scaling used in ESRN-B (right), compared with a conventional residual block (left).*

**Why global residual learning works — the rationale.** The LR input and the HR target are, after upsampling, mostly identical: they agree on all the low-frequency content and differ only in the high-frequency detail that downscaling removed. If a network is asked to output the entire HR image, most of its capacity is spent re-creating the low frequencies that are already present in the input—a wasteful "identity-plus-correction" that the network must learn from scratch. Residual learning hands the identity part to the network for free through the skip connection, so the trainable layers only have to predict the correction, whose values are small and centred near zero. This has two beneficial effects. It makes the optimisation landscape easier, because a near-zero residual is a gentle target that the network can approach from its initialisation; and it improves gradient flow, because the skip connection provides a short, unobstructed path from the loss to the early layers, mitigating the vanishing-gradient problem that historically prevented deep super-resolution networks from training (recall from Section 1.4.1 that SRCNN's authors could not benefit from added depth). VDSR [13] demonstrated exactly this effect when it first used global residual learning to train a 20-layer network. Figure 3.7 in Chapter 3 shows the same effect for ESRN-B: removing the global skip connection slows convergence dramatically and lowers the final PSNR.

**Why removing batch normalisation is correct — the rationale.** Batch normalisation [42] standardises each feature channel to zero mean and unit variance over the training batch, which is enormously helpful in classification, where only the *presence* of a feature matters and its absolute scale is irrelevant. Super-resolution is different: it is a regression task in which the *absolute intensities* of the output must match the target precisely, and the contrast and brightness range of the features carry information that the final reconstruction needs. Batch normalisation throws this range information away by rescaling every feature to unit variance, and it also couples the prediction for one image to the statistics of the other images that happen to share its batch, which is undesirable when each image should be reconstructed on its own terms. EDSR [19] showed empirically that removing batch normalisation *improves* super-resolution quality while also freeing the memory the normalisation layers consumed, allowing a larger model in the same budget. ESRN-B follows this finding.

Removing batch normalisation, however, removes the stabilising effect it had on training very deep stacks of convolutions, so something must replace it. ESRN-B uses **weight normalisation**, which decouples the length and direction of each weight vector and normalises only the direction. Unlike batch normalisation, weight normalisation does not touch the feature *activations*—it leaves their intensities and contrast untouched, so it does not damage the range information that super-resolution needs—yet it conditions the optimisation by keeping the effective gradient scale stable across layers. It is also a per-weight operation independent of the batch, so it introduces none of the batch-coupling that makes batch normalisation inappropriate here. The residual-scaling factor $\lambda=0.1$ plays a complementary stabilising role: by attenuating each block's contribution before it is added to the skip path, it keeps the variance of the accumulated signal from growing with depth, which would otherwise destabilise training in a normalisation-free network.

**Why the combination is valid.** The concern with a normalisation-free network is training instability, and the concern with weight normalisation specifically is that it might not be powerful enough to replace batch normalisation. Both concerns are answered by the convergence behaviour reported in Section 3.9.3 and Figure 3.7: ESRN-B trains smoothly to a higher final PSNR than an otherwise identical network that uses batch normalisation, and substantially higher than one with neither normalisation nor weight normalisation. The combination of global residual learning (which eases the target and the gradient flow), residual scaling (which controls signal growth with depth), and weight normalisation (which conditions the optimisation without harming activations) is therefore validated both by its theoretical fit to the regression nature of super-resolution and by the measured training curves. This is the second improvement of ESRN-B.

### 2.1.4 Complexity analysis

It is useful to quantify the cost of ESRN-B explicitly, because the whole point of the design is efficiency. The receptive field of a stack of $L$ convolutions with kernel sizes $k_{l}$ and strides $s_{l}$ grows as

$$r_{L} = 1 + \sum_{l=1}^{L} (k_{l}-1)\prod_{i=1}^{l-1} s_{i}.$$

With all strides equal to one and all kernels $3\times3$, the $B=16$ residual blocks (two convolutions each) plus the head and the pre-upsampling convolution give a receptive field of $r=2(2B+2)+1=67$ LR pixels, which corresponds to a $67s$-pixel region of the HR image—ample context for the local detail super-resolution must synthesise. The parameter count is dominated by the body: each residual block holds $2\times(3^{2}C^{2})=18C^{2}$ weights, so $B$ blocks hold $18BC^{2}$, which for $C=48$, $B=16$ is about $0.66$ million, before the small head and tail. The arithmetic cost, following $\mathcal{O}_{\mathrm{post}}$ above, scales with $HW$ rather than $s^{2}HW$, so a ×4 reconstruction of a $480\times320$ image costs the same in the body as a ×2 reconstruction of the same input—the body is oblivious to the scale factor, which appears only in the tail. Table 2.3 collects these quantities and compares them with representative baselines. The headline figures are summarised again with measured runtimes in Section 3.7.

| Method | Params (M) | FLOPs (G) | Set5 ×4 PSNR (dB) |
|---|---|---|---|
| SRCNN [10] | 0.057 | 52.7 | 30.48 |
| VDSR [13] | 0.665 | 612.6 | 31.35 |
| LapSRN [17] | 0.813 | 149.4 | 31.54 |
| IDN [23] | 0.553 | 32.3 | 31.82 |
| CARN [22] | 1.592 | 90.9 | 32.13 |
| IMDN [24] | 0.715 | 40.9 | 32.21 |
| EDSR [19] | 43.0 | 2895 | 32.46 |
| RCAN [21] | 15.6 | 918 | 32.63 |
| **ESRN-B (ours)** | **0.62** | **35.6** | **32.06** |

*Table 2.3: Complexity of ESRN-B compared with representative baselines. FLOPs are for producing a 1280×720 output at ×4; PSNR is for Set5 ×4.*

### 2.1.5 Discussion

ESRN-B is intentionally simple. It contributes nothing exotic; its two improvements—LR-space computation with sub-pixel upsampling, and global residual learning in a normalisation-free, weight-normalised network—are each individually known from the literature. The value added here is in *combining them coherently in a deliberately compact network and justifying each choice on the merits*. The result, as Chapter 3 will show, is a 0.62-million-parameter network that already matches the much larger CARN on several benchmarks. ESRN-B serves both as a strong stand-alone model for the most resource-constrained settings and as the backbone on which the more capable ESRN-D is built.

## 2.2 Section 2 — ESRN-D: distillation and cascading for higher quality at the same cost

### 2.2.1 Architecture overview

ESRN-D keeps the head, the LR-space computation, the global residual connection, the sub-pixel tail, and the normalisation-free, weight-normalised philosophy of ESRN-B unchanged. What it changes is the *body*: the plain residual blocks are replaced by **information-distillation blocks** (IDBs), and the IDBs are wired together with **cascading** connections and finished with a **contrast-aware channel-attention** module. The overall structure is shown in Figure 2.4, and the internal structure of one IDB in Figure 2.5. The default configuration uses $C=48$ channels and $B=12$ distillation blocks, giving about 0.78 million parameters at ×4—still comfortably under the one-million target set in Section 1.6, and only a quarter more than ESRN-B. The full specification is in Table 2.2.

![Figure 2.4: Architecture of the proposed ESRN-D model: a cascade of information-distillation blocks with feature reuse and contrast-aware channel attention.](figures/fig_2_4_modelB.png)

*Figure 2.4: Architecture of the proposed ESRN-D model: a cascade of information-distillation blocks with feature reuse and contrast-aware channel attention.*

| Stage | Layer | Kernel | In → Out channels | Output size |
|---|---|---|---|---|
| Head | Conv | 3×3 | 3 → 48 | H × W |
| Body | 12 × information-distillation block (3 distillation steps + CCA) | 3×3 | 48 → 48 | H × W |
| Body | Cascading concatenation + 1×1 fusion | 1×1 | 12·48 → 48 | H × W |
| Body | Body-end Conv + global skip add | 3×3 | 48 → 48 | H × W |
| Tail | Conv (expand for upsampling) | 3×3 | 48 → 3s² | H × W |
| Tail | Sub-pixel convolution (pixel shuffle ×s) | — | 3s² → 3 | sH × sW |

*Table 2.2: Layer specification of ESRN-D (C = 48 channels, B = 12 distillation blocks, distillation ratio 1/4).*

The two improvements of ESRN-D are the information-distillation block (Improvement 1, Section 2.2.2) and the combination of cascading feature reuse with contrast-aware channel attention (Improvement 2, Section 2.2.3). As before, the emphasis is on rationale and validity.

### 2.2.2 Improvement 1 — information-distillation blocks

**What it is.** A plain residual block processes its input with two convolutions and passes the full result on; nothing is set aside, and the block's intermediate representations are visible only to the next block. An information-distillation block instead processes its input in several short steps and, at each step, *splits* the features into two parts: a small "distilled" part that is retained and carried directly to the block's output, and a larger "remaining" part that is processed by the next step. Formally, writing $R_{0}=F_{\mathrm{in}}$ for the block input and applying a convolution followed by a split at each step $j$,

$$D_{j},\,R_{j} = \mathrm{Split}\!\left(\sigma(W_{j} R_{j-1})\right), \qquad R_{0}=F_{\mathrm{in}},$$

the distilled parts $D_{1},\dots,D_{B'}$ from all steps (the last step's full output is also retained) are concatenated, recalibrated by the contrast-aware attention of Improvement 2, fused by a $1\times1$ convolution, and added to the block input through a local residual connection:

$$F_{\mathrm{out}} = F_{\mathrm{in}} + W_{f}\!\left(\mathrm{CCA}\!\left(\mathrm{Concat}[D_{1},\dots,D_{B}]\right)\right).$$

The mechanism is drawn in Figure 2.5. In ESRN-D each IDB uses three distillation steps with a distillation ratio of one quarter, meaning that one quarter of the channels are retained at each step and three quarters are passed on.

![Figure 2.5: The information-distillation block: at each step a fraction of the features is retained and the remainder is processed further, then all retained features are fused.](figures/fig_2_5_idb.png)

*Figure 2.5: The information-distillation block: at each step a fraction of the features is retained and the remainder is processed further, then all retained features are fused.*

**Why it works — the rationale.** The distillation mechanism is a cheap way to give a block a *multi-depth* view of its input. The features retained at the first step have passed through only one convolution and therefore capture shallow, local structure; those retained at the last step have passed through several convolutions and capture deeper, more abstract structure. By concatenating distilled features from every depth, the block's output simultaneously contains information processed to several different degrees, which a single plain residual block of the same parameter count cannot offer because it exposes only its final, deepest representation. This is the same intuition that motivates dense connections [20, 27], but distillation realises it far more cheaply: instead of concatenating *all* intermediate features (which makes the fusion convolution's cost grow quadratically with depth), it concatenates only the small retained slices, so the fusion stays cheap. The split also acts as a built-in form of feature selection—the network learns, through the convolution weights that feed each split, which information is worth retaining early and which should be processed further—so capacity is not wasted re-deriving features that were already adequate after one step.

**Why it is valid.** The legitimate concern is that splitting and retaining might be no better than simply making a plain block wider or deeper with the same parameter budget. Two pieces of evidence answer this. Theoretically, the distillation block and a plain block with matched parameters differ in *what they expose to the rest of the network*, not merely in their internal width: the distillation block exports a mixture of shallow and deep features, whereas the plain block exports only deep features, and the cascading connections of Improvement 2 then make that richer export available network-wide. Empirically, IDN [23] and IMDN [24] established that distillation blocks outperform plain residual blocks of equal cost on every standard benchmark, and the ablation in Section 3.9.1 reproduces this for ESRN-D: swapping the IDBs of ESRN-D for the plain residual blocks of ESRN-B, at matched parameter count, lowers PSNR measurably. The improvement is therefore valid in the sense that it converts a fixed parameter budget into higher quality than the obvious alternative use of that budget.

### 2.2.3 Improvement 2 — cascading feature reuse with contrast-aware channel attention

This improvement has two tightly coupled parts that are presented together because they work in concert: cascading connections that reuse features across blocks, and a contrast-aware channel-attention module that recalibrates those features cheaply.

**Cascading — what it is and why it works.** In a plain sequential body, block $m$ sees only the output of block $m-1$; the outputs of earlier blocks are no longer accessible. Cascading, introduced for super-resolution by CARN [22], makes every earlier block's output available to every later stage by concatenating them and fusing with a $1\times1$ convolution:

$$G_{m} = H_{m}\!\left(\mathrm{Concat}[\,G_{0}, G_{1}, \dots, G_{m-1}\,]\right).$$

The rationale is feature reuse, the third design principle of Section 1.5. A feature computed by an early block—say, an oriented edge response—is often useful again much later in the network, but in a sequential design it must be recomputed from scratch because it was overwritten. Cascading lets the later stage simply read the early feature back, spending only the negligible cost of a $1\times1$ fusion instead of the full cost of recomputation. This both saves capacity, which a compact network cannot spare, and shortens the gradient path from the loss to every block, which aids training for the same reason the global residual connection does. The cost is modest and controllable: the $1\times1$ fusion convolutions add parameters proportional to the number of blocks being fused, not to the spatial size, and a bottleneck can cap the fused channel count if needed.

**Contrast-aware channel attention — what it is and why it works.** Channel attention, as introduced by SENet [46] and brought to super-resolution by RCAN [21], rescales each feature channel by a learned weight that reflects the channel's global importance. The standard mechanism squeezes each channel to a single number by *global average pooling*, passes the resulting vector through a small two-layer bottleneck, and applies a sigmoid to obtain per-channel gates:

$$w = \sigma\!\left(W_{2}\,\delta(W_{1}\,\mathrm{GAP}(F))\right), \qquad F' = w \odot F.$$

ESRN-D uses a variant, following IMDN [24], that is better matched to the statistics of super-resolution features: instead of summarising each channel by its mean alone, it uses the mean **plus the standard deviation**,

$$z_c = \mu_c + \sigma_c = \frac{1}{HW}\sum_{p} F_{c,p} + \sqrt{\frac{1}{HW}\sum_{p}\left(F_{c,p}-\mu_c\right)^{2}}.$$

The module is drawn in Figure 2.6. The rationale for adding the standard deviation is specific to image restoration. Global average pooling measures only the average activation of a channel, which reflects low-frequency content; but the channels that matter most for super-resolution are precisely those that respond to *high-contrast structure*—edges, corners, and textures—whose hallmark is high *variance*, not high mean. A channel that fires strongly along a few sharp edges but is quiet elsewhere has a modest mean yet a large standard deviation, and average pooling alone would under-weight it exactly when it carries the high-frequency detail the reconstruction needs. Including the standard deviation makes the attention "contrast-aware" and lets it emphasise the structurally informative channels. The cost of the whole module is tiny: the pooling collapses the spatial dimensions, so the two bottleneck convolutions operate on length-$C$ vectors and add only a few thousand parameters and a negligible number of operations.

![Figure 2.6: Contrast-aware channel attention (CCA): channel descriptors combine mean and standard deviation, so high-contrast structural channels are emphasised.](figures/fig_2_6_cca.png)

*Figure 2.6: Contrast-aware channel attention (CCA): channel descriptors combine mean and standard deviation, so high-contrast structural channels are emphasised.*

**Why the combination is valid.** Cascading and contrast-aware attention are complementary, and their joint validity rests on three observations. First, both are *cheap*: cascading adds only $1\times1$ fusions and attention adds only vector-sized bottlenecks, so together they raise the parameter count of ESRN-D over ESRN-B by less than a third while raising quality by substantially more than a third of the ESRN-B-to-EDSR gap (Section 3.6). Second, they are *independent of the backbone's efficiency*: neither touches the LR-space computation or the sub-pixel tail, so the $s^{2}$ saving of Section 2.1.2 is preserved intact. Third, their individual contributions are *isolable and confirmed*: the cumulative ablation of Section 3.9.1 (Figure 3.6a) adds first cascading and then contrast-aware attention on top of the distillation backbone and shows a clear, monotonic PSNR gain at each step, while a control experiment using mean-only attention instead of contrast-aware attention recovers part but not all of the gain—direct evidence that the standard-deviation term is doing useful work rather than merely adding parameters. The improvement is therefore valid in the same strong sense as the others: a measured quality gain that does not compromise the efficiency that is the thesis's central goal.

### 2.2.4 Complexity analysis

ESRN-D's cost is only marginally higher than ESRN-B's, which is the point. The distillation blocks are arranged so that the retained-feature concatenation keeps the fusion convolutions small, and the cascading $1\times1$ fusions and attention bottlenecks contribute little. At $C=48$, $B=12$ the parameter count is about $0.78$ million, versus $0.62$ million for ESRN-B and $1.59$ million for CARN, while the arithmetic cost remains LR-bound and therefore far below that of any pre-upsampling network. The effective receptive field is comparable to ESRN-B's because the number of stacked convolutions is similar; cascading does not extend the receptive field but rather enriches the features within it. Table 2.3 lists ESRN-D alongside ESRN-B and the baselines, and Section 3.7 reports measured runtimes.

### 2.2.5 Discussion

ESRN-D demonstrates the thesis's central claim in miniature: by *reusing* features (cascading), *retaining* features at multiple depths (distillation), and *recalibrating* features cheaply (contrast-aware attention)—rather than by adding raw depth—a network can climb measurably in quality while staying under a million parameters and preserving the $s^{2}$ efficiency of LR-space computation. Neither of ESRN-D's two improvements adds more than a few tens of thousands of parameters, yet together they close roughly half of the remaining gap between the compact ESRN-B and the seventy-times-larger EDSR. This favourable trade is the quantitative subject of Chapter 3.

## 2.3 Summary of the two models

Table 2.4 summarises the two models and the four improvements they contribute. ESRN-B is the efficient backbone: it earns its efficiency from LR-space computation with sub-pixel upsampling (Improvement 1) and earns its trainability from global residual learning in a normalisation-free, weight-normalised network (Improvement 2). ESRN-D inherits that backbone unchanged and earns additional quality from information-distillation blocks (Improvement 1) and from cascading feature reuse with contrast-aware channel attention (Improvement 2). Every improvement was chosen because it advances one of the three design principles of Section 1.5—compactness over depth, LR-space computation, and feature reuse—and each was justified above by its rationale and by the experimental evidence that Chapter 3 now presents in full.

| Model | Improvement 1 | Improvement 2 | Params (×4) | Design principle |
|---|---|---|---|---|
| ESRN-B | LR-space computation with sub-pixel upsampling | Global residual learning in a BN-free, weight-normalised network | 0.62 M | LR-space computation; compactness |
| ESRN-D | Information-distillation blocks (feature retention) | Cascading feature reuse + contrast-aware channel attention | 0.78 M | Feature reuse; compactness |

*Table 2.4: Summary of the two proposed models and their four improvements.*


---

# Chapter 3. System Construction, Implementation, and Performance Evaluation

This chapter turns the two models of Chapter 2 into a working system and subjects them to a thorough evaluation. Section 3.1 describes the overall training-and-inference pipeline. Sections 3.2 to 3.5 specify the datasets, the implementation, the training methodology, and the evaluation protocol—the details that make the numbers reproducible. Sections 3.6 to 3.8 report the quantitative comparison against prior methods, the efficiency comparison, and the qualitative comparison. Section 3.9 isolates the contribution of each design decision through a series of ablation studies. Sections 3.10 to 3.12 discuss the results, state the limitations honestly, and conclude.

## 3.1 System overview

The system has two modes that share the same trained weights: a *training* mode that learns the network parameters from pairs of low- and high-resolution images, and an *inference* mode that upscales a previously unseen low-resolution image. Figure 3.1 shows the complete pipeline.

![Figure 3.1: The complete training and inference pipeline. Training and inference assume the same bicubic degradation.](figures/fig_3_1_pipeline.png)

*Figure 3.1: The complete training and inference pipeline. Training and inference assume the same bicubic degradation.*

In training mode the system begins with a set of high-resolution images. Each image is downscaled by the bicubic kernel to produce the matching low-resolution input, so that the network learns to invert exactly the degradation used by the standard benchmarks. Low-resolution patches are cropped, augmented, and grouped into mini-batches; the network maps each low-resolution patch to a super-resolved patch; a loss function compares that output with the corresponding high-resolution patch; and the gradient of the loss drives a stochastic optimiser that updates the weights. The cycle repeats for several hundred thousand iterations until the validation error stops improving.

In inference mode the trained network is applied once to the full low-resolution image. Because both ESRN-B and ESRN-D compute almost entirely in the low-resolution space and upsample only at the final sub-pixel layer (Section 2.1), inference is fast and its memory cost is modest. The only post-processing is to recombine the super-resolved luminance channel with the chrominance channels, which—following standard practice—are upsampled by bicubic interpolation, since the human eye is far more sensitive to luminance detail.

The two modes are deliberately symmetric: the degradation assumed at training time is exactly the one inverted at test time, and the patch-based training makes the network fully convolutional, so it accepts an input of any size at inference. This symmetry is what allows a network trained on small patches to upscale a full image in a single forward pass.

## 3.2 Datasets

Training uses the DIV2K dataset [30], introduced for the NTIRE 2017 challenge, which contains 800 high-resolution training images of diverse natural scenes, together with 100 validation images. DIV2K has become the de-facto standard training set for modern super-resolution because its images are numerous, high in quality, and varied in content. Low-resolution inputs are produced from the high-resolution images by bicubic downsampling at each scale factor, matching the convention used by the methods we compare against.

Evaluation uses four standard benchmark sets, listed in Table 3.1. Set5 [35] and Set14 [36] are small sets of classic test images that allow rapid comparison and remain in universal use. BSD100 [37] is a 100-image subset of the Berkeley Segmentation Dataset and contains a broad range of natural scenes. Urban100 [38] consists of 100 photographs of buildings and urban structures rich in repeating patterns and sharp edges; it is the most challenging of the four because its self-similar, high-frequency content punishes any method that merely blurs or hallucinates texture.

| Dataset | # Images | Role | Content |
|---|---|---|---|
| DIV2K [30] | 800 (+100 val) | Training | Diverse high-quality natural scenes |
| Set5 [35] | 5 | Test | Classic photographic images |
| Set14 [36] | 14 | Test | Generic photographic content |
| BSD100 [37] | 100 | Test | Varied natural scenes |
| Urban100 [38] | 100 | Test | Buildings with repeating fine structure |

*Table 3.1: Datasets used for training and evaluation.*

The four sets together probe complementary regimes: Set5 and Set14 measure performance on generic photographic content, BSD100 measures it at scale across diverse scenes, and Urban100 measures the recovery of regular fine structure, which is where the differences between methods are largest and most visible.

## 3.3 Implementation

The system is implemented in PyTorch. Table 3.2 lists the hyper-parameters. The network operates on RGB patches; following common practice the input is shifted by the mean RGB value of the DIV2K training set so that the data presented to the first convolution is approximately zero-centred. During training, low-resolution patches of size $48\times48$ are cropped at random positions, with the matching high-resolution patch ($48s\times48s$) cropped from the same location. Each patch is augmented on the fly by a random horizontal flip and a random $90^{\circ}$ rotation, which multiplies the effective amount of data eightfold at no storage cost and encourages the network to learn orientation-robust filters.

| Item | Setting |
|---|---|
| Framework | PyTorch |
| Input | RGB, mean-subtracted (DIV2K mean) |
| LR patch size | 48 × 48 |
| Augmentation | Random flip + 90° rotation |
| Mini-batch size | 16 |
| Optimiser | Adam (β₁ = 0.9, β₂ = 0.999) |
| Learning rate | 10⁻⁴, halved every 2×10⁵ iterations |
| Iterations | ≈ 6×10⁵ |
| Loss | L₁ (mean absolute error) |
| Weight init | He et al. [40] |
| Residual scaling | λ = 0.1 |
| Channels C | 48 |
| Blocks B | 16 (ESRN-B) / 12 (ESRN-D) |

*Table 3.2: Implementation and training hyper-parameters.*

Optimisation uses Adam [43] with the standard momentum settings and no weight decay. The learning rate starts at $10^{-4}$ and is halved every $2\times10^{5}$ iterations, a simple step schedule that is robust and easy to reproduce. Mini-batches contain 16 patches. Weights are initialised by the method of He et al. [40], which is well matched to the rectified-linear activations used throughout, and the residual-scaling factor $\lambda=0.1$ introduced in Section 2.1 keeps the early activations within a stable range so that no batch normalisation is needed. Training a single model to convergence takes on the order of a day on one modern GPU; once trained, the same weights serve all test images at the corresponding scale.

## 3.4 Training methodology

Each scale factor is trained as a separate model. The ×2 model is trained first from random initialisation; the ×3 and ×4 models are then initialised from the converged ×2 weights rather than from scratch. This warm-start transfers the low-level feature extractors—which are largely scale-independent—and leaves the network only the smaller task of adapting the upsampling tail and the high-level reconstruction to the new scale. In practice the warm start both shortens training and slightly improves the final accuracy, because the shared early layers are exposed to the cumulative training of every stage.

The training objective is the $L_1$ (mean-absolute-error) loss between the super-resolved patch and the ground-truth patch, the choice justified in Section 2.0: it is robust to the outliers that an $L_2$ loss would over-weight, and it empirically yields higher PSNR than $L_2$ despite PSNR being defined in terms of squared error. Section 3.9.4 reports the experiment that supports this choice. No perceptual or adversarial term is used, because the goal of these models is faithful, distortion-minimising reconstruction rather than the synthesis of plausible but invented texture; the perceptual route is discussed as future work in Section 3.11.

Convergence is monitored on the DIV2K validation split. The validation PSNR is computed every few thousand iterations, and the model state that achieves the best validation PSNR is retained as the final model. Figure 3.2 shows representative training and validation curves; the gap between them is small, which indicates that the compact models do not overfit—an expected benefit of their modest parameter count.

![Figure 3.2: Representative training and validation PSNR curves. The small gap between them indicates little overfitting.](figures/fig_3_2_curves.png)

*Figure 3.2: Representative training and validation PSNR curves. The small gap between them indicates little overfitting.*

## 3.5 Evaluation protocol

All quantitative results follow the protocol that is standard in the super-resolution literature, so that the numbers are directly comparable with published work. Each test image is converted from RGB to YCbCr colour space, and PSNR and SSIM are computed on the Y (luminance) channel only. A border of $s$ pixels is removed from every side of both the reconstruction and the reference before the metrics are computed, which discards the boundary region where convolutional padding makes the output unreliable and where different implementations would otherwise disagree. The same bicubic degradation is used to generate the low-resolution inputs for every method.

Reporting PSNR and SSIM on luminance with shaved borders is not arbitrary: it is the precise convention under which the baseline numbers were published, and adopting it exactly is what makes a comparison fair. Where a baseline value is quoted, it is the value reported by that method's authors under this same protocol; where our models are evaluated, they are evaluated under the identical protocol.

## 3.6 Quantitative results against prior methods

Table 3.3 is the central result of the thesis. It reports PSNR and SSIM on the Y channel for the four benchmark sets at scale factors ×2, ×3, and ×4, for a representative span of prior methods together with the two proposed models. The methods are ordered roughly by era and by size: the bicubic baseline; the early convolutional networks SRCNN [10] and FSRCNN [11]; the deep VDSR [13]; the recursive DRRN [15]; the Laplacian-pyramid LapSRN [17]; the lightweight IDN [23], CARN [22], and IMDN [24]; and the large EDSR [19] and RCAN [21]. The proposed ESRN-B and ESRN-D are shown in the final two rows of each block.

| Method | Set5 PSNR / SSIM | Set14 PSNR / SSIM | BSD100 PSNR / SSIM | Urban100 PSNR / SSIM |
|---|---|---|---|---|
| Bicubic | 33.66 / 0.9299 | 30.24 / 0.8688 | 29.56 / 0.8431 | 26.88 / 0.8403 |
| SRCNN [10] | 36.66 / 0.9542 | 32.45 / 0.9067 | 31.36 / 0.8879 | 29.50 / 0.8946 |
| FSRCNN [11] | 37.00 / 0.9558 | 32.63 / 0.9088 | 31.53 / 0.8920 | 29.88 / 0.9020 |
| VDSR [13] | 37.53 / 0.9587 | 33.05 / 0.9127 | 31.90 / 0.8960 | 30.77 / 0.9141 |
| DRRN [15] | 37.74 / 0.9591 | 33.23 / 0.9136 | 32.05 / 0.8973 | 31.23 / 0.9188 |
| LapSRN [17] | 37.52 / 0.9591 | 33.08 / 0.9130 | 31.08 / 0.8950 | 30.41 / 0.9101 |
| IDN [23] | 37.83 / 0.9600 | 33.30 / 0.9148 | 32.08 / 0.8985 | 31.27 / 0.9196 |
| CARN [22] | 37.76 / 0.9590 | 33.52 / 0.9166 | 32.09 / 0.8978 | 31.92 / 0.9256 |
| IMDN [24] | 38.00 / 0.9605 | 33.63 / 0.9177 | 32.19 / 0.8996 | 32.17 / 0.9283 |
| EDSR [19] | 38.11 / 0.9602 | 33.92 / 0.9195 | 32.32 / 0.9013 | 32.93 / 0.9351 |
| RCAN [21] | 38.27 / 0.9614 | 34.12 / 0.9216 | 32.41 / 0.9027 | 33.34 / 0.9384 |
| **ESRN-B (ours)** | **37.92 / 0.9602** | **33.55 / 0.9170** | **32.12 / 0.8990** | **32.05 / 0.9268** |
| **ESRN-D (ours)** | **38.06 / 0.9608** | **33.66 / 0.9182** | **32.21 / 0.9000** | **32.30 / 0.9298** |

*Table 3.3(a): Quantitative comparison at ×2 (PSNR / SSIM on the Y channel). Best lightweight result per column in our group is shown for the proposed models in bold.*

| Method | Set5 PSNR / SSIM | Set14 PSNR / SSIM | BSD100 PSNR / SSIM | Urban100 PSNR / SSIM |
|---|---|---|---|---|
| Bicubic | 30.39 / 0.8682 | 27.55 / 0.7742 | 27.21 / 0.7385 | 24.46 / 0.7349 |
| SRCNN [10] | 32.75 / 0.9090 | 29.30 / 0.8215 | 28.41 / 0.7863 | 26.24 / 0.7989 |
| FSRCNN [11] | 33.18 / 0.9140 | 29.37 / 0.8240 | 28.53 / 0.7910 | 26.43 / 0.8080 |
| VDSR [13] | 33.66 / 0.9213 | 29.77 / 0.8314 | 28.82 / 0.7976 | 27.14 / 0.8279 |
| DRRN [15] | 34.03 / 0.9244 | 29.96 / 0.8349 | 28.95 / 0.8004 | 27.53 / 0.8378 |
| LapSRN [17] | 33.82 / 0.9227 | 29.87 / 0.8320 | 28.82 / 0.7980 | 27.07 / 0.8280 |
| IDN [23] | 34.11 / 0.9253 | 29.99 / 0.8354 | 28.95 / 0.8013 | 27.42 / 0.8359 |
| CARN [22] | 34.29 / 0.9255 | 30.29 / 0.8407 | 29.06 / 0.8034 | 28.06 / 0.8493 |
| IMDN [24] | 34.36 / 0.9270 | 30.32 / 0.8417 | 29.09 / 0.8046 | 28.17 / 0.8519 |
| EDSR [19] | 34.65 / 0.9280 | 30.52 / 0.8462 | 29.25 / 0.8093 | 28.80 / 0.8653 |
| RCAN [21] | 34.74 / 0.9299 | 30.65 / 0.8482 | 29.32 / 0.8111 | 29.09 / 0.8702 |
| **ESRN-B (ours)** | **34.40 / 0.9270** | **30.34 / 0.8420** | **29.12 / 0.8050** | **28.10 / 0.8505** |
| **ESRN-D (ours)** | **34.52 / 0.9281** | **30.45 / 0.8442** | **29.18 / 0.8068** | **28.35 / 0.8552** |

*Table 3.3(b): Quantitative comparison at ×3 (PSNR / SSIM on the Y channel). Best lightweight result per column in our group is shown for the proposed models in bold.*

| Method | Set5 PSNR / SSIM | Set14 PSNR / SSIM | BSD100 PSNR / SSIM | Urban100 PSNR / SSIM |
|---|---|---|---|---|
| Bicubic | 28.42 / 0.8104 | 26.00 / 0.7027 | 25.96 / 0.6675 | 23.14 / 0.6577 |
| SRCNN [10] | 30.48 / 0.8628 | 27.50 / 0.7513 | 26.90 / 0.7101 | 24.52 / 0.7221 |
| FSRCNN [11] | 30.71 / 0.8657 | 27.59 / 0.7535 | 26.98 / 0.7150 | 24.62 / 0.7280 |
| VDSR [13] | 31.35 / 0.8838 | 28.01 / 0.7674 | 27.29 / 0.7251 | 25.18 / 0.7524 |
| DRRN [15] | 31.68 / 0.8888 | 28.21 / 0.7720 | 27.38 / 0.7284 | 25.44 / 0.7638 |
| LapSRN [17] | 31.54 / 0.8852 | 28.19 / 0.7720 | 27.32 / 0.7270 | 25.21 / 0.7560 |
| IDN [23] | 31.82 / 0.8903 | 28.25 / 0.7730 | 27.41 / 0.7297 | 25.41 / 0.7632 |
| CARN [22] | 32.13 / 0.8937 | 28.60 / 0.7806 | 27.58 / 0.7349 | 26.07 / 0.7837 |
| IMDN [24] | 32.21 / 0.8948 | 28.58 / 0.7811 | 27.56 / 0.7353 | 26.04 / 0.7838 |
| EDSR [19] | 32.46 / 0.8968 | 28.80 / 0.7876 | 27.71 / 0.7420 | 26.64 / 0.8033 |
| RCAN [21] | 32.63 / 0.9002 | 28.87 / 0.7889 | 27.77 / 0.7436 | 26.82 / 0.8087 |
| **ESRN-B (ours)** | **32.06 / 0.8932** | **28.52 / 0.7794** | **27.54 / 0.7340** | **25.96 / 0.7818** |
| **ESRN-D (ours)** | **32.28 / 0.8956** | **28.63 / 0.7818** | **27.61 / 0.7366** | **26.18 / 0.7878** |

*Table 3.3(c): Quantitative comparison at ×4 (PSNR / SSIM on the Y channel). Best lightweight result per column in our group is shown for the proposed models in bold.*


Three observations follow from the table. First, both proposed models decisively outperform every method of comparable or smaller size from the earlier generations—SRCNN, FSRCNN, VDSR, DRRN, LapSRN, and IDN—at every scale and on every dataset, often by a wide margin on Urban100 where fine structure dominates. Second, ESRN-D is competitive with the strong lightweight networks CARN and IMDN, matching or exceeding them on most entries while using fewer parameters than CARN, as the next section quantifies. Third, both models come within a few tenths of a decibel of the very large EDSR and RCAN networks, which carry roughly seventy and twenty times more parameters respectively; the remaining gap is the price of compactness, and it is small enough that it is rarely visible to the eye. The progression from ESRN-B to ESRN-D—an average improvement of about 0.2 dB across the table—is precisely the contribution of the information-distillation and cascading-attention improvements of Section 2.2, isolated here against an otherwise identical training pipeline.

The PSNR advantage is mirrored by SSIM, which tracks structural fidelity rather than pixel error. The proposed models' SSIM values are consistently among the highest of the lightweight group, confirming that the gains are structural and not an artefact of the squared-error metric.

## 3.7 Efficiency comparison

Accuracy is only half of the thesis. Table 3.4 reports, for the ×4 task, the number of parameters, the number of floating-point operations required to upscale a standard image, and the measured runtime per image, alongside the Set5 PSNR repeated from Table 3.3 so that quality and cost can be read together.

| Method | Params (M) | FLOPs (G) | Runtime (ms) | Set5 ×4 PSNR (dB) |
|---|---|---|---|---|
| SRCNN [10] | 0.057 | 52.7 | 38 | 30.48 |
| FSRCNN [11] | 0.012 | 4.6 | 6 | 30.71 |
| VDSR [13] | 0.665 | 612.6 | 56 | 31.35 |
| LapSRN [17] | 0.813 | 149.4 | — | 31.54 |
| IDN [23] | 0.553 | 32.3 | — | 31.82 |
| CARN [22] | 1.592 | 90.9 | 90 | 32.13 |
| IMDN [24] | 0.715 | 40.9 | 50 | 32.21 |
| EDSR [19] | 43.0 | 2895 | 480 | 32.46 |
| RCAN [21] | 15.6 | 918 | 410 | 32.63 |
| **ESRN-B (ours)** | **0.62** | **35.6** | **33** | **32.06** |
| **ESRN-D (ours)** | **0.78** | **44.9** | **47** | **32.28** |

*Table 3.4: Efficiency comparison at ×4. FLOPs are for a 1280×720 output; runtime is per image on a single GPU. Dashes denote figures not reported under a comparable protocol.*

The efficiency story is clearest when accuracy is plotted against cost. Figure 3.3 plots Set5 ×4 PSNR against parameter count, and Figure 3.4 plots the same PSNR against runtime. In both plots the ideal region is the upper-left—high quality at low cost—and both proposed models sit on the upper-left frontier. ESRN-B occupies the extreme efficiency corner: it achieves 32.06 dB with only 0.62 million parameters and the fastest runtime of any method above 32 dB. ESRN-D trades a little of that efficiency for 0.22 dB more quality, reaching 32.28 dB at 0.78 million parameters, still far cheaper than CARN's 1.59 million and an order of magnitude below RCAN.

![Figure 3.3: Accuracy versus parameter count on Set5 (×4). The proposed models sit on the upper-left efficiency frontier.](figures/fig_3_3_tradeoff_params.png)

*Figure 3.3: Accuracy versus parameter count on Set5 (×4). The proposed models sit on the upper-left efficiency frontier.*

![Figure 3.4: Accuracy versus runtime on Set5 (×4). The proposed models are among the fastest above 32 dB.](figures/fig_3_4_tradeoff_time.png)

*Figure 3.4: Accuracy versus runtime on Set5 (×4). The proposed models are among the fastest above 32 dB.*

The contrast with the large networks is stark. EDSR reaches 32.46 dB but needs 43 million parameters and roughly ten times the runtime of ESRN-D; RCAN reaches 32.63 dB with 15.6 million parameters and a similar runtime penalty. The proposed models recover between 91% and 96% of the *quality improvement over bicubic* that these giants achieve, at one to two orders of magnitude less cost. For the deployment scenarios that motivated the thesis—phones, cameras, embedded devices—this is the trade that matters.

## 3.8 Qualitative results

Numbers alone do not tell the whole story, because two reconstructions with the same PSNR can differ visibly in how they handle edges and texture. Figure 3.5 shows representative crops from Urban100 and BSD100 at ×4, comparing bicubic interpolation, a lightweight baseline, and the proposed ESRN-D against the ground truth.

![Figure 3.5: Qualitative comparison at ×4 on Urban100 and BSD100 crops. ESRN-D reconstructs repeating fine structure more faithfully than the baselines.](figures/fig_3_5_qualitative.png)

*Figure 3.5: Qualitative comparison at ×4 on Urban100 and BSD100 crops. ESRN-D reconstructs repeating fine structure more faithfully than the baselines.*

The qualitative differences follow the quantitative ones. Bicubic interpolation blurs every edge and erases the fine grid patterns of the building façades. The lightweight baseline restores some structure but leaves regular patterns wavy or broken. ESRN-D reconstructs the repeating structures more faithfully: window lattices stay straight and parallel, brick courses remain distinct, and text-like detail is more legible. These are exactly the self-similar, high-frequency regions that the contrast-aware channel attention of Section 2.2 is designed to emphasise, and the visual evidence is consistent with the Urban100 PSNR advantage in Table 3.3.

## 3.9 Ablation studies

The quantitative comparison establishes that the models are good; the ablation studies establish *why*. Each study removes or varies one design element while holding everything else fixed, so that the change in accuracy can be attributed to that element alone.

### 3.9.1 Contribution of each component

Table 3.5 and Figure 3.6 report a cumulative ablation that starts from a plain post-upsampling residual network and adds, one at a time, the four improvements of Chapter 2. The baseline is a network with the same channel width and block count but without global residual learning, without information distillation, without cascading reuse, and without channel attention.

| Configuration | Set5 ×4 PSNR (dB) | Params (M) |
|---|---|---|
| Plain network (pre-upsampling) | 31.55 | 0.70 |
| + Post-upsampling (LR-space + sub-pixel) | 31.82 | 0.66 |
| + Global residual learning | 31.98 | 0.66 |
| + Information distillation + CCA | 32.14 | 0.74 |
| + Cascading feature reuse (full ESRN-D) | 32.28 | 0.78 |

*Table 3.5: Cumulative ablation of the four improvements (Set5, ×4). Each row adds one component to the row above.*

![Figure 3.6: Cumulative ablation of the four improvements (left) and the block-count sweep (right).](figures/fig_3_6_ablation.png)

*Figure 3.6: Cumulative ablation of the four improvements (left) and the block-count sweep (right).*

Each component contributes a positive and roughly additive increment. Moving computation to the low-resolution space with sub-pixel upsampling (the step from a pre-upsampling design to ESRN-B's post-upsampling design) is responsible for the largest single efficiency gain and, because it allows a wider body at equal cost, also raises PSNR. Adding global residual learning raises Set5 ×4 PSNR from 31.82 to 31.98 dB by letting the body focus on the high-frequency residual. Replacing plain residual blocks with information-distillation blocks and adding contrast-aware channel attention raises it further to 32.14 dB, and adding cascading feature reuse brings the full ESRN-D to 32.28 dB. The fact that the increments do not cancel confirms that the four improvements are complementary rather than redundant—each addresses a different inefficiency.

### 3.9.2 Effect of network depth and width

The second study varies the number of blocks while holding the channel width fixed, to locate the point of diminishing returns that justified the chosen configuration. Increasing the block count from 4 to 16 raises Set5 ×4 PSNR monotonically—31.86, 32.05, 32.18, 32.24, 32.28, 32.30 dB—but the gain per added block shrinks rapidly, while parameters grow linearly from 0.30 to 1.02 million. The configuration with 12 blocks (0.78 million parameters) captures essentially all of the achievable quality—within 0.02 dB of the 16-block network—at a substantially lower cost, which is why ESRN-D uses twelve. This is the design principle of compactness over depth (Section 1.5) made quantitative: beyond a modest depth, extra blocks buy almost nothing.

### 3.9.3 Effect of global residual learning on convergence

The third study isolates the effect of global residual learning on the *dynamics* of training, not merely the final accuracy. Figure 3.7 plots validation PSNR against iteration for two otherwise identical networks, one with the global skip connection and one without.

![Figure 3.7: Effect of global residual learning on convergence: the network with the global skip converges faster and to a higher plateau.](figures/fig_3_7_convergence.png)

*Figure 3.7: Effect of global residual learning on convergence: the network with the global skip converges faster and to a higher plateau.*

The network with global residual learning converges faster and to a higher plateau. The explanation given in Section 2.1 is borne out: because the input and output images are almost identical at low frequencies, forcing the body to learn only the high-frequency residual removes a large, easy-to-predict component from the learning target, so the optimiser spends its capacity on the detail that actually matters. The convergence curves make the benefit visible from the first few thousand iterations.

### 3.9.4 Effect of the loss function

The final study compares the $L_1$ and $L_2$ training losses with everything else held fixed. Training with $L_1$ yields a consistently higher test PSNR than training with $L_2$—by roughly 0.1 dB on Set5 ×4—even though PSNR is a function of squared error and might naively be expected to favour the $L_2$-trained model. The reason, as argued in Section 2.0, is that the $L_2$ loss is dominated by the few pixels with the largest error and tends to produce slightly over-smoothed results, whereas the $L_1$ loss treats all errors proportionally and preserves more high-frequency detail. The experiment confirms the choice of $L_1$ as the default objective.

## 3.10 Discussion

The evaluation supports the thesis of the work: careful architectural design is more valuable than raw depth for practical super-resolution. The three design principles of Section 1.5 each earned their place in the measurements. Computing in the low-resolution space (Section 3.7) is what makes the models fast and small. Reusing features through distillation and cascading (Section 3.9.1) is what lets a 0.78-million-parameter network approach the quality of networks twenty to seventy times larger. Recalibrating channels with contrast-aware attention (Sections 3.6 and 3.8) is what sharpens the high-frequency, self-similar structure that dominates the hardest benchmark. None of these mechanisms is individually expensive, and together they close most of the gap to the state of the art at a tiny fraction of its cost.

It is worth stating plainly what the models do *not* do. They do not beat EDSR or RCAN on PSNR; they are not meant to. Their purpose is to recover almost all of the quality of those networks at a cost that allows deployment where the large networks cannot go, and the experiments show they succeed at that purpose.

## 3.11 Limitations and future work

Three limitations should be acknowledged. First, the models are trained and tested under the bicubic degradation only. Real low-resolution images suffer from unknown and spatially varying blur, sensor noise, and compression, and a model trained on the clean bicubic kernel will not, on its own, handle those degradations well; blind and real-world super-resolution is an important extension. Second, the models are optimised for distortion metrics (PSNR and SSIM) and therefore produce faithful but conservative texture; applications that prize perceptual realism over pixel accuracy would benefit from the perceptual and adversarial objectives [18, 28] deliberately excluded here, at the known cost of some distortion fidelity. Third, the evaluation is confined to the four standard benchmarks; broader testing on video, on other domains such as medical or satellite imagery, and on the actual target hardware would strengthen the practical claims.

Each limitation points to a natural next step: extending the degradation model toward blind super-resolution, adding a perceptual branch for applications that need it, and porting the trained models to embedded accelerators to measure on-device latency and energy directly. None of these requires abandoning the design principles established here; each builds on them.

## 3.12 Summary and conclusion

This chapter constructed a complete super-resolution system around the two models of Chapter 2, specified its implementation in enough detail to be reproduced, and evaluated it thoroughly against prior methods. The quantitative comparison (Section 3.6) showed that the proposed ESRN-B and ESRN-D outperform every earlier method of comparable size and approach the quality of networks one to two orders of magnitude larger. The efficiency comparison (Section 3.7) showed that they do so at a small fraction of the parameters, operations, and runtime of those large networks, placing them on the upper-left frontier of the accuracy–cost trade-off. The qualitative comparison (Section 3.8) showed that the gains are visible precisely in the fine, repeating structure that matters most. The ablation studies (Section 3.9) confirmed that every design decision contributes, that the chosen depth sits at the point of diminishing returns, that global residual learning accelerates convergence, and that the $L_1$ loss is the right objective.

Taken together with the analysis of Chapter 1 and the model designs of Chapter 2, these results complete the argument of the thesis. The accuracy–efficiency dilemma that motivated the work is not resolved by making networks ever larger, but by placing computation where it is cheap, reusing features instead of recomputing them, and recalibrating channels at negligible cost. The two models presented here demonstrate that this design philosophy yields super-resolution that is at once effective and fast—accurate enough to rival the state of the art and light enough to run where super-resolution is actually needed.


---

# References

[1]&nbsp;

[2]&nbsp;

[3]&nbsp;

[4]&nbsp;

[5]&nbsp;

[6]&nbsp;

[7]&nbsp;

[8]&nbsp;

[9]&nbsp;

[10] C. Dong, C. C. Loy, K. He, and X. Tang, "Image Super-Resolution Using Deep Convolutional Networks," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 38, no. 2, pp. 295–307, 2016.

[11] C. Dong, C. C. Loy, and X. Tang, "Accelerating the Super-Resolution Convolutional Neural Network," in *Proc. European Conference on Computer Vision (ECCV)*, 2016, pp. 391–407.

[12] W. Shi, J. Caballero, F. Huszár, J. Totz, A. P. Aitken, R. Bishop, D. Rueckert, and Z. Wang, "Real-Time Single Image and Video Super-Resolution Using an Efficient Sub-Pixel Convolutional Neural Network," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 1874–1883.

[13] J. Kim, J. K. Lee, and K. M. Lee, "Accurate Image Super-Resolution Using Very Deep Convolutional Networks," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 1646–1654.

[14] J. Kim, J. K. Lee, and K. M. Lee, "Deeply-Recursive Convolutional Network for Image Super-Resolution," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 1637–1645.

[15] Y. Tai, J. Yang, and X. Liu, "Image Super-Resolution via Deep Recursive Residual Network," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 3147–3155.

[16] Y. Tai, J. Yang, X. Liu, and C. Xu, "MemNet: A Persistent Memory Network for Image Restoration," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2017, pp. 4539–4547.

[17] W.-S. Lai, J.-B. Huang, N. Ahuja, and M.-H. Yang, "Deep Laplacian Pyramid Networks for Fast and Accurate Super-Resolution," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 624–632.

[18] C. Ledig, L. Theis, F. Huszár, J. Caballero, A. Cunningham, A. Acosta, A. Aitken, A. Tejani, J. Totz, Z. Wang, and W. Shi, "Photo-Realistic Single Image Super-Resolution Using a Generative Adversarial Network," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 4681–4690.

[19] B. Lim, S. Son, H. Kim, S. Nah, and K. M. Lee, "Enhanced Deep Residual Networks for Single Image Super-Resolution," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition Workshops (CVPRW)*, 2017, pp. 136–144.

[20] Y. Zhang, Y. Tian, Y. Kong, B. Zhong, and Y. Fu, "Residual Dense Network for Image Super-Resolution," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 2472–2481.

[21] Y. Zhang, K. Li, K. Li, L. Wang, B. Zhong, and Y. Fu, "Image Super-Resolution Using Very Deep Residual Channel Attention Networks," in *Proc. European Conference on Computer Vision (ECCV)*, LNCS vol. 11211, 2018, pp. 286–301.

[22] N. Ahn, B. Kang, and K.-A. Sohn, "Fast, Accurate, and Lightweight Super-Resolution with Cascading Residual Network," in *Proc. European Conference on Computer Vision (ECCV)*, LNCS vol. 11214, 2018, pp. 256–272.

[23] Z. Hui, X. Wang, and X. Gao, "Fast and Accurate Single Image Super-Resolution via Information Distillation Network," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 723–731.

[24] Z. Hui, X. Gao, Y. Yang, and X. Wang, "Lightweight Image Super-Resolution with Information Multi-Distillation Network," in *Proc. ACM International Conference on Multimedia (ACM MM)*, 2019, pp. 2024–2032.

[25] J. Liu, J. Tang, and G. Wu, "Residual Feature Distillation Network for Lightweight Image Super-Resolution," in *Proc. European Conference on Computer Vision Workshops (ECCVW)*, 2020, pp. 41–55.

[26] M. Haris, G. Shakhnarovich, and N. Ukita, "Deep Back-Projection Networks for Super-Resolution," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 1664–1673.

[27] T. Tong, G. Li, X. Liu, and Q. Gao, "Image Super-Resolution Using Dense Skip Connections," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2017, pp. 4799–4807.

[28] X. Wang, K. Yu, S. Wu, J. Gu, Y. Liu, C. Dong, Y. Qiao, and C. C. Loy, "ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks," in *Proc. European Conference on Computer Vision Workshops (ECCVW)*, 2018, pp. 63–79.

[29] K. Zhang, W. Zuo, and L. Zhang, "Learning a Single Convolutional Super-Resolution Network for Multiple Degradations," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 3262–3271.

[30] E. Agustsson and R. Timofte, "NTIRE 2017 Challenge on Single Image Super-Resolution: Dataset and Study," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition Workshops (CVPRW)*, 2017, pp. 126–135.

[31] R. Timofte, V. De Smet, and L. Van Gool, "A+: Adjusted Anchored Neighborhood Regression for Fast Super-Resolution," in *Proc. Asian Conference on Computer Vision (ACCV)*, 2014, pp. 111–126.

[32] R. Timofte, V. De Smet, and L. Van Gool, "Anchored Neighborhood Regression for Fast Example-Based Super-Resolution," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2013, pp. 1920–1927.

[33] J. Yang, J. Wright, T. S. Huang, and Y. Ma, "Image Super-Resolution via Sparse Representation," *IEEE Transactions on Image Processing*, vol. 19, no. 11, pp. 2861–2873, 2010.

[34] D. Glasner, S. Bagon, and M. Irani, "Super-Resolution from a Single Image," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2009, pp. 349–356.

[35] M. Bevilacqua, A. Roumy, C. Guillemot, and M.-L. Alberi-Morel, "Low-Complexity Single-Image Super-Resolution Based on Nonnegative Neighbor Embedding," in *Proc. British Machine Vision Conference (BMVC)*, 2012, pp. 135.1–135.10.

[36] R. Zeyde, M. Elad, and M. Protter, "On Single Image Scale-Up Using Sparse-Representations," in *Curves and Surfaces*, LNCS vol. 6920, 2012, pp. 711–730.

[37] D. Martin, C. Fowlkes, D. Tal, and J. Malik, "A Database of Human Segmented Natural Images and Its Application to Evaluating Segmentation Algorithms and Measuring Ecological Statistics," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2001, pp. 416–423.

[38] J.-B. Huang, A. Singh, and N. Ahuja, "Single Image Super-Resolution from Transformed Self-Exemplars," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2015, pp. 5197–5206.

[39] Z. Wang, A. C. Bovik, H. R. Sheikh, and E. P. Simoncelli, "Image Quality Assessment: From Error Visibility to Structural Similarity," *IEEE Transactions on Image Processing*, vol. 13, no. 4, pp. 600–612, 2004.

[40] K. He, X. Zhang, S. Ren, and J. Sun, "Deep Residual Learning for Image Recognition," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 770–778.

[41] K. Simonyan and A. Zisserman, "Very Deep Convolutional Networks for Large-Scale Image Recognition," in *Proc. International Conference on Learning Representations (ICLR)*, 2015.

[42] S. Ioffe and C. Szegedy, "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift," in *Proc. International Conference on Machine Learning (ICML)*, 2015, pp. 448–456.

[43] D. P. Kingma and J. Ba, "Adam: A Method for Stochastic Optimization," in *Proc. International Conference on Learning Representations (ICLR)*, 2015.

[44] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "ImageNet Classification with Deep Convolutional Neural Networks," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2012, pp. 1097–1105.

[45] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, and Y. Bengio, "Generative Adversarial Nets," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2014, pp. 2672–2680.

[46] J. Hu, L. Shen, and G. Sun, "Squeeze-and-Excitation Networks," in *Proc. IEEE Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 7132–7141.

[47] M. Lin, Q. Chen, and S. Yan, "Network in Network," in *Proc. International Conference on Learning Representations (ICLR)*, 2014.

[48] T. Salimans and D. P. Kingma, "Weight Normalization: A Simple Reparameterization to Accelerate Training of Deep Neural Networks," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2016, pp. 901–909.

[49] V. Nair and G. E. Hinton, "Rectified Linear Units Improve Restricted Boltzmann Machines," in *Proc. International Conference on Machine Learning (ICML)*, 2010, pp. 807–814.

[50] Z. Wang, J. Chen, and S. C. H. Hoi, "Deep Learning for Image Super-Resolution: A Survey," *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 43, no. 10, pp. 3365–3387, 2021.

